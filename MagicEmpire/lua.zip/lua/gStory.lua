------------gameStory 剧情事件
_GFtouchPolt = nil
function GFuncClickEventStory()
    if _GFtouchPolt then
        _GFtouchPolt(0,0,CCTOUCHENDED, true)
    end
end
--------------------
--------------------
GGameRunEventStory = function(args)
    local eid, func = args.eid, args.func
    local function endfunc()
        if func then
            func()
        end
    end

    ----获取剧情对白信息
    local _index = 1
    local plotStoryInfos = {}
    if args.evtlist then
        plotStoryInfos = args.evtlist
    else
        --for k, info in pairs(StoryTables_Static) do
        for k=1,table.getn(StoryTables_Static) do
            local info = StoryTables_Static[k]
            if info and info.event == eid then--and _index == info.index then
                --plotStoryInfos[info.index] = info --table.insert(plotStoryInfos, info)
                table.insert(plotStoryInfos, info)
            end
        end
    end
    if #plotStoryInfos <= 0 then
        endfunc()
        return
    end
    
    -- 当前显示段落
    local plotIndex = 0
    local plotInfo = plotStoryInfos
    -- 当前显示序列
    local txtIndex = 0
    local maxtxtLength = 0
    -- 显示频率
    local txtInv = 0.05
    local txtInvlast = 0
    
    -- 显示完成标识
    local isShowEnd = true
    
    local layer = nil
    --文字
    local txtMsg = nil
    -- 提示点击
    local iconNext = nil
    -- 当前显示文本
    local _showmessage = ""
    local _showInfos = nil
    
    local func_showNext = function()
        if plotIndex < #plotInfo then
            isShowEnd = false
            plotIndex = plotIndex + 1
            txtIndex = 1
            
            --- 信息相关
            _showInfos = plotInfo[plotIndex]
            _showmessage = _showInfos.msg
            if type(_showmessage) == number then
                _showmessage = string.format("%d", _showmessage)
            end
            maxtxtLength = string.len(_showmessage)

            -- 清空显示文本
            iconNext:setVisible(false)
            txtMsg:setString("")
        else
            -- 没有了
            CCDirector:sharedDirector():getRunningScene():removeChild(layer,true)
            -- 执行事件
            endfunc()
        end
    end
    
    local func_showEnd = function()
        iconNext:setVisible(true)
        isShowEnd = true
        txtMsg:setString(_showmessage)
    end
    
    
    --剧情开始
    local updateLayer = function(dt)  --更新回调
        if not isShowEnd and txtIndex <= maxtxtLength then
            txtInvlast = dt + txtInvlast
            if txtInvlast >= txtInv then
                txtInvlast = 0
                --下一个文字
                local ntxt = string.sub(_showmessage,txtIndex,txtIndex)
                local isV = false
                for k,v in pairs({"(", ":",")","[", "]","o","O","S","1","2","3","4","5","6","7","8","9","0",",",".","!","~"," ","^","/"}) do
                    if ntxt == v then
                        isV = true
                        break
                    end
                end
                if not isV then
                    ntxt = string.sub(_showmessage,txtIndex,txtIndex + 2)
                    txtIndex = txtIndex + 2
                end
                txtIndex = txtIndex + 1
                
                txtMsg:setString(string.format("%s%s",txtMsg:getString(),ntxt))
            end
            if txtIndex >= maxtxtLength then
                func_showEnd()
            end
        end
    end
    local enterLayer = function() --进入
    end
    local exitLayer = function() --离开
        _GFtouchPolt = nil
    end
    local touchBegin = function(x,y,eventType, snext) --触摸
        if eventType == CCTOUCHENDED then
            --快进,
            Play_Effect(sme_Click)
            if isShowEnd or snext then
                --下一条信息
                func_showNext()
            else
                func_showEnd()
            end
        end
    end

    local function clicklast( ... )
        -- body
        touchBegin(0,0,CCTOUCHENDED, true)
    end

    _GFtouchPolt = touchBegin

    local color = ccc4(0,0,0,100)
    if args.color then
        color = args.color
    end

    layer = GFunc_CreateLayerEnterOrExit({lindex=100,color=color, update=updateLayer, 
    enfunc=enterLayer, exfunc=exitLayer, touchBegin=touchBegin, touchMoved=touchBegin, touchEnded=touchBegin,
        fmbg=true})
    CCDirector:sharedDirector():getRunningScene():addChild(layer,15)
    
    local _parent = CCNode:create()
    layer:addChild(_parent)
    ---背景
    local uiWidth,uiHeight = 600, 300
    if args.width then
        uiWidth= args.width
    end
    if args.height then
        uiHeight = args.height
    end
    local spbg = CCScale9Sprite:createWithSpriteFrameName("duihuakuang01.png", CCRectMake(27, 27, 10, 10))
    spbg:setContentSize(CCSizeMake(uiWidth,uiHeight))
    spbg:setPosition(ccp(uiWidth/2, uiHeight/2))
    _parent:addChild(spbg)

    local agleft = 0
    if args.left then
        agleft = args.left
    end
    local agtop = 0
    if args.top then
        agtop = args.top
    end

    txtMsg = CCLabelTTF:create("", "Arial", GFGetFont(26), CCSizeMake(uiWidth-60-agleft, 0), kCCTextAlignmentLeft)
    txtMsg:setPosition(30+agleft, uiHeight-30-agtop)
    txtMsg:setAnchorPoint(ccp(0, 1))
    txtMsg:setColor(ccc3(0,0,0))
    spbg:addChild(txtMsg)

    iconNext = CCSprite:createWithSpriteFrameName("duihuakuang02.png")
    iconNext:setPosition(ccp(uiWidth-50, 40))
    spbg:addChild(iconNext)
    iconNext:setVisible(false)

    local arr1 = CCArray:create()
    arr1:addObject(CCMoveTo:create(0.2, ccp(uiWidth-50, 46)))
    arr1:addObject(CCMoveTo:create(0.2, ccp(uiWidth-50, 40)))
    local seq1 = CCSequence:create(arr1)
    iconNext:runAction(CCRepeatForever:create(seq1))


    func_showNext()

    local parentX, parentY = (DWinSize.width - uiWidth)/2,0
    _parent:setPosition(ccp(parentX, parentY))
    
    return {layer=layer, parent=_parent, parentX=parentX, parentY=parentY, clicklast=clicklast}
end
