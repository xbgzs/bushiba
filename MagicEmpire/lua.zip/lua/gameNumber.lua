local _NumberIndex = {
    ["1"]=0,
    ["2"]=1,
    ["3"]=2,
    ["4"]=3,
    ["5"]=4,
    ["6"]=5,
    ["7"]=6,
    ["8"]=7,
    ["9"]=8,
    ["0"]=9,
    ["/"]=10,
    ["-"]=10,
    ["%"]=10,
    [":"]=11,
}

NumberAlginment_Left    = 0x01
NumberAlginment_Right   = 0x02
NumberAlginment_Conter  = 0x03


GetNumberFile = function(v)
    return string.format("res/number/%s", v)
end

--------------------- 游戏道具按钮类
GameNumbers = {}
--这句是重定义元表的索引，必须要有，
GameNumbers.__index = GameNumbers
--模拟构造体，一般名称为new()
function GameNumbers:new(tpe, algin, interval, maxlenght)
    local self = {}   
    setmetatable(self, GameNumbers)   --必须要有
    
    --类型
    self.tpe = tpe
    --最大长度
    self.maxlenght = maxlenght
    --间隔
    self.interval = interval
    --对齐
    self.algin = algin
    --值
    self.value = 0
    --坐标
    self.pos = ccp(0,0)

    self.color = ccc3(255,255,255)
    
    if self.maxlenght == nil then
        self.maxlenght = 10
    end
    if self.interval == nil then
        self.interval = 0
    end
    if self.algin == nil then
        self.algin = NumberAlginment_Conter
    end
    
    self._scale = 1.0
    
    self._batchNode = CCSpriteBatchNode:create(GetNumberFile(self.tpe), self.maxlenght)
    self._batchNode:setPosition(ccp(0,0))
    
    self._spw = NumberTables[self.tpe].w
    self._sph = NumberTables[self.tpe].h
    
    self._numbers = {}
    for i=1, self.maxlenght do 
        --local sp = CCSprite:createWithTexture(self._batchNode:getTexture(), CCRectMake(0, 0, _spw, _sph))
        --self._batchNode.addChild(sp)
        table.insert(self._numbers, nil)
    end
    
    return self  
end

function GameNumbers:addLayer(layer, z, tag)
    if z == nil then
        z = 0
    end
    if tag == nil then
        tag = -1
    end
    layer:addChild(self._batchNode, z, tag)
end

function GameNumbers:setPosition(pos)
    self.pos = pos
    self._batchNode:setPosition(pos)
    
    self:Update()
end

function GameNumbers:setVisible(v)
    -- body
    self._batchNode:setVisible(v)
end

function GameNumbers:setNumber(v)
    self.value = v
    self:Update()
end

function GameNumbers:setString(v)
    self.value = v
    self:Update()
end

function GameNumbers:setAlginment(algin)
    self.algin = algin
    self:Update()
end

function GameNumbers:Update()
    local snum = self.value
    if type(self.value) == number then
        snum = string.format("%d",self.value)
    end
    local slenght = string.len(snum)
    local bpx = 0
    local bpy = 0
    if self.algin == NumberAlginment_Left then
        
    elseif self.algin == NumberAlginment_Right then
        bpx = -(slenght * self._spw + (slenght - 1) * self.interval)
    elseif self.algin == NumberAlginment_Conter then
        bpx = -(slenght * self._spw + (slenght - 1) * self.interval)
        bpx = bpx / 2
    end
    
    local x = bpx - self._spw / 2
    local y = bpy
    
    local dijian = 0 --递减(遇到半个字符时
    for k=1, self.maxlenght do
        
        local s = string.sub(snum,k,k)
        if self._numbers[k] ~= nil then
            self._batchNode:removeChild(self._numbers[k], true)
            self._numbers[k] = nil
        end
        
        if k <= slenght then
            if s == ":" then
                dijian = dijian + self._spw / 2
            end
            
            local sp = CCSprite:createWithTexture(self._batchNode:getTexture(), CCRectMake(_NumberIndex[s] * self._spw, 0, self._spw, self._sph))
            sp:setPosition(ccp(x + k * (self._spw + self.interval) - dijian, y))
            --sp:setAnchorPoint(ccp(0.5, 0.5))
            self._batchNode:addChild(sp)
            self._numbers[k] = sp

            sp:setColor(self.color)
        end
    end
end

function GameNumbers:setColor(color)
    self.color = color
    table.foreach(self._numbers, function(k,v)
        if v ~= nil then
            v:setColor(self.color)
        end
    end)
end
function GameNumbers:setScale(value)
    self._batchNode:setScale(value)
end

function GameNumbers:getWidth()
    local snum = self.value
    if type(self.value) == number then
        snum = string.format("%d",self.value)
    end
    local slenght = string.len(snum)
    
    return slenght * (self._spw + self.interval)
end
function GameNumbers:getHeight()
    return self._sph
end









