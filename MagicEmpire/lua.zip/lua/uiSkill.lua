---uiSKill

---角色使用技能
function GFuncFightUseSkill(args)
  	local taglist = {}
    local tagtype = 1
    ---{crole=gPlayerTables[_rid], mlist=gMonsterTables, hpbar=progressHp, func}
    local function effRunEnd()
        local rtaglist = {}
        if tagtype == 1 then
            rtaglist = taglist
        end
        if args.func then
            args.func(rtaglist)
        end
    end
    local _skill = args.crole.skill
    --local testsk = {}
   	-- _skill = rand(1,#testsk)

    --技能特效,
    if _skill then
        --获取技能信息
        local skinfo = SkillTables_Static[_skill]
        local artloop = skinfo.artloop
        tagtype = skinfo.single
        if artloop == nil then
        	artloop = 1
        end
    	--获得目标
    	if skinfo.single == 1 then --单个敌人
    		--随机一个目标
    		table.insert(taglist, args.mlist[rand(1,#args.mlist)])
    	elseif skinfo.single == 3 then -- 玩家
    		table.insert(taglist, args.player)
    	elseif skinfo.single == 4 then --施法勇者
    		table.insert(taglist, args.crole)
            --print("添加勇者",args.crole)
    	else
    		taglist = args.mlist
    	end

    	local _effargs = {skinfo=skinfo, taglist=taglist, crole=args.crole, func=function()
    		effRunEnd()
    	end}

    	--特效结束
    	local function effonend()
    		---执行效果
    		GFuncFightSkillEff(_effargs)
    		--特效结束
    		--effRunEnd()
    	end

        ----释放特效
        local anim = nil
        --特殊特效
        if skinfo.id == 13 then
            ---闪避效果
            GFuncFightSkillEff_Dodge(args.player, effonend)
        elseif skinfo.art == "eff_fire" or skinfo.art == "eff_sword" then
        	GFuncFightSkillEff_Fire(skinfo, effonend)
        elseif skinfo.art == "jiagong" then
            anim = GFuncFightSkillEff_AddUp(skinfo, effonend)
        elseif skinfo.art == "jingbi_xiaoguo" then
            GFuncFightSkillEff_Treat(skinfo, effonend)
        elseif skinfo.art then
        	anim = GFunc_CreateAnimation(skinfo.art.."_", 1, 10, artloop, 0.1, effonend, 3)
        else
            effonend()
       	end

        if anim then
            local x, y = 0,0
           	if skinfo.single == 1 then --单体
           		for _k, _moster in pairs(taglist) do
           			x, y = _moster:getPosition().x, _moster:getPosition().y
           			if skinfo.art == "hanbing" then
           				y = y + anim:getContentSize().height/2-50
           			else
            			y = y + anim:getContentSize().height/2-20
            		end
            	end
            elseif skinfo.single == 4 then --勇者
            	x, y = args.crole._parent:getPosition()
            elseif skinfo.single == 3 then --玩家
            	x, y = DWinSize.width/2,780
            else --所有
            	x, y = DWinSize.width/2,780
            end

            if anim then
            	CCDirector:sharedDirector():getRunningScene():addChild(anim)
            	anim:setPosition(ccp(x,y))
            end
        end
    else
        effRunEnd()
    end
end
SkillType_Hurt	= 0x01 --伤害
SkillType_Health	= 0x02 --恢复(玩家)
SkillType_Poison	= 0x04 --中毒
SkillType_Avoid	= 0x05 --闪避(玩家)
SkillType_Sleep	= 0x06 --睡觉(晕)
SkillType_AddUp 	= 0x07 --增加攻击力(勇者)

---各BUFF与图标
GTableBuffIcon = {
	[SkillType_Poison] = "buff_poison.png",
	[SkillType_Avoid] = "buff_avoid.png",
	[SkillType_Sleep] = "buff_sleep.png",
	[SkillType_AddUp] = "buff_atk.png",
}


--受到伤害
local function GSKillEff_Hurt(args)
	local function endfunc()
		--print("播放结束")
		if args.func then
			args.func()
		end
	end

	--伤害值-勇者攻击*skinfo.value
	for k, mon in pairs(args.taglist) do
		local value = args.crole.atk * args.skinfo.value

		local _func = nil
		--print(#args.taglist, k)
		if k == #args.taglist then
			_func = endfunc
		end
        value = GFuncGameValueFloat(value, 0.05)
		mon:onHurt(value, _func)
	end
end
--受到治疗
local function GSKillEff_Treat(args)
    local function endfunc()
        if args.func then
            args.func()
        end
    end
    --伤害值-勇者攻击*skinfo.value
    for k, mon in pairs(args.taglist) do
        local value = mon.hpmax * (args.skinfo.value / 100.0)

        local _func = nil
        if k == #args.taglist then
            _func = endfunc
        end
        mon:onTreat(value, _func)
    end
end
--目标中毒
local function GSKillEff_Poison(args)
	local function endfunc()
		if args.func then
			args.func()
		end
	end
	--生命值的百分比
	for k, mon in pairs(args.taglist) do
		local vhurt = args.skinfo.value/100 * mon.hp
		--print(mon.hp, args.skinfo.value, args.skinfo.value/100.0)
		local _func = nil
		if k == #args.taglist then
			_func = endfunc
		end
		mon:onHurt(vhurt, _func)
	end
end

local GTableSkillEffs = {
	[SkillType_Hurt] = GSKillEff_Hurt,
	[SkillType_Poison] = GSKillEff_Poison,
    [SkillType_Health] = GSKillEff_Treat,
}
---执行特效结果效果
function GFuncFightSkillEff(args)
	-- body
	if GTableSkillEffs[args.skinfo.eff] then
		GTableSkillEffs[args.skinfo.eff](args)
	else
		if args.func then
			args.func()
		end
	end

	--初始命中(有施法目标说明是使用时,不是使用时则不添加buff)
    --print("添加buff",args.crole , args.skinfo.round, #args.taglist)
	if args.crole and args.skinfo.round then
		for k,mon in pairs(args.taglist) do
			--添加buff
			mon:addbuff(args.skinfo)
		end
	end
end





------------
---特殊效果
function GFuncFightSkillEff_Fire(skinfo, func)
	local _parent = CCNode:create()
	CCDirector:sharedDirector():getRunningScene():addChild(_parent)

    local _visitNodeParent = GFunc_CreateLayerVisit(_parent, DWinSize.width, DWinSize.height - 628, 0, 628)
    --_visitNodeParent:addChild()

    local function effFireEndV()
    	if func then
    		func()
    	end
    end
    --结束
    local function effFireEnd()
    	CCDirector:sharedDirector():getRunningScene():removeChild(_parent, true)
    end



    local efflist = {}
    --持续时间
    local arttime = 1.0
    local barttime = 0
    --密集度(个/秒)
    local artsum = 50.0
    --资源
    local art = skinfo.art

    local iscreate = true
    local function endCreate()
    	if barttime > arttime then
	    	if iscreate then
	    		iscreate = false
	    		--effFireEndV()
	    	end
    	end
    end

    local effIndex = 0
    local effdelsum = 0
    local function funcMoveEnd(obj)
    	GFunc_RemoveChild(efflist[obj:getTag()])
    	efflist[obj:getTag()] = nil
    	--if not iscreate and #efflist == 0 then
        --	effFireEnd()
        --end
        effdelsum = effdelsum + 1
        if effdelsum == effIndex then
        	effFireEnd()
        end

        if effdelsum == 1 then
        	effFireEndV()
        end
    end

    local lastPy = 0
  	local sfile = art..".png"
   	local sprite = CCSprite:createWithSpriteFrameName(sfile)
   	lastPy = 550 - sprite:getContentSize().height

    --出现间隔,下个时间
    local _stime = 1.0/artsum
    local _lstime = 0
    local function updateEff(dt)
    	barttime = barttime + dt

    	endCreate()

    	_lstime = _lstime + dt
        if iscreate and _lstime > _stime then
        	effIndex = effIndex + 1
            local x = rand(30, DWinSize.width - 30)
            local y = DWinSize.height--rand(0,)
            local sprite = CCSprite:createWithSpriteFrameName(sfile)
            sprite:setAnchorPoint(ccp(0.5,0))
            sprite:setPosition(ccp(x,y))
            sprite:setTag(effIndex)
            _visitNodeParent:addChild(sprite,1)
            efflist[effIndex] = sprite
            --Tag为速度
            --sprite:setTag(math.random(300,500))
            local action = CCMoveTo:create(0.6, ccp(x, 530))
            local sq = CCSequence:createWithTwoActions(action, CCCallFuncN:create(funcMoveEnd))
            sprite:runAction(sq)

            _lstime = 0
        end
    end

    local function update(dt)
    	----更新所有效果
    	updateEff(dt)
    end
    local _layertime = GFunc_CreateLayerEnterOrExit({update=update})
    _parent:addChild(_layertime)
end
---------加攻
function GFuncFightSkillEff_AddUp(skinfo, func)
    local function endfunc()
        if func then
            func()
        end
    end

    ---
    local parent = CCNode:create()
    local sp = CCSprite:createWithSpriteFrameName("jiagong_001.png")
    sp:setAnchorPoint(ccp(0.5,0))
    sp:setPosition(ccp(0,-30))
    sp:setScale(0.2)
    --放大
    local sq = CCSequence:createWithTwoActions(CCScaleTo:create(0.3, 1.1), CCCallFuncN:create(function()
        --重影
        local spc = CCSprite:createWithSpriteFrameName("jiagong_001.png")
        spc:setOpacity(180)
        spc:setScale(1.1)
        spc:setPosition(ccp(0,0))
        spc:setAnchorPoint(ccp(0.5,0.33))
        parent:addChild(spc)

        local array = CCArray:create()
        array:addObject(CCScaleTo:create(0.3, 1.8))
        array:addObject(CCScaleTo:create(0.3, 1.0))
        local sqe = CCSequence:create(array)
        spc:runAction(CCSequence:createWithTwoActions(sqe, CCCallFunc:create(function()
            --消失
            spc:runAction(CCFadeOut:create(0.3))
            sp:runAction(CCSequence:createWithTwoActions(CCFadeOut:create(0.5), CCCallFunc:create(endfunc)))
        end)))
    end))
    sp:runAction(sq)

    parent:addChild(sp,2)

    return parent
end

---------闪避
function GFuncFightSkillEff_Dodge(player, func)
    
    local parent = CCNode:create()
    local function endfunc()
        GFunc_RemoveChild(parent)

        if func then
            func()
        end
    end

    ---

    local pxbegin = 10
    local pxend = DWinSize.width-10
    local gsetpos = ccp(pxbegin, 550)
    local psum = 2 --回来数
    local pindex = 0
    local function update(dt)
        --左右移动一个坐标点
        if pindex % 2 == 0 then
            gsetpos = ccp(gsetpos.x + dt*800, gsetpos.y)
            if gsetpos.x >= pxend then
                gsetpos.x = pxend
                pindex = pindex + 1
            end
        else
            gsetpos = ccp(gsetpos.x - dt*800, gsetpos.y)
            if gsetpos.x <= pxbegin then
                gsetpos.x = pxbegin
                pindex = pindex + 1
            end
        end

        local showsum = rand(1,4)

        --for k=1,showsum do
            ---散落星星
            local spos = ccp(rand(gsetpos.x-20, gsetpos.x+20), rand(gsetpos.y-10, gsetpos.y+10))
            local stsp = CCSprite:createWithSpriteFrameName("jingbi_xiaoguo_001.png")
            stsp:setPosition(spos)
            CCDirector:sharedDirector():getRunningScene():addChild(stsp,15)

            ---向下落并消失
            stsp:runAction(CCMoveBy:create(0.4, ccp(0,-30)))
            stsp:runAction(CCSequence:createWithTwoActions(CCFadeOut:create(0.4), CCCallFuncN:create(function(tag)
                GFunc_RemoveChild(tag)
            end)))
        --end

        if pindex >= psum then
            ---结束
            endfunc()
        end
    end
    --player.progressHp._progress_sp:setOpacity(100)
    --------血条透明化
    --player.progressHp._prosp:runAction(CCFadeTo:create(1.0, 100))

    local templayer = GFunc_CreateLayerEnterOrExit({update=update})
    parent:addChild(templayer)

    CCDirector:sharedDirector():getRunningScene():addChild(parent)
end

function GFuncFightSkillEff_Treat(skinfo, func)
    local function endfunc()
        if func then
            func()
        end
    end
    endfunc()
end