-----出征界面
local _GFuncInterfaceCloseGoFight = nil
function GFuncInterfaceCloseGoFight()
    if _GFuncInterfaceCloseGoFight then
        _GFuncInterfaceCloseGoFight()
    end
end
local _GFuncInterfaceCloseSelectRole = nil
function GFuncInterfaceCloseSelectRole()
    if _GFuncInterfaceCloseSelectRole then
        _GFuncInterfaceCloseSelectRole()
    end
end

-----------显示地区地图
GameAreaMapClass = {}
GameAreaMapClass.__index = GameAreaMapClass
---
function GameAreaMapClass:new()
    local self = {}
    setmetatable(self, GameAreaMapClass)

    self._parent = GFunc_CreateLayerEnterOrExit({update=function(dt)self:update(dt)end,fps=1.0/30})

    self.spbg = CCSprite:createWithSpriteFrameName("map_007.png")
    self.spbg:setAnchorPoint(ccp(0,0))
    self.spbg:setPosition(ccp(0,0))
    self._parent:addChild(self.spbg)

    --底背景sp
    self.spbgpv = CCScale9Sprite:createWithSpriteFrameName("jiemian_117.png", CCRectMake(640, 30, 0, 20))
    self.spbgpv:setContentSize(CCSizeMake(640, DWinSize.height - self.spbg:getContentSize().height))
    self.spbgpv:setAnchorPoint(ccp(0,1))
    self.spbgpv:setPosition(ccp(0,0))
    self._parent:addChild(self.spbgpv)

    --城堡
    self.citybg = CCSprite:createWithSpriteFrameName("jiemian_167.png")
    --self.citybg:setScale(0.3)
    self._parent:addChild(self.citybg,1)

    self._showGotoMapNew = false
    self._showGotoMap = false
    self._gotoMap = 0

    --显示所有已经开放的地区的位置 map_008 map_009
    for mid, v in pairs(PlayerInfos:getOpenAreas()) do
        local info = MapArea_Static[mid]
        local pos = lua_string_split(info.posmap, ",")
        local x = pos[1] + 0
        local y = pos[2] + 0
        local sfile = "map_009.png"
        --if info.id == PlayerInfos.mapID then
        --    sfile = "map_008.png"
        --end
        local possp = CCSprite:createWithSpriteFrameName(sfile)
        possp:setPosition(ccp(x,y))
        self._parent:addChild(possp)
    end

    --显示当前玩家所有位置 /去往某地的途中,在某地
    self.tipDashed = nil

    self._parent:setPosition(ccp(0, DWinSize.height-self.spbg:getContentSize().height))

    self:update()

    return self
end
function GameAreaMapClass:addParent(parent)
    -- body
    parent:addChild(self._parent)
end
function GameAreaMapClass:update(dt)
    self:gotoArea()
end
function GameAreaMapClass:hideGotoMap()
    self._showGotoMap = false
    self._showGotoMapNew = false
    self._gotoMap = nil
end
function GameAreaMapClass:GotoTemp(mid)
    if self._gotoMap ~= mid then
        self._showGotoMap = true
        self._showGotoMapNew = true
        self._gotoMap = mid
    end
end
--显示前往另一个地方的指示效果
function GameAreaMapClass:gotoArea()
    local function removeTipDashedAndCreate(pos1, pos2)
        if self.tipDashed then
            self._parent:removeChild(self.tipDashed._parent, true)
            self.tipDashed = nil
        end
        if pos1 and pos2 then
            self.tipDashed = GameDashedDynamic:new("res/dashed.png", 18, pos1, pos2)
            self._parent:addChild(self.tipDashed._parent)
        end
    end

    if self._showGotoMap and self._gotoMap ~= PlayerInfos.mapID then
        if self._showGotoMapNew or PlayerInfos.mapID == GMoveMapStatus then
            self._showGotoMapNew = false
            --获得两地的坐标
            local pos = PlayerInfos:getInMapPos()
            local pos1 = ccp(pos[1]+0, pos[2]+0)
            local pos = lua_string_split(MapArea_Static[self._gotoMap].posmap, ",")
            local pos2 = ccp(pos[1]+0, pos[2]+0)

            removeTipDashedAndCreate(pos1, pos2)
        end
    elseif PlayerInfos.mapID == GMoveMapStatus then
        --获得两地的坐标
        local pos = PlayerInfos:getInMapPos()
        local pos1 = ccp(pos[1]+0, pos[2]+0)
        local pos = lua_string_split(MapArea_Static[PlayerInfos.mapGoto].posmap, ",")
        local pos2 = ccp(pos[1]+0, pos[2]+0)

        removeTipDashedAndCreate(pos1, pos2)
    else
        removeTipDashedAndCreate()
    end

    local pos = PlayerInfos:getInMapPos()
    self.citybg:setPosition(ccp(pos[1]+0, pos[2]+0))
end



--获得当前所有地图的所有出击任务
local function getAreaTanks()
    --
    local infos = {}
    --所在地区已开启且未完成任务
    --当前地区已接受的附加战斗任务/移动任务?/运送任务?/发现地区任务?
    for _tid, v in pairs(PlayerInfos.acceptTasks) do
        local info = GFuncGetTaskForID(_tid)
        --if info.type == GTaskType_Fight or info.type == GTaskType_Moved
        --table.insert(infos, {type=info.type, info=info})

        ---平叛点战斗任务不需要
        if info.type == GTaskType_Fight and info.param ~= nil or info.type == GTaskType_Build or info.type == GTaskType_Agree
            or info.type == GTaskType_Yanjiu or info.type == GTaskType_AddShop then

        else
            table.insert(infos, {type=info.type, info=info})
        end
    end

    --地区平叛任务
    local areaPlaces = GFuncGetAllPlace(PlayerInfos.mapID)
    for k=1, 10 do
        local info = areaPlaces[k]
        if info then
            --2以后的平叛点必须等其平叛点打开
            if k > 1 and not GFuncGetPlaceFinsh(areaPlaces[k-1].id) then
                break
            end
            table.insert(infos, {type=nil, info=info})
        else
            break
        end
    end

    return infos
end

local reloaddata = nil
function GFunc_GotoFightMpaRefsh()
    if reloaddata then
        reloaddata()
    end
end
--------出击目标
function createLayerGoFight(endfunc)
    GGameShowInterface = GGameInterface_GoFight
    
    local layer = nil
    local _container = nil
    local btnTables = {}
    local btnContainerTables = {}

    local beginPickY = 0
    local function touchContainer(x,y,eventType)
        local isclick = false
        if eventType == CCTOUCHENDED and (y >= 70 and y <= 635) and math.abs(beginPickY-y) < 20 then
            isclick = true
        end
        local _mx, _my = _container:getPosition()
        GFunc_SelectBtnRun(btnContainerTables,x-_mx,y-_my-70,eventType, isclick)
        if (y >= 70 and y <= 635) then
            _container:onTouch(x,y,eventType)
        end
    end

    local function touchBegin(x,y,eventType)
        beginPickY = y
        touchContainer(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x,y,eventType)
    end
    local function touchMoved(x,y, eventType)
        touchContainer(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x,y,eventType)
    end
    local function touchEnded(x,y,eventType)
        touchContainer(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x,y,eventType)
    end
    local function exitlayer()
        reloaddata = nil
    end

    layer = GFunc_CreateLayerEnterOrExit({color=ccc4(255,255,255,255), exfunc=exitlayer, touchBegin=touchBegin, touchMoved=touchMoved, touchEnded=touchEnded, fmbg = true})
    --CCDirector:sharedDirector():getRunningScene():addChild(layer)
    ----------
    --layer = GFunc_CreateLayerEnterOrExit({color=ccc4(93,139,69,255)})

    _GFuncInterfaceCloseGoFight = function()
        if endfunc then
            endfunc()
        end
        CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
        _GFuncInterfaceCloseGoFight = nil
        layer = nil
    end


    ---菜单按钮
    local menu = CCMenu:create()
    menu:setPosition(ccp(0,0))

    ---地图
    local gmaps = GameAreaMapClass:new()
    gmaps:addParent(layer)

    local layerbg3 = CCNode:create()
    layerbg3:setPosition(ccp(0,70))
    layer:addChild(layerbg3)

    ---出击任务列表
    --遮罩
    local _nodeParentLayerVisit = GFunc_CreateLayerVisit(layerbg3, DWinSize.width, 560, 0, 0)
    --排列容器
    _container = GameSildeContainer:new(0, 0, SildeContainer_UpDown)
    _container:addToLayer(_nodeParentLayerVisit)
    --_nodeParentLayerVisit:addChild(menu,1)

    --列出项目
    local _taskInfos = {}
    local function clickItem(tag)
        local _vinfo = _taskInfos[tag]
        local _type = _vinfo.type
        local info = _vinfo.info
        local moveMapID = info.mid

        --移动类的目的地为param参数
        if _type == GTaskType_Moved or _type == GTaskType_Area then
            moveMapID = info.param
        end
        --print(moveMapID, _type, info.param)

        if PlayerInfos.mapID ~= moveMapID then
            layer:setTouchEnabled(false)
            local function _closeDialog(_args)
                layer:setTouchEnabled(true)
                if _args.enter then
                    if PlayerInfos.mapID == GMoveMapStatus then
                        layer:setTouchEnabled(false)
                        local smsg = string.format("正在向 [%s] 移动，请不要着急",MapArea_Static[PlayerInfos.mapGoto].name)
                        GFunc_ShowGameDialogMessage({msg=smsg, func=function() layer:setTouchEnabled(true) end})
                    else
                        gmaps:hideGotoMap()
                        PlayerInfos:moveToArea(moveMapID)

                        GFunc_GotoFightMpaRefsh()
                    end
                end
            end
            GFunc_ShowDialogEnterClance({msg=string.format("是否向 [%s] 移动？",MapArea_Static[moveMapID].name), func=_closeDialog})
            gmaps:GotoTemp(moveMapID)
            return
        elseif PlayerInfos.mapID ~= GMoveMapStatus then
            gmaps:hideGotoMap()
        end

        if _type == nil or _type == GTaskType_Fight then
            layer:setVisible(false)
            layer:setTouchEnabled(false)
            createLayerGoSelectFight(info, function()
                layer:setVisible(true)
            layer:setTouchEnabled(true)
            end)
        elseif _type == GTaskType_Moved then
            if PlayerInfos.mapID ~= info.mid then
                --GFunc_ShowDialogEnterClance("")
                --GFunc_ShowGameDialogMessage
            end
        elseif _type == GTaskType_Express then
        elseif _type == GTaskType_Area then
        end
    end

    GFuncTutorialGoSelect = clickItem

    local _parentItems = nil
    local menuItem = nil
    reloaddata = function()
        _taskInfos = getAreaTanks()

        if _parentItems ~= nil then
            _container:removeChild(_parentItems)
        end

        _parentItems = CCNode:create()

        menuItem = CCMenu:create()
        menuItem:setPosition(ccp(0,0))
        _parentItems:addChild(menuItem)

        _container:addElementChild(_parentItems)
        btnContainerTables = {}

        local index = 0
        local inv = 66
        local psum = 8
        for k,_vinfo in pairs(_taskInfos) do
            local _type = _vinfo.type
            local info = _vinfo.info
            local btnItem = GFunc_CreateButtonLabel("", clickItem, nil, CCSizeMake(DWinSize.width, inv))
            btnItem:setPosition(ccp(DWinSize.width/2, 510 - inv * (k-1)))
            menuItem:addChild(btnItem, 0, k)
            table.insert(btnContainerTables, btnItem)
            --背景
            local color = nil
            if index % 2 == 0 then
                color = ccc4f(206/255.0,221/255.0,106/255.0,1)
            else
                color = ccc4f(250/255.0,245/255.0,170/255.0,1)
                local stencil = CCSprite:createWithSpriteFrameName("jiemian_137.png")
                stencil:setPosition(ccp(DWinSize.width/2, inv/2))
                btnItem:addChild(stencil)
            end
            index = index + 1
    
            --local stencil = CCDrawNode:create()
            --stencil:drawSegment(ccp(-DWinSize.width/2,0), ccp(DWinSize.width,0), inv/2, color)
            --stencil:setPosition(ccp(DWinSize.width/2, inv/2))
            --btnItem:addChild(stencil)
    
            --类型
            local strType = "清除叛党"
            if _type == GTaskType_Fight then
                strType = "战斗"
            elseif _type == GTaskType_Moved then
                strType = "移动"
            elseif _type == GTaskType_Express then
                strType = "运送"
            elseif _type == GTaskType_Area then
                strType = "新地区"
            elseif _type == GTaskType_Greed then

            end
            local txttype = CCLabelTTF:create(strType, "Arial", 26)
            txttype:setAnchorPoint(ccp(0,0.5))
            txttype:setColor(ccc3(109,121,32))
            txttype:setPosition(ccp(10, inv/2+10))
            btnItem:addChild(txttype)
    
            local sp = CCLabelTTF:create(info.name, "Arial", 30)
            sp:setAnchorPoint(ccp(0,0.5))
            sp:setColor(ccc3(93,139,69))
            btnItem:addChild(sp)

            if _type == GTaskType_Fight then
                txttype:setColor(ccc3(255,0,0))
                sp:setColor(ccc3(255,0,0))
            end
    
            if _type then
                sp:setPosition(ccp(100, inv/2))
            else
                sp:setPosition(ccp(150, inv/2))
                --未完成的任务后面显示new
                if info.fight_sum <= 0 then
                    --local sp = CCLabelTTF:create("new", "Arial", 30)
                    local sp = CCSprite:createWithSpriteFrameName("jiemian_166.png")
                    sp:setAnchorPoint(ccp(0,0.5))
                    --sp:setColor(ccc3(244,185,41))
                    sp:setPosition(ccp(DWinSize.width-80,inv/2))
                    btnItem:addChild(sp)
                end
            end

            ---战斗需要消耗费用
            if _type == nil or _type == GTaskType_Fight then
                local txtmoney = CCLabelTTF:create(info.money or 0, "Arial", 30)
                txtmoney:setAnchorPoint(ccp(1,0.5))
                txtmoney:setPosition(ccp(DWinSize.width/1.3, inv/2))
                txtmoney:setColor(ccc3(135,88,32))
                btnItem:addChild(txtmoney)

                local spbg = CCSprite:createWithSpriteFrameName(SIconMoney)
                spbg:setAnchorPoint(ccp(0,0.5))
                spbg:setPosition(ccp(DWinSize.width/1.28, inv/2))
                btnItem:addChild(spbg)
            end
        end
        _container:setSize(nil, inv*index- psum *inv)
        --print(inv*index- psum *inv)
    end
    reloaddata()



    --返回
    local menuBack = CCMenu:create()
    menuBack:setPosition(ccp(0,0))
    layer:addChild(menuBack)
    local btnItem = GFunc_CreateButtonP("jiemian_002.png", function()
        _GFuncInterfaceCloseGoFight()
    end, nil, 1.5)
    btnItem:setPosition(ccp(DWinSize.width - 40, 35))
    menuBack:addChild(btnItem)
    table.insert(btnTables, btnItem)

    ---移动++++
    local btnEnterItem = GFunc_CreateButtonP("jiemian_111.png",function()
        ---打开移动界面
        layer:setVisible(false)
        layer:setTouchEnabled(false)
        createLayerMoveArea(function()
            layer:setVisible(true)
            layer:setTouchEnabled(true)
        end)
    end)
    btnEnterItem:setPosition(ccp(70, 670))
    menuBack:addChild(btnEnterItem)
    table.insert(btnTables, btnEnterItem)

    CCDirector:sharedDirector():getRunningScene():addChild(layer)
end
--------选择出击
--fInfos:战斗信息
function createLayerGoSelectFight(fInfos, endfunc)
    local layer = nil
    
    _GFuncInterfaceCloseSelectRole = function()
        if endfunc then
            endfunc()
        end
        CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
        _GFuncInterfaceCloseSelectRole = nil
    end
    ----------
    layer = GFunc_CreateLayerEnterOrExit({color=ccc4(255,255,255,255)})

    ---菜单按钮
    local menu = CCMenu:create()
    menu:setPosition(ccp(0,0))
    layer:addChild(menu,1)
    ------------

    ---地图
    local gmaps = GameAreaMapClass:new()
    gmaps:addParent(layer)

    --底背景sp
    local spbg = CCSprite:createWithSpriteFrameName("jiemian_118.png")
    spbg:setAnchorPoint(ccp(0,0))
    spbg:setPosition(ccp(0,0))
    layer:addChild(spbg)
    

    ---状态属性
    --玩家属性
    local spbg = CCSprite:createWithSpriteFrameName("jiemian_115.png")
    spbg:setAnchorPoint(ccp(0.5, 1))
    spbg:setPosition(ccp(320, DWinSize.height - 365))
    layer:addChild(spbg)
    ---玩家信息显示
    local sppyinfo = GCreatePlayerProperty()
    sppyinfo:setPosition(ccp(30, 260))
    spbg:addChild(sppyinfo)

    --出击成员bg
    local spbg = CCSprite:createWithSpriteFrameName("jiemian_116.png")
    spbg:setPosition(ccp(DWinSize.width/2, 160))
    layer:addChild(spbg)


    --出击成员sp
    local spbg = CCSprite:createWithSpriteFrameName("jiemian_053.png")
    spbg:setPosition(ccp(130,260))
    layer:addChild(spbg)

    ---出击成员预览
    ----所有当前已经设置的出击角色
    local createMyRoles = nil
    local _menuRoles = nil
    createMyRoles = function()
        local proles = PlayerInfos:getMyUseAidPlayer()
        if _menuRoles then
            layer:removeChild(_menuRoles, true)
        end
        _menuRoles = CCMenu:create()
        _menuRoles:setPosition(ccp(0,0))
        layer:addChild(_menuRoles)

        for k=1,4 do
            local rpinfo = proles[k]
    
            local btnItem = nil
            local function changepycallback(tag)
                --点击更换角色
                layer:setVisible(false)
                createLayerSelectPlayer({change=proles[tag]}, function(changePlayer)
                    layer:setVisible(true)
                    --更换的角色
                    --更换当前按钮信息
                    if changePlayer then
                        --changePlayer
                        PlayerInfos:setUseAidPlayer(tag, changePlayer.id)
                        --重新生成列表
                        createMyRoles()
                    end
                end)
            end

            --名字sp
            if rpinfo then
                local newHead = createRoleIcon(rpinfo, changepycallback)
                btnItem = newHead.btn
                newHead.spname:setPosition(ccp(220,15))
                newHead.tname:setPosition(ccp(220,15))
            else
                --头像
                btnItem = GFunc_CreateButtonP("jiemian_055.png", changepycallback)
            end
            btnItem:setPosition(ccp(110 + ((k-1)%2)*300, 195 - (math.floor((k-1)/2)) * 90))
            _menuRoles:addChild(btnItem, 0, k)
        end
    end
    createMyRoles()

    --返回
    local btnItem = GFunc_CreateButtonP("jiemian_002.png", function()
        _GFuncInterfaceCloseSelectRole()
    end, nil, 1.5)
    btnItem:setPosition(ccp(DWinSize.width - 40, 35))
    menu:addChild(btnItem)


    GFuncTutorialGoFight = function()
        layer:setVisible(false)

        --关闭界面
        GFuncInterfaceCloseSelectRole()
        GFuncInterfaceCloseGoFight()

        ---判断是否有足够的金钱,并扣除
        local fmoney = fInfos.money or 0
        if fmoney > PlayerInfos:getMoney() then
            --没有足够的金钱
            GFunc_ShowGameDialogMessage({msg="王子陛下!支付出征费用的金币不足啊~"})
        else
            PlayerInfos:addMoney(-fmoney)
        end
        --得到相关任务的数据信息
        createLayerFight(fInfos, function()
            --layer:setVisible(true)
        end)
    end

    ---出击按钮
    local btnItem = GFunc_CreateButtonP("jiemian_120.png", GFuncTutorialGoFight)
    btnItem:setPosition(ccp(DWinSize.width-170, 350))
    menu:addChild(btnItem)
    ---出征
    
    CCDirector:sharedDirector():getRunningScene():addChild(layer)
end

---------成员选择界面
function createLayerSelectPlayer(args, endfunc)
    local layer = nil
    --当前选择的角色
    local changeRPinfo = args.change
    local btnTables = {}
    local btnItemTables = {}
    
    --显示选择成员的信息
    local selectPlayer = changeRPinfo
    local _parentInfo = nil
    local alllRoleIems = {}
    ----------
    layer = GFunc_CreateLayerEnterOrExit({color=ccc4(255,255,255,255)})

    local function closeFunc(args)
        if endfunc then
            endfunc(args)
        end
        CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
    end

    ---菜单按钮
    local menu = CCMenu:create()
    menu:setPosition(ccp(0,0))
    layer:addChild(menu,1)

    ---地图
    local gmaps = GameAreaMapClass:new()
    gmaps:addParent(layer)

    --选择成员sp
    local spbg = CCSprite:createWithSpriteFrameName("jiemian_058.png")
    spbg:setPosition(ccp(105,410))
    layer:addChild(spbg)

    local spbg = CCSprite:createWithSpriteFrameName("jiemian_123.png")
    spbg:setPosition(ccp(320, 525))
    layer:addChild(spbg)

    --成员信息sp
    local spbg = CCScale9Sprite:createWithSpriteFrameName("jiemian_121.png", CCRectMake(20, 20, 20, 30))
    spbg:setContentSize(CCSizeMake(640, 340))
    spbg:setPosition(ccp(320, 220))
    layer:addChild(spbg)


    --遮罩
    local _nodeParentLayerVisit = GFunc_CreateLayerVisit(layer, 640, 340, 0, 50)
    --排列容器
    local _container = GameSildeContainer:new(0, 0, SildeContainer_UpDown)
    _container:addToLayer(_nodeParentLayerVisit)
    local menuContainer = CCMenu:create()
    menuContainer:setPosition(ccp(0,0))
    _container:addChild(menuContainer)

    --通过点击间隔判断双击选择角色
    local lastclickTime = os.clock()
    local function showSelectInfo(pickPlayer)
        --同一角色二次选择
        if (os.clock() - lastclickTime) > 1 and selectPlayer and selectPlayer.id == pickPlayer.id then
            closeFunc(selectPlayer)
            return
        end
        selectPlayer = pickPlayer
        if _parentInfo then
            layer:removeChild(_parentInfo, true)
        end
        _parentInfo = CCNode:create()
        layer:addChild(_parentInfo)

        if selectPlayer then
            local newHead = createRoleIcon(selectPlayer)
            local spbg = newHead.btn
            spbg:setEnabled(false)
            spbg:setPosition(ccp(125, 550))
            _parentInfo:addChild(spbg)

            --技能描述
            local skdes = ""
            --if selectPlayer.skill then
            --    skdes = SkillTables_Static[selectPlayer.skill].des or ""
            --end
            if selectPlayer.des then
                skdes = selectPlayer.des--SkillTables_Static[info.skill].des or ""
            end

            --描述
            local txtn = CCLabelTTF:create(skdes, "Arial", 28, CCSizeMake(370, 125), kCCTextAlignmentLeft)
            txtn:setAnchorPoint(ccp(0,1))
            txtn:setColor(ccc3(0,0,0))
            txtn:setPosition(ccp(230,545))
            _parentInfo:addChild(txtn)

            --伤害
            local txtn = CCLabelTTF:create(string.format("攻击力:%d", selectPlayer.atk), "Arial", 32)
            txtn:setAnchorPoint(ccp(0,1))
            txtn:setColor(ccc3(255,44,50))
            txtn:setPosition(ccp(230,585))
            _parentInfo:addChild(txtn)

            --经验
            --local txtn = CCLabelTTF:create(string.format("经验值: %d / %d", selectPlayer.expsum, selectPlayer.expup), "Arial", 32)
            --txtn:setAnchorPoint(ccp(0,1))
            --txtn:setPosition(ccp(450,580))
            --_parentInfo:addChild(txtn)
        end

        --显示
        for k, _btnitem in pairs(alllRoleIems) do
            if selectPlayer and k == selectPlayer.id then
                setRoleIconEnabled(_btnitem, false)
            else
                setRoleIconEnabled(_btnitem, true)
            end
        end
    end

    ---可选择成员一览
    local proles = PlayerInfos:getAidPlayers()
    --print("数量:",table.getn(proles))
    local rpsum = 0
    for k, info in pairs(proles) do
        --头像
        local px, py = 100 + (rpsum%3)*220, 340 - 120 * math.floor(rpsum/3)
        local newHead = createRoleIcon(info, function(tag)
            showSelectInfo(proles[tag])
        end)
        local btnItem = newHead.btn
        btnItem:setPosition(ccp(px, py))
        table.insert(btnItemTables, btnItem)
        menuContainer:addChild(btnItem, 0, info.id)
        alllRoleIems[info.id] = newHead

        rpsum = rpsum + 1
    end
    _container:setSize(nil, math.ceil(rpsum/3) * 120-270)

    local function touchContainer(x,y,eventType)
        local isclick = true
        if eventType == CCTOUCHENDED and (y < 70 or y > 400) then
            isclick = false
        else
            _container:onTouch(x,y,eventType)
        end
        local mpx, mpy = _container:getPosition()
        GFunc_SelectBtnRun(btnTables,x,y,eventType)
        GFunc_SelectBtnRun(btnItemTables,x - mpx,y - mpy,eventType, isclick)

    end
    local function touchBegin(x,y,eventType)
        touchContainer(x,y,eventType)
    end
    local function touchMoved(x,y, eventType)
        touchContainer(x,y,eventType)
    end
    local function touchEnded(x,y,eventType)
        touchContainer(x,y,eventType)
    end
    _layerConfig = GFunc_CreateLayerEnterOrExit({touchBegin=touchBegin, touchMoved=touchMoved, touchEnded=touchEnded, fmbg=true})
    layer:addChild(_layerConfig)


    --返回
    local btnItem = GFunc_CreateButtonP("jiemian_002.png", function()closeFunc()end, nil, 1.5)
    btnItem:setPosition(ccp(DWinSize.width - 40, 35))
    table.insert(btnTables, btnItem)
    menu:addChild(btnItem)
    
    CCDirector:sharedDirector():getRunningScene():addChild(layer)


    showSelectInfo(selectPlayer)
end

--------显示地区移动界面
function createLayerMoveArea(endfunc)
    local layer = nil
    local _container = nil
    local btnTables = {}
    local btnContainerTables = {}

    local beginPickY = 0
    local function touchContainer(x,y,eventType)
        local isclick = false
        if eventType == CCTOUCHENDED and (y >= 70 and y <= 635) and math.abs(beginPickY-y) < 20 then
            isclick = true
        end
        local _mx, _my = _container:getPosition()
        GFunc_SelectBtnRun(btnContainerTables,x-_mx,y-_my-70,eventType, isclick)
        if (y >= 70 and y <= 635) then
            _container:onTouch(x,y,eventType)
        end
    end

    local function touchBegin(x,y,eventType)
        beginPickY = y
        touchContainer(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x,y,eventType)
    end
    local function touchMoved(x,y, eventType)
        touchContainer(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x,y,eventType)
    end
    local function touchEnded(x,y,eventType)
        touchContainer(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x,y,eventType)
    end

    layer = GFunc_CreateLayerEnterOrExit({color=ccc4(255,255,255,255), touchBegin=touchBegin, touchMoved=touchMoved, touchEnded=touchEnded, fmbg = true})

    local function closeInterface()
        if endfunc then
            endfunc()
        end
        CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
        layer = nil
    end
    ---地图
    local gmaps = GameAreaMapClass:new()
    gmaps:addParent(layer)

    local layerbg3 = CCNode:create()
    layerbg3:setPosition(ccp(0,70))
    layer:addChild(layerbg3)

    ---菜单按钮
    local menu = CCMenu:create()
    menu:setPosition(ccp(0,0))
    ------------

    ---已开启地图列表
    --遮罩
    local _nodeParentLayerVisit = GFunc_CreateLayerVisit(layerbg3, DWinSize.width, 560, 0, 0)
    --排列容器
    _container = GameSildeContainer:new(0, 0, SildeContainer_UpDown)
    _container:addToLayer(_nodeParentLayerVisit)

    local menuItem = CCMenu:create()
    menuItem:setPosition(ccp(0,0))
    _container:addElementChild(menuItem)


    local function clickItem(tag)
        local info = MapArea_Static[tag]
        moveMapID = tag

        if PlayerInfos.mapID ~= moveMapID then
            layer:setTouchEnabled(false)
            local function _closeDialog(_args)
                layer:setTouchEnabled(true)
                if _args.enter then
                    if PlayerInfos.mapID == GMoveMapStatus then
                        layer:setTouchEnabled(false)
                        local smsg = string.format("正在向 [%s] 移动，请不要着急",info.name)
                        GFunc_ShowGameDialogMessage({msg=smsg, func=function() layer:setTouchEnabled(true) end})
                    else
                        gmaps:hideGotoMap()
                        PlayerInfos:moveToArea(moveMapID)
                    end
                end
            end
            GFunc_ShowDialogEnterClance({msg=string.format("是否向 [%s] 移动？",info.name), func=_closeDialog})
            gmaps:GotoTemp(moveMapID)
            return
        elseif PlayerInfos.mapID ~= GMoveMapStatus then
            gmaps:hideGotoMap()
        end
    end

    --列出项目
    local _listInfos = PlayerInfos:getOpenAreas()
    local index = 0
    local inv = 66
    local psum = 8
    for k,_vinfo in pairs(_listInfos) do
        local info = MapArea_Static[k]

        local btnItem = GFunc_CreateButtonLabel("", clickItem, nil, CCSizeMake(DWinSize.width, inv))
        btnItem:setPosition(ccp(DWinSize.width/2, 510 - inv * (k-1)))
        menuItem:addChild(btnItem, 0, k)
        table.insert(btnContainerTables, btnItem)
        --背景
        local color = nil
        if index % 2 == 0 then
            --color = ccc4f(206/255.0,221/255.0,106/255.0,1)
        else
            --color = ccc4f(250/255.0,245/255.0,170/255.0,1)
            local stencil = CCSprite:createWithSpriteFrameName("jiemian_137.png")
            stencil:setPosition(ccp(DWinSize.width/2, inv/2))
            btnItem:addChild(stencil)
        end
        index = index + 1

        --local stencil = CCDrawNode:create()
        --stencil:drawSegment(ccp(-DWinSize.width/2,0), ccp(DWinSize.width,0), inv/2, color)
        --stencil:setPosition(ccp(DWinSize.width/2, inv/2))
        --btnItem:addChild(stencil)

        local sp = CCLabelTTF:create(info.name, "Arial", 30)
        sp:setAnchorPoint(ccp(0,0.5))
        sp:setPosition(ccp(150, inv/2))
        sp:setColor(ccc3(135,88,32))
        btnItem:addChild(sp)
    end
    _container:setSize(nil, inv*index- psum *inv)

    --返回
    local menuBack = CCMenu:create()
    menuBack:setPosition(ccp(0,0))
    layer:addChild(menuBack)
    local btnItem = GFunc_CreateButtonP("jiemian_002.png", function()
        closeInterface()
    end)
    btnItem:setPosition(ccp(DWinSize.width - 40, 35))
    menuBack:addChild(btnItem)
    table.insert(btnTables, btnItem)

    CCDirector:sharedDirector():getRunningScene():addChild(layer)
end


function setRoleIconEnabled(btnIcon, value)
    if value then
        btnIcon.btn:setColor(ccc3(150,150,150))
        btnIcon.spicon:setColor(ccc3(150,150,150))
        btnIcon.spfront:setColor(ccc3(150,150,150))
        btnIcon.spicons:setColor(ccc3(150,150,150))
        btnIcon.spfronts:setColor(ccc3(150,150,150))
    else
        btnIcon.btn:setColor(ccc3(255,255,255))
        btnIcon.spicon:setColor(ccc3(255,255,255))
        btnIcon.spfront:setColor(ccc3(255,255,255))
        btnIcon.spicons:setColor(ccc3(255,255,255))
        btnIcon.spfronts:setColor(ccc3(255,255,255))
    end
end




