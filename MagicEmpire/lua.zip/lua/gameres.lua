--- 数字
vNumberWhite = "jiemian_065.png"
vNumberBFHui = "jiemian_073.png"

NumberTables = {
    [vNumberWhite]={
        w=24,
        h=24,
    },
    [vNumberBFHui]={
        w=30,
        h=26,
    },
}

---音乐音效
sFilePath_Sound = "sound/"
SoundTypeTabls ={
    --[sm_Menu]=Res_Bgm,
    --[sme_Attack]=Res_Effs,
}

Png_BrickPng = "res/Brick.pvr"
--资源表
ResourcesTalbes = {
    --{rtype=Res_Bgm,     d1=sm_Menu,     d2=nil,},
    --{rtype=Res_Effs,    d1=sme_BoosF,   d2=nil,},
    --{rtype=Res_Png,     d1=s_btnPick,   d2=nil,},
    --{rtype=Res_Plist,   d1="role.plist",d2="role.png",},
    {rtype=Res_Plist,   d1="res/map.plist",d2="res/map.pvr",},
    {rtype=Res_Plist,   d1="res/mapbg.plist",d2="res/mapbg.pvr",},
    {rtype=Res_Plist,   d1="res/mapbg2.plist",d2="res/mapbg2.pvr",},
    {rtype=Res_Plist,   d1="res/city.plist",d2="res/city.pvr",},
    {rtype=Res_Plist,   d1="res/title.plist",d2="res/title.pvr",},
    {rtype=Res_Plist,   d1="res/monster.plist",d2="res/monster.pvr",},
    {rtype=Res_Plist,   d1="res/eff.plist",d2="res/eff.pvr",},
    {rtype=Res_Plist,   d1="res/passer.plist",d2="res/passer.pvr",},
    {rtype=Res_Plist,   d1="res/Brick.plist",d2=Png_BrickPng,},
}

SIconMagic = "GUI_Magic.png"
SIconMoney = "GUI_GOLD.png" --"GUI_SJ.png" --
SIconCrystal = "shop_004.png"











