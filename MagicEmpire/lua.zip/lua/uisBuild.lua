-------
--显示建筑物信息
-------

function gfuncCreateUIBG(args)
	local uiWidth = args.width
	local uiHeight = args.height
	if uiWidth == nil then
		uiWidth = 577
	end

	local spbg = CCScale9Sprite:createWithSpriteFrameName("jiemian_006.png", CCRectMake(uiWidth, 135, 0, 10))
  	spbg:setContentSize(CCSizeMake(uiWidth, uiHeight))

  	return spbg
end

-------------------打开商品选择界面
local function onbuildSelectItems(args)
	local layer = nil
	local _container = nil
	local btnTables = {}
	local btnContainerTables = {}
	local parentX, parentY = 0,0

	local item = args.item
	local items = args.items
	local func = args.func

	----添加一个取消商品
	table.insert(items, 1, {info={name="卸下",id=0}})

	local function closeFunc(_args)
		if _args == nil then
			_args = {}
		end
    	----
    	CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
    	if func then
    		func(_args)
    	end
    end

    local beginPickY = 0
   	local function touchContainer(x,y,eventType)
   		local isclick = false
   		if eventType == CCTOUCHENDED and (y >= 220 and y <= 700) and math.abs(beginPickY-y) < 20 then
   			isclick = true
   		end
    	local _mx, _my = _container:getPosition()
    	GFunc_SelectBtnRun(btnContainerTables,x-parentX-_mx,y-parentY-_my,eventType, isclick)
    	if (y >= 220 and y <= 700) then
   			_container:onTouch(x-parentX,y-parentY,eventType)
   		end
    end

    local function touchBegin(x,y,eventType)
    	beginPickY = y
    	touchContainer(x,y,eventType)
    	GFunc_SelectBtnRun(btnTables,x-parentX,y-parentY,eventType)
    end
    local function touchMoved(x,y, eventType)
    	touchContainer(x,y,eventType)
    	GFunc_SelectBtnRun(btnTables,x-parentX,y-parentY,eventType)
    end
    local function touchEnded(x,y,eventType)
    	touchContainer(x,y,eventType)
    	GFunc_SelectBtnRun(btnTables,x-parentX,y-parentY,eventType)
    end

	layer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,155),update=update,touchBegin=touchBegin, touchMoved=touchMoved, touchEnded=touchEnded, fmbg = true})
	CCDirector:sharedDirector():getRunningScene():addChild(layer)

	local _parent = CCNode:create()
	layer:addChild(_parent)
	local _menu = CCMenu:create()
	_menu:setPosition(ccp(0,0))
	_parent:addChild(_menu,1)

	local uiWidth,uiHeight = 577, 552
    local spbg = gfuncCreateUIBG({height=uiHeight})
	spbg:setPosition(ccp(uiWidth/2, uiHeight/2))
	_parent:addChild(spbg)

    --遮罩
    local visitWidth = uiWidth-42
   	local _nodeParentLayerVisit = GFunc_CreateLayerVisit(_parent, visitWidth, 430, 25, 25)
    --排列容器
    _container = GameSildeContainer:new(0, 0, SildeContainer_UpDown)
    _container:addToLayer(_nodeParentLayerVisit)

	local menu = CCMenu:create()
	menu:setPosition(ccp(0,0))
	_container:addElementChild(menu)
	--获取已经开启的商品项目
	local index = 0
	local inv = 66
	local psum = 5
	for k,infos in pairs(items) do
		local info = infos.info
		--列出项目
		local function clickItem(tag)
			--清除之前的物品使用状态
			if item then
				PlayerInfos:onSetItemBuyState(item.id, false)
			end

			local prinfo = items[tag].info
			if items[tag].info.id == 0 then
				prinfo = nil
			end

			if prinfo then
				--设置新物品的使用状态
				PlayerInfos:onSetItemBuyState(prinfo.id, true)
				GameEvent_AddShopEnd(prinfo.id)
			end
			--print(tag)
			closeFunc({info=prinfo})

			--print("选择...",tag,prinfo)
		end
		GTutorShopSelectEnd = function()
			clickItem(k)
		end
		local btnItem = GFunc_CreateButtonLabel("", clickItem, nil, CCSizeMake(visitWidth, inv))
		btnItem:setPosition(ccp(visitWidth/2 - 42, 430 - inv * index))
		menu:addChild(btnItem, 0, k)
		table.insert(btnContainerTables, btnItem)
		--背景
		
        if index % 2 == 1 then
      		local stencil = CCSprite:createWithSpriteFrameName("jiemian_114.png")
         	stencil:setPosition(ccp(visitWidth/2, inv/2))
         	btnItem:addChild(stencil)
     	end
     	index = index + 1

    	local itemname = info.name
        local sp = CCLabelTTF:create(itemname, "Arial", 36)
    	sp:setPosition(ccp(visitWidth/2, inv/2))
    	sp:setColor(ccc3(139,99,36))
    	btnItem:addChild(sp)

		---禁用已经使用的商品
		--print(infos.state, info.name, info.id)
		if infos.state == 1 then
			btnItem:setEnabled(false)
			sp:setColor(ccc3(200,200,200))
		end

    	----显示价格
    	if info.money then
     		local spoutMoney = GameNumbers:new(vNumberBFHui, NumberAlginment_Right)
      		spoutMoney:setPosition(ccp(visitWidth-40, inv/2))
        	spoutMoney:addLayer(btnItem)
        	spoutMoney:setString(GGameGetItemMoney(info.id))

			local spmoneyIcon = CCSprite:createWithSpriteFrameName(SIconMoney)
       		spmoneyIcon:setAnchorPoint(ccp(0,0.5))
       		spmoneyIcon:setPosition(ccp(visitWidth-30, inv/2))
        	btnItem:addChild(spmoneyIcon)
        end
	end
	_container:setSize(nil, inv*index- psum *inv)


    --关闭
    local btnItem = GFunc_CreateButtonP("jiemian_105.png", function()
        closeFunc({close=true})
    end, nil, 2)
    btnItem:setPosition(ccp(uiWidth-10, uiHeight-30))
    _menu:addChild(btnItem)
    table.insert(btnTables, btnItem)

	--界面显示位置
	parentX, parentY = DWinSize.width/2 - uiWidth/2, DWinSize.height/2 - uiHeight/2
	_parent:setPosition(ccp(parentX, parentY))
end

----城堡
local function CBuild_Chengbao(_args)
end
---魔法学院
local function CBuild_MagicXueyuan(_args)
	----研究中则显示当前研究信息
	if _args.info.onYanjiu == 1 then
		_args.funcfinsh = function()
			-- 研究完成后的回调
			--print("研究完成")
			----重新显示
			_args.reload()
		end
		createNodeYanJiuRuning(_args)
	else
		local btnItem = GFunc_CreateButtonP("jiemian_036.png", function(tag)
			_args.layer:setTouchEnabled(false)
			_args.layer:setVisible(false)
	        GameFuncClockCity()
	        createLayerYanJiuMenu(_args.info, function(_vargs)
	        	_args.layer:setTouchEnabled(true)
				_args.layer:setVisible(true)
	            GameFuncUnclockCity()
	            if _vargs.reload then
	            	_args.reload()
	            end
	        end)
	        
			end,nil, 1.2)
		btnItem:setPosition(ccp(_args.uiWidth/2, 200))
		_args.menu:addChild(btnItem)
		table.insert(_args.btnTables, btnItem)
	end
end

GTutorShopClickItem = nil
GTutorShopSelectEnd = nil
---商店
local function CBuild_Shoping(_args)
	--商店的展示位数目
	local fieldsum = _args.info:getFieldSum() or 1
	--print(fieldsum, _args.info.name, _args.info.param, _args.info.lv)
	--商品项目
	local menu = CCMenu:create()
	menu:setPosition(ccp(0,0))
	_args.container:addElementChild(menu)
	--获取已经开启的商品项目
	local index = 0
	local inv = 66
	local psum = 3
	--
	local itemInfos = {}
	for k=1, fieldsum do
		--获取各种栏位中的物品
		local info = _args.info:getFieldItem(k)
		--列出项目
		local function clickItem(tag)
			_args.layer:setTouchEnabled(false)

			local function funcSelectEnd(_vargs)
				--更新商品
				_args.layer:setTouchEnabled(true)
				if _vargs.info then
					_args.info:setFiledItem(tag, _vargs.info)
					--更新显示文本
					itemInfos[tag].txt:setString(_vargs.info.name)
					itemInfos[tag].spoutMoney:setString(GGameGetItemMoney(_vargs.info.id))
					itemInfos[tag].spoutMoney:setVisible(true)
					itemInfos[tag].spmoneyIcon:setVisible(true)
				elseif _vargs.close ~= true then
					_args.info:setFiledItem(tag, _vargs.info)
					itemInfos[tag].txt:setString("[添加作物]")
					itemInfos[tag].spoutMoney:setVisible(false)
					itemInfos[tag].spmoneyIcon:setVisible(false)
				end

				---更新金钱
				_args.updateMoneys()
			end
			--GTutorShopSelectEnd = funcSelectEnd
			local _vargs = {item=_args.info:getFieldItem(tag), items=PlayerInfos:getShops(), func=funcSelectEnd}
			onbuildSelectItems(_vargs)
		end
		GTutorShopClickItem = clickItem
		local btnItem = GFunc_CreateButtonLabel("", clickItem, nil, CCSizeMake(_args.uiWidth, inv))
		btnItem:setPosition(ccp(_args.uiWidth/2-30, 250 - inv * index))
		menu:addChild(btnItem, 0, k)
		table.insert(_args.btnContainerTables, btnItem)
		--背景
      	--local color = nil
        if index % 2 == 0 then
      		local stencil = CCSprite:createWithSpriteFrameName("jiemian_114.png")
         	stencil:setPosition(ccp(DWinSize.width/2-30, inv/2))
         	btnItem:addChild(stencil)
     	end
     	index = index + 1

    	local itemname = "[添加商品]"
    	if info then
    		itemname = info.name
    	end
        local sp = CCLabelTTF:create(itemname, "Arial", 36)
    	sp:setPosition(ccp(_args.uiWidth/2, inv/2))
     	sp:setColor(ccc3(93,139,69))
    	btnItem:addChild(sp)


    	----显示价格
    	local spmoneyIcon = nil
    	local spoutMoney = nil
     	spoutMoney = GameNumbers:new(vNumberBFHui, NumberAlginment_Right)
      	spoutMoney:setPosition(ccp(_args.uiWidth-80, inv/2))
        spoutMoney:addLayer(btnItem)
        spoutMoney:setVisible(false)

		spmoneyIcon = CCSprite:createWithSpriteFrameName(SIconMoney)
       	spmoneyIcon:setAnchorPoint(ccp(0,0.5))
       	spmoneyIcon:setPosition(ccp(_args.uiWidth-70, inv/2))
     	spmoneyIcon:setVisible(false)
        btnItem:addChild(spmoneyIcon)

        if info then
        	spoutMoney:setString(GGameGetItemMoney(info.id))
        	spmoneyIcon:setVisible(true)
        	spoutMoney:setVisible(true)
        end
        
    	itemInfos[k] = {txt=sp,spmoneyIcon=spmoneyIcon,spoutMoney=spoutMoney}
	end
	_args.container:setSize(nil, inv*index- psum *inv)
end
---牧场
local function CBuild_Muchang(_args)
	--商店的展示位数目
	local fieldsum = _args.info:getFieldSum() or 1
	--商品项目
	local menu = CCMenu:create()
	menu:setPosition(ccp(0,0))
	_args.container:addElementChild(menu)
	--获取已经开启的商品项目
	local index = 0
	local inv = 66
	local psum = 3
	--
	local itemInfos = {}
	for k=1, fieldsum do
		--获取各种栏位中的物品
		local info = _args.info:getFieldItem(k)
		--列出项目
		local function clickItem(tag)
			_args.layer:setTouchEnabled(false)

			local function funcSelectEnd(_vargs)
				--更新商品
				_args.layer:setTouchEnabled(true)
				if _vargs.info then
					_args.info:setFiledItem(tag, _vargs.info)
					--更新显示文本
					itemInfos[tag].txt:setString(_vargs.info.name)
					itemInfos[tag].spoutMoney:setString(GGameGetItemMoney(_vargs.info.id))
					itemInfos[tag].spoutMoney:setVisible(true)
					itemInfos[tag].spmoneyIcon:setVisible(true)
				elseif _vargs.close ~= true then
					_args.info:setFiledItem(tag, _vargs.info)
					itemInfos[tag].txt:setString("[添加作物]")
					itemInfos[tag].spoutMoney:setVisible(false)
					itemInfos[tag].spmoneyIcon:setVisible(false)
				end
				---更新金钱
				_args.updateMoneys()
			end
			local _vargs = {item=_args.info:getFieldItem(tag), items=PlayerInfos:getRanchs(), func=funcSelectEnd}
			onbuildSelectItems(_vargs)
		end
		local btnItem = GFunc_CreateButtonLabel("", clickItem, nil, CCSizeMake(_args.uiWidth, inv))
		btnItem:setPosition(ccp(_args.uiWidth/2-30, 250 - inv * index))
		menu:addChild(btnItem, 0, k)
		table.insert(_args.btnContainerTables, btnItem)
		--背景
        if index % 2 == 0 then
      		local stencil = CCSprite:createWithSpriteFrameName("jiemian_114.png")
         	stencil:setPosition(ccp(DWinSize.width/2-30, inv/2))
         	btnItem:addChild(stencil)
     	end
		index = index + 1

    	local itemname = "[添加动物]"
    	if info then
    		itemname = info.name
    	end
        local sp = CCLabelTTF:create(itemname, "Arial", 36)
    	sp:setPosition(ccp(_args.uiWidth/2, inv/2))
    	sp:setColor(ccc3(93,139,69))
    	btnItem:addChild(sp)

    	----显示价格
    	local spmoneyIcon = nil
    	local spoutMoney = nil
     	spoutMoney = GameNumbers:new(vNumberBFHui, NumberAlginment_Right)
      	spoutMoney:setPosition(ccp(_args.uiWidth-80, inv/2))
        spoutMoney:addLayer(btnItem)
        spoutMoney:setVisible(false)

		spmoneyIcon = CCSprite:createWithSpriteFrameName(SIconMoney)
       	spmoneyIcon:setAnchorPoint(ccp(0,0.5))
       	spmoneyIcon:setPosition(ccp(_args.uiWidth-70, inv/2))
     	spmoneyIcon:setVisible(false)
        btnItem:addChild(spmoneyIcon)

        if info then
        	spoutMoney:setString(GGameGetItemMoney(info.id))
        	spmoneyIcon:setVisible(true)
        	spoutMoney:setVisible(true)
        end
        
    	itemInfos[k] = {txt=sp,spmoneyIcon=spmoneyIcon,spoutMoney=spoutMoney}
	end
	_args.container:setSize(nil, inv*index- psum *inv)
end
---农场
local function CBuild_NongChang(_args)
	--商店的展示位数目
	local fieldsum = _args.info:getFieldSum() or 1
	--print(fieldsum, _args.info.name, _args.info.param, _args.info.lv)
	--商品项目
	local menu = CCMenu:create()
	menu:setPosition(ccp(0,0))
	_args.container:addElementChild(menu)
	--获取已经开启的商品项目
	local index = 0
	local inv = 66
	local psum = 3
	--
	local itemInfos = {}
	for k=1, fieldsum do
		--获取各种栏位中的物品
		local info = _args.info:getFieldItem(k)
		--列出项目
		local function clickItem(tag)
			_args.layer:setTouchEnabled(false)

			local function funcSelectEnd(_vargs)
				--更新商品
				_args.layer:setTouchEnabled(true)
				if _vargs.info then
					_args.info:setFiledItem(tag, _vargs.info)
					--更新显示文本
					itemInfos[tag].txt:setString(_vargs.info.name)
					itemInfos[tag].spoutMoney:setString(GGameGetItemMoney(_vargs.info.id))
					itemInfos[tag].spoutMoney:setVisible(true)
					itemInfos[tag].spmoneyIcon:setVisible(true)
				elseif _vargs.close ~= true then
					_args.info:setFiledItem(tag, _vargs.info)
					itemInfos[tag].txt:setString("[添加作物]")
					itemInfos[tag].spoutMoney:setVisible(false)
					itemInfos[tag].spmoneyIcon:setVisible(false)
				end
				---更新金钱
				_args.updateMoneys()
			end
			local _vargs = {item=_args.info:getFieldItem(tag), items=PlayerInfos:getFarms(), func=funcSelectEnd}
			onbuildSelectItems(_vargs)
		end
		local btnItem = GFunc_CreateButtonLabel("", clickItem, nil, CCSizeMake(_args.uiWidth, inv))
		btnItem:setPosition(ccp(_args.uiWidth/2-30, 250 - inv * index))
		menu:addChild(btnItem, 0, k)
		table.insert(_args.btnContainerTables, btnItem)
		--背景
      	--local color = nil
        if index % 2 == 0 then
      		local stencil = CCSprite:createWithSpriteFrameName("jiemian_114.png")
         	stencil:setPosition(ccp(DWinSize.width/2-30, inv/2))
         	btnItem:addChild(stencil)
     	end
     	index = index + 1

    	local itemname = "[添加作物]"
    	if info then
    		itemname = info.name
    	end
        local sp = CCLabelTTF:create(itemname, "Arial", 36)
    	sp:setPosition(ccp(_args.uiWidth/2, inv/2))
     	sp:setColor(ccc3(93,139,69))
    	btnItem:addChild(sp)

    	----显示价格
    	local spmoneyIcon = nil
    	local spoutMoney = nil
     	spoutMoney = GameNumbers:new(vNumberBFHui, NumberAlginment_Right)
      	spoutMoney:setPosition(ccp(_args.uiWidth-80, inv/2))
        spoutMoney:addLayer(btnItem)
        spoutMoney:setVisible(false)

		spmoneyIcon = CCSprite:createWithSpriteFrameName(SIconMoney)
       	spmoneyIcon:setAnchorPoint(ccp(0,0.5))
       	spmoneyIcon:setPosition(ccp(_args.uiWidth-70, inv/2))
     	spmoneyIcon:setVisible(false)
        btnItem:addChild(spmoneyIcon)

        if info then
        	spoutMoney:setString(GGameGetItemMoney(info.id))
        	spmoneyIcon:setVisible(true)
        	spoutMoney:setVisible(true)
        end
        
    	itemInfos[k] = {txt=sp,spmoneyIcon=spmoneyIcon,spoutMoney=spoutMoney}
	end
	_args.container:setSize(nil, inv*index- psum *inv)
end

local _BuildInfoUITable = {
[1]=CBuild_Chengbao,
[2]=CBuild_MagicXueyuan,
[3]=CBuild_Shoping,
[4]=CBuild_Muchang,
[5]=CBuild_NongChang,
}



function GShowBuildInfos(args)
	--获得建筑的信息
	local buildInfo = args.info
	local buildID = buildInfo.bid
	local endfunc = args.endfunc
	local showDetail = args.detail
	local info = GFuncGetTableBuilds()[buildID]
	if info then
		----
		local layer = nil
		local _container = nil
		local btnTables = {}
		local btnContainerTables = {}
		local numberTime = nil
		local buildprogress = nil
		local parentX, parentY = 0,0

		local function reload()
			CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
			GShowBuildInfos(args)
		end

		local function closeFunc(args)
			if args == nil then
				args = {}
			end
    		----
    		CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
    		if endfunc then
    			endfunc(args)
    		end
    	end

    	local function touchContainer(x,y,eventType)
    		if eventType == CCTOUCHENDED and (y < 220 or y > 420) then
    			return
    		end
    		local _mx, _my = _container:getPosition()
    		GFunc_SelectBtnRun(btnContainerTables,x-parentX-_mx,y-parentY-_my,eventType)
            _container:onTouch(x-parentX,y-parentY,eventType)
    	end

    	local function touchBegin(x,y,eventType)
    		GFunc_SelectBtnRun(btnTables,x-parentX,y-parentY,eventType)
    		touchContainer(x,y,eventType)
    	end
    	local function touchMoved(x,y, eventType)
    		--print("noved",x,y)
    		GFunc_SelectBtnRun(btnTables,x-parentX,y-parentY,eventType)
    		touchContainer(x,y,eventType)
    	end
    	local function touchEnded(x,y,eventType)
    		GFunc_SelectBtnRun(btnTables,x-parentX,y-parentY,eventType)
    		touchContainer(x,y,eventType)
    	end
    	local function update(dt)
    		if buildInfo._status == BuildStatus_Build and numberTime then
    			numberTime:setString(math.floor(buildInfo._buildalltime - buildInfo._buildtime))
    			buildprogress:update(buildInfo._buildtime)
    		end
			--显示完成则更新显示
			if buildInfo._status ~= BuildStatus_Build and numberTime then
				closeFunc({disabled=true})
				GShowBuildInfos(args)
			end
		end

		local function exitlayer()
			GFInterface_BuildDetail = nil
		end

		layer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,100),update=update,exfunc=exitlayer,touchBegin=touchBegin, touchMoved=touchMoved, touchEnded=touchEnded, fmbg = true})
		CCDirector:sharedDirector():getRunningScene():addChild(layer)

		GFInterface_BuildDetail = layer

		--背景
		local _parent = CCNode:create()
		layer:addChild(_parent)
		local _menu = CCMenu:create()
		_menu:setPosition(ccp(0,0))
		_parent:addChild(_menu,1)


		local uiWidth,uiHeight = 577, 695
		if showDetail == true then
			uiHeight = 485
		end
    	local spbg = gfuncCreateUIBG({height=uiHeight})
		spbg:setPosition(ccp(uiWidth/2, uiHeight/2))
		_parent:addChild(spbg)

		--图标
		local spbg = CCSprite:createWithSpriteFrameName(string.format("%s.png", info.art))
		spbg:setPosition(ccp(125, uiHeight - 210))
		_parent:addChild(spbg)

		--描述背景
		local spbg = CCSprite:createWithSpriteFrameName("jiemian_089.png")
		spbg:setAnchorPoint(ccp(0,1))
		spbg:setPosition(ccp(210, uiHeight - 110))
		_parent:addChild(spbg)

		--名称sp
		if info.namesp then
			local spbg = CCSprite:createWithSpriteFrameName(string.format("%s.png",info.namesp))
			spbg:setPosition(ccp(uiWidth/2-10,uiHeight-160))
			_parent:addChild(spbg)
		end
		--描述sp
		if info.des then
			local spbg = CCSprite:createWithSpriteFrameName(string.format("%s.png",info.des))
			spbg:setAnchorPoint(ccp(0,1))
			spbg:setPosition(ccp(uiWidth/2+20, uiHeight - 195))
			_parent:addChild(spbg)
		end

       	--每星期产出spbg
        local spbg = CCScale9Sprite:createWithSpriteFrameName("jiemian_150.png", CCRectMake(40, 15, 20, 10))
        spbg:setContentSize(CCSizeMake(460, 50))
       	spbg:setPosition(ccp(uiWidth/2 + 30,uiHeight - 350))
       	_parent:addChild(spbg)

       	local spbg = CCSprite:createWithSpriteFrameName("jiemian_030.png")
       	spbg:setPosition(ccp(200,uiHeight - 350))
       	_parent:addChild(spbg)

       	local icopx = spbg:getContentSize().width + 20
       	local icopy = spbg:getContentSize().height/2
       	----根据不同的产出,获得显示内容
     	local spoutMoney = GameNumbers:new(vNumberBFHui, NumberAlginment_Left)
      	spoutMoney:setPosition(ccp(icopx, icopy))
        spoutMoney:addLayer(spbg)

        local spmoneyIcon = nil
       	if buildInfo:getOutAgree() > 0 then
       		--认同值
       		spmoneyIcon = CCSprite:createWithSpriteFrameName("jiemian_151.png")
       		spmoneyIcon:setAnchorPoint(ccp(0,0.5))
        	spbg:addChild(spmoneyIcon)
       	elseif buildInfo:getOutMagic() > 0 then
       		icopy = icopy + 2
       		icopx = icopx - 10
       		--魔法点图标
       		spmoneyIcon = CCSprite:createWithSpriteFrameName(SIconMagic)
       		spmoneyIcon:setAnchorPoint(ccp(0,0.5))
        	spbg:addChild(spmoneyIcon)
       	else
       		--金币图标
			spmoneyIcon = CCSprite:createWithSpriteFrameName(SIconMoney)
       		spmoneyIcon:setAnchorPoint(ccp(0,0.5))
        	spbg:addChild(spmoneyIcon)
       	end
        local function updateMoneyPos()
        	local icopxv = icopx + 20 + spoutMoney:getWidth()
      		spmoneyIcon:setPosition(ccp(icopxv, icopy))
      		--print(更新坐标)
        end

        local function updateMoneys()
        	local showmoney = 0
        	--print("数值___", buildInfo:getOutAgree(), buildInfo:getOutMagic(), buildInfo:getOutMoney())
       		if buildInfo:getOutAgree() > 0 then
       			showmoney = buildInfo:getOutAgree()
       		elseif buildInfo:getOutMagic() > 0 then
       			showmoney = buildInfo:getOutMagic()
       		else
       			showmoney = buildInfo:getOutMoney()
       		end
     		spoutMoney:setString(showmoney)
     		updateMoneyPos()
        end

        updateMoneys()


    	--遮罩
   	 	local _nodeParentLayerVisit = GFunc_CreateLayerVisit(_parent, uiWidth-20, 200, 10, 90)
    	--排列容器
    	_container = GameSildeContainer:new(0, 0, SildeContainer_UpDown)
    	_container:addToLayer(_nodeParentLayerVisit)

    	if showDetail ~= true then
			---建造中
			if buildInfo._status == BuildStatus_Build then

	       		---进度条
	       		buildprogress = GameProgressCrols:new("jiemian_068.png", "jiemian_067.png")
    			buildprogress:setAllProgress(buildInfo._buildalltime)
    			buildprogress:addToParent(_parent)
    			buildprogress:setPosition(ccp(80, 250))

				--显示建造时间
				local spbg = CCSprite:createWithSpriteFrameName("jiemian_063.png")
				spbg:setAnchorPoint(ccp(0,0))
				spbg:setPosition(ccp(160, 190))
				spbg:setColor(ccc3(123,21,244))
				_parent:addChild(spbg)

	       		--建造时间/秒
	       		numberTime = GameNumbers:new(vNumberWhite)
	       		numberTime:addLayer(_parent)
				numberTime:setColor(ccc3(139,99,36))
	       		numberTime:setPosition(ccp(350, 205))
	       		numberTime:setString(math.floor(buildInfo._buildalltime - buildInfo._buildtime))

				--秒sp
				local spbg = CCSprite:createWithSpriteFrameName("jiemian_064.png")
				spbg:setAnchorPoint(ccp(0,0))
				spbg:setColor(ccc3(123,21,244))
				spbg:setPosition(ccp(400, 195))
				_parent:addChild(spbg)

	       		--立即完成建造按钮
	       		local btnItem = createFirstbuttom(buildInfo, function(tag)
	       			buildInfo:onComplete(true)
	       		end)
	       		btnItem:setPosition(ccp(uiWidth/2,120))
	       		_menu:addChild(btnItem,0,buildID)
	       		table.insert(btnTables, btnItem)
	       	else
				----等级升级相关
	       		--升级按钮
	       		--可以升级并且升级没有满
	       		if info.lvup and buildInfo.onYanjiu == 0 then
	       			--lv sp
	       			local spbg = CCSprite:createWithSpriteFrameName("jiemian_038.png")
	       			spbg:setAnchorPoint(ccp(0,0))
	       			spbg:setPosition(ccp(uiWidth - 150,uiHeight-170))
	       			_parent:addChild(spbg)
					--lv数字
					local numberLv = GameNumbers:new(vNumberWhite, NumberAlginment_Left)
					numberLv:addLayer(_parent)
					numberLv:setPosition(ccp(uiWidth - 95,uiHeight-158))
					numberLv:setString(buildInfo.lv)

					--判断是否可以升级
					--除了城堡,其它的建筑升级需要城堡等级提升,城堡在建筑位置1
					local _haslvup = true
					local chengbaoInfo = PlayerInfos:getAllBuildInfos()[1]
					if info.id ~= 1 then
						if buildInfo.lv >= chengbaoInfo.lv then
							_haslvup = false
						end
					end
					local nextUpInfo = buildInfo:getNextLvInfo()
					if _haslvup and nextUpInfo then
						local btnItem = GFunc_CreateButtonP("jiemian_034.png", function(tag)
							--是否有足够的金钱,
							if PlayerInfos:getMoney() < nextUpInfo.lvmoney then
								GFunc_ShowGameDialogMessage({msg="似乎没有足够的金币啊"})
								return
							end
							--扣除相应金钱
							PlayerInfos:addMoney(-nextUpInfo.lvmoney)
							---开始升级
							buildInfo:onLevelUp()
							closeFunc()
						end,nil, 1.2)
						btnItem:setPosition(ccp(uiWidth/2,60))
						_menu:addChild(btnItem,0,buildID)
						table.insert(btnTables, btnItem)

						--显示个金钱
						local txtmoney = CCLabelTTF:create(string.format("花费:%d",nextUpInfo.lvmoney), "Arial", 28)
						txtmoney:setPosition(ccp(uiWidth/2,110))
						txtmoney:setColor(ccc3(103,163,253))
						_parent:addChild(txtmoney)
					elseif _haslvup == false and nextUpInfo then
						---如果不能升级但是有可提升的等级,则提示
						--显示个金钱
						local txtmoney = CCLabelTTF:create(string.format("升级需要 城堡 到达Lv.%d", nextUpInfo.lv), "Arial", 28)
						txtmoney:setPosition(ccp(uiWidth/2,60))
						txtmoney:setColor(ccc3(103,163,253))
						_parent:addChild(txtmoney)
					end
				end
				--建筑物各自的其它不同显示
				if _BuildInfoUITable[buildID] then
					local _args ={
						parent = _parent,
						menu = _menu,
						btnTables = btnTables,
						btnContainerTables = btnContainerTables,
						container = _container,
						uiWidth = uiWidth,
						uiHeight = uiHeight,
						info = buildInfo,
						layer = layer,
						updateMoneys=updateMoneys,
						args=args,
						closeFunc=closeFunc,
						reload=reload,
					}
					_BuildInfoUITable[buildID](_args)
				end
			end

	    	---城堡不可拆除
	    	if buildInfo.bid ~= 1 then

			--拆除
	    	local btnItem = GFunc_CreateButtonP("jiemian_160.png", function()
	    		layer:setTouchEnabled(false)
	    	   	--确认
	    	   	GFunc_ShowDialogEnterClance({msg=string.format("您确定要拆除掉 %s 吗",buildInfo.name), func=function(_args)
	    	   		layer:setTouchEnabled(true)
	    	   		if _args.enter then
	    	   			--删除建筑
	    	   			buildInfo:remove()
	    				PlayerInfos:getAllBuildInfos()[buildInfo.mapid] = nil
	    				--清除相应位置
	    				closeFunc()
	    	   		end
	    	   	end})
	    	end, nil, 2)
	    	btnItem:setPosition(ccp(uiWidth-78, 56))
	    	_menu:addChild(btnItem)
	    	table.insert(btnTables, btnItem)
	    	end
	    end


    	--关闭
    	local btnItem = GFunc_CreateButtonP("jiemian_105.png", function()
    	    closeFunc()
    	end, nil, 2)
    	btnItem:setPosition(ccp(uiWidth-10, uiHeight-30))
    	_menu:addChild(btnItem)
    	table.insert(btnTables, btnItem)

		--界面显示位置
		parentX, parentY = DWinSize.width/2 - uiWidth/2, DWinSize.height/2 - uiHeight/2
		_parent:setPosition(ccp(parentX, parentY))
		----
	end
end



function createFirstbuttom(info, func)
	----计算出消耗的宝石数
	local function getConsumeGen()
		local lasttime = 0
		---如果还在建造中,则计算剩余建造时间
		if info._status == BuildStatus_Build then
			lasttime = info._buildalltime - info._buildtime
		elseif info._status == BuildStatus_BuildComplete then
			---建造完成则判定是研究
			if info.bid == 2 and info.onYanjiu == 1 then
				lasttime = GameYanjiu_Time - info.Yanjiutime
			end
		end

		--每10秒消耗1宝石
		local gem = math.ceil(lasttime/10)
		return gem
	end

	--立即完成建造按钮
	local btnItem = GFunc_CreateButtonP("jiemian_070.png", function()
		--询问?是否有足够的宝石
		if getConsumeGen() > PlayerInfos:getCrystal() then
			GFunc_ShowGameDialogMessage({msg="宝石不足哦"})
			return
		end
		---扣除宝石
		PlayerInfos:addCrystal(-getConsumeGen())

		if func then
			func()
		end
	end)

	--立即完成消耗
	local numberGold = GameNumbers:new(vNumberWhite, NumberAlginment_Right)
	numberGold:addLayer(btnItem)
	numberGold:setPosition(ccp(100, 70))
	numberGold:setColor(ccc3(22,255,22))
	numberGold:setString(100)

	--图标
	local spbg = CCSprite:createWithSpriteFrameName(SIconCrystal)
	spbg:setPosition(ccp(125, 75))
	spbg:setScale(0.7)
	btnItem:addChild(spbg)

	--根据时间更新其消耗数
	local function update(dt)
		numberGold:setString(getConsumeGen())
	end
	update()
	local layer = GFunc_CreateLayerEnterOrExit({update=update, fps=0.3})
	btnItem:addChild(layer)

	return btnItem
end