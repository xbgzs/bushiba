------
--主城界面
------
local _GFunc_ShowBulidList = nil
function GFunc_ShowBulidList(build)
    if _GFunc_ShowBulidList then
        _GFunc_ShowBulidList(build)
    end
end
local _GFunc_hideBuildList = nil
function GFunc_hideBuildList()
    if _GFunc_hideBuildList then
        _GFunc_hideBuildList()
    end
end

-------------坐标显示阶段层
TableRLevelPostion = {
    {y=700, rlevel = 0},
    {y=600, rlevel = 1},
    {y=513, rlevel = 2},
    {y=425, rlevel = 3},
    {y=340, rlevel = 4},
    {y=255, rlevel = 5},
    {y=167, rlevel = 6},
    {y=80, rlevel = 7},
}

GGameCityLayer  = nil

---获取显示位置
GameFuncGetCityViewPos = nil

function createLayerCity(scene)
    local myLayer = {}

    myLayer.layer = nil
    local _parentNode = nil
    local _container = nil

    --地图大小
    local mapSizeW = 0
    local mapSizeH = 0
    
    local buildItemlist = {}

    function GGameCityRemoveBuild(tag)
        for k,v in pairs(buildItemlist) do
            if tag == v:getTag() then
                buildItemlist[k] = nil
            end
        end
    end

    local movepx = 0
    local function touchbuild(x,y,eventType)
        local click = true
        if eventType == CCTOUCHBEGAN then
            movepx = x
        elseif eventType == CCTOUCHENDED then
            if math.abs(x - movepx) > 20 then
                click = false
            end
        end

        local mx,my = _container:getViewPostion()
        GFunc_SelectBtnRun(buildItemlist,x-mx,y-my,eventType,click)
    end

    ------------
    local function touchBegin(x,y, eventType)
        _container:onTouchBegin(x,y)

        touchbuild(x,y, eventType)
    end
    local function touchMoved(x,y, eventType)
        _container:onTouchMoved(x,y)
        touchbuild(x,y, eventType)
    end
    local function touchEnded(x,y, eventType)
        _container:onTouchEnded(x,y, eventType)

        touchbuild(x,y, eventType)

        GFunc_hideBuildList()
    end
    local function exitlayer()
        GGameCityLayer  = nil
    end
    local function update(dt)
        ---更新游戏时间
        PlayerInfos:addCityTime(dt)
    end

    GameFuncGetCityViewPos = function(pos)
        if pos then
            --设置位置
            _container:setViewPosition(pos)
        end
        return _container:getViewPostion()
    end
    
    ----------
    myLayer.layer = GFunc_CreateLayerEnterOrExit({update=update,fps=1.0/30.0,exfunc=exitlayer,touchBegin=touchBegin, touchMoved=touchMoved, touchEnded=touchEnded})
    ------------

    _parentNode = CCNode:create()
    --layer:addChild(_parentNode)
    GGameCityLayer =_parentNode

    ---模拟行人
    _parentNode:addChild(createLayerCityPasser())

    --排列容器
    _container = GameSildeContainer:new()
    _container:addToLayer(myLayer.layer)
    _container:addElementChild(_parentNode)
    --地图背景
    local spbg = CCSprite:createWithSpriteFrameName("map_001.png")
    spbg:setAnchorPoint(ccp(0,0))
    spbg:setPosition(ccp(0,0))
    _parentNode:addChild(spbg)

    --城堡遮挡
    local spbgzm = CCSprite:createWithSpriteFrameName("jiemian_033.png")
    spbgzm:setAnchorPoint(ccp(0,0))
    spbgzm:setPosition(ccp(596, DWinSize.height - 268))
    _parentNode:addChild(spbgzm,1)

    mapSizeH = spbg:getContentSize().height
    mapSizeW = spbg:getContentSize().width
    _container:setSize(mapSizeW - DWinSize.width, mapSizeH - DWinSize.height)
    _container:setType(SildeContainer_All);
    
    myLayer.menu = CCMenu:create()
    myLayer.menu:setPosition(ccp(0,0))
    _parentNode:addChild(myLayer.menu)

    local strReturn = ""

    ------建造建筑
    GGameCityNewBuild = function(buildid, mapid)
        local info = MapInfos_Static[mapid]
        local binfo = GFuncGetTableBuilds()[buildid]
        local btnItem = GFunc_CreateButtonP(string.format("%s.png",binfo.art), function(tag)
            --如果没有收钱则收钱(收获)
            if PlayerInfos:getAllBuildInfos()[tag].tempgaintime > 0 then
                PlayerInfos:getAllBuildInfos()[tag]:onGainConfirm()
            else
                GameFuncClockCity()
                GShowBuildInfos({info=PlayerInfos:getAllBuildInfos()[tag], endfunc=function()
                    GameFuncUnclockCity()
                    end});
            end
        end)
        local px = info.x + btnItem:getNormalImage():getContentSize().width/2
        local py = DWinSize.height - info.y + btnItem:getNormalImage():getContentSize().height/2
        btnItem:setPosition(ccp(px, py))

        local pvy = DWinSize.height - info.y
        local rlevel = 0
        strReturn = string.format("%s\n{x=%d,y=%d,mapid=%d},",strReturn,px,pvy-30,mapid)
        for k=1,10 do
            local _vinfo = TableRLevelPostion[k]
            if _vinfo == nil then
                break
            end
            if _vinfo.y < pvy then
                rlevel = _vinfo.rlevel
                break
            end
        end

        GGameCityLayer:addChild(btnItem, rlevel, mapid)
        table.insert(buildItemlist, btnItem)

        local cbuild = GameBuildClass:new(buildid, mapid)
        cbuild:setArt(btnItem)
        PlayerInfos:getAllBuildInfos()[mapid] = cbuild

        return cbuild
    end

    ---使用中道具表
    local useitems = {}
    ---初始化建筑
    for k ,info in pairs(PlayerInfos:getAllBuildInfos()) do
        if info.build then --初始建筑
            local cbuild = GGameCityNewBuild(info.build, k)
            if info.lv then
                cbuild.lv = info.lv
            end
            cbuild:updateInfo()
            --print("等级",cbuild.lv, cbuild.name)
            if info.buildtime then
                cbuild._buildtime = info.buildtime
            end
            if info.buildalltime then
                cbuild._buildalltime = info.buildalltime
            end
            if info.status then
                cbuild._status = info.status
            end

            if info.fieldTables then
                cbuild.fieldTables = info.fieldTables

                for _k,_v in pairs(info.fieldTables) do
                    --table.insert(useitems, _v.id)
                    useitems[_v.id] = true
                end
            end

            if info.onYanjiu then
                cbuild.onYanjiu = info.onYanjiu
            end
            if info.YanjiuItemID then
                cbuild.YanjiuItemID = info.YanjiuItemID
            end
            if info.Yanjiutime then
                cbuild.Yanjiutime = info.Yanjiutime
            end


            if info.tempagree then
                cbuild.tempagree = info.tempagree
            end
            if info.tempmagic then
                cbuild.tempmagic = info.tempmagic
            end
            if info.tempmoney then
                cbuild.tempmoney = info.tempmoney
            end
            if info.tempgaintime then
                cbuild.tempgaintime = info.tempgaintime
            end

            ---根据状态显示建造
            cbuild:onInit()
        end
    end

    ---重置道具使用状态
    for k,item in pairs(PlayerInfos.itemlists) do
        item.state = 0
        if useitems[k] then
            item.state = 1
        end
    end


    -------------
    local _tempBuild = {}
    _GFunc_hideBuildList = function()
        for k , tempItem in pairs(_tempBuild) do
            myLayer.menu:removeChild(tempItem, true)
        end
        _tempBuild = {}
    end
    GFuncGetTempBuildlist = function()
        return _tempBuild
    end
    --在空位中显示所有可建造的建筑物
    _GFunc_ShowBulidList = function(build)
        local binfo = GFuncGetTableBuilds()[build]

        GFunc_hideBuildList()
        for k ,info in pairs(MapInfos_Static) do
            if PlayerInfos:getAllBuildInfos()[k] == nil then
                local btnItem = GFunc_CreateButtonP(string.format("%s.png",binfo.art), function(tag)
                    --print("__b__",tag)
                    ---开始建造建筑
                    local cbuild = GGameCityNewBuild(build, tag)
                    ----建造进度显示
                    cbuild:onBuild()

                    --扣除建造费用
                    PlayerInfos:addMoney(-binfo.money)

                    --取消所有临时显示建筑
                    GFunc_hideBuildList()
                end)
                btnItem:setOpacity(100)
                btnItem:setPosition(ccp(info.x + btnItem:getNormalImage():getContentSize().width/2, DWinSize.height - info.y + btnItem:getNormalImage():getContentSize().height/2))
                myLayer.menu:addChild(btnItem, 0, k)

                table.insert(_tempBuild, btnItem)
            end
        end
    end
    
    
    return myLayer
end

------------------------
BuildStatus_Build   = 0x01
BuildStatus_BuildComplete = 0x02
----
GameBuildClass = {}
GameBuildClass.__index = GameBuildClass
---
function GameBuildClass:new(id, mapid)
    local self = {}
    setmetatable(self, GameBuildClass)

    self.info = nil
    self.bid = id
    self.mapid = mapid
    self.lv = 1
    --[[
        id 相应等级建筑ID
        type 建筑ID
        name 名称
        lv 等级
        time 建造时间
        kcost 维护费用
        lvmoney 等级费用
        param 展示栏数量
    --]]
    -----研究所
    --研究相关
    self.onYanjiu = 0 --1为正在研发中
    self.Yanjiutime = 0 --当前研发时间
    self.YanjiuItemID = 0 --当前研究物品ID


    self.artg = nil --建筑显示(形象)
    self.progress = nil --建造进度条

    self.progressyj = nil --研究进度条

    self._buildtime = 0 --已经建造时间
    self._buildalltime = self.time or 0 --建造总时间
    self._status = BuildStatus_BuildComplete
    self._lvup = false


    -----临时待收获
    self.tempagree = 0
    self.tempmoney = 0
    self.tempmagic = 0
    self.tempgaintime = 0 --上次收获时间
    --local btnItem = GFunc_CreateButtonP("jiemian_004.png", buildcallback, 1.05)
    --btnItem:setPosition(ccp(_x,_y))
    --_pageMenu:addChild(btnItem,0,k)



    --附加参数,商店/农场/牧场,拥有商品的栏位数
    self.param = 1
    self.fieldTables = {} --记录摆放在展示架上的商品

    self:updateInfo()

    return self
end

function GameBuildClass:remove()
    GGameCityRemoveBuild(self.mapid)
    GFunc_RemoveChild(self.artg)

    ---把占用中的物品清除
    for k,item in pairs(self.fieldTables) do
        PlayerInfos:onSetItemBuyState(item.id, false)
    end
end

function GameBuildClass:setArt(btnItem)
    self.artg = btnItem

    --操作收获按钮
    self.gainBg = CCSprite:createWithSpriteFrameName("jiemian_019.png")
    self.gainBg:setAnchorPoint(ccp(0.5,0))
    self.gainBg:setOpacity(220)
    self.gainBg:setVisible(false)
    self.gainBg:setPosition(ccp(btnItem:getNormalImage():getContentSize().width/2, btnItem:getNormalImage():getContentSize().height*0.9))
    btnItem:addChild(self.gainBg)

    --金钱
    self.gainMoneysp = CCSprite:createWithSpriteFrameName(SIconMoney)
    --self.gainMoneysp:setAnchorPoint(ccp(0,0))
    self.gainMoneysp:setPosition(ccp(self.gainBg:getContentSize().width/2,self.gainBg:getContentSize().height/2))
    self.gainBg:addChild(self.gainMoneysp)
end

--获取当前建筑的相关信息
function GameBuildClass:updateInfo()
    for k,info in pairs(BuildInfoList_Static) do
        --print(info.name, info.lv, info.type, self.lv, self.bid)
        if info.lv == self.lv and info.type == self.bid then
            self.info = info
            for k, v in pairs(self.info) do
                self[k] = v
                --print(k,v)
            end
            break
        end
    end
end

function GameBuildClass:getFieldSum()
    return self.param
end
function GameBuildClass:getFieldItem(index)
    return self.fieldTables[index]
end
function GameBuildClass:setFiledItem(index, item)
    self.fieldTables[index] = item
end
--获取下一等级的信息
function GameBuildClass:getNextLvInfo()
    local rinfo = nil
    for k,info in pairs(BuildInfoList_Static) do
        ---print(info.lv, self.lv, info.type, self.bid)
        if info.lv == self.lv + 1 and info.type == self.bid then
            rinfo = info
            break
        end
    end
    return rinfo
end
--建筑升级
function GameBuildClass:onLevelUp()
    self._lvup = true
    self:onBuild()
end
---开始建造并显示建造进度
function GameBuildClass:onBuild(binit)
    self._status = BuildStatus_Build
    --获取建筑时间,
    if not binit then
        self._buildtime = 0 --已经建造时间
        self._buildalltime = self.time or 0 --建造总时间
        --获得下个等级的建筑时间
        if self._lvup then
            local nextInfo = self:getNextLvInfo()
            self._buildalltime = nextInfo.time
        end
        --print("建造时间", self._buildtime, self._buildalltime, self._lvup, self.time)
    end
    --显示进度条
    self.progress = GameProgressCrols:new("jiemian_061.png", "jiemian_062.png")
    self.progress:setAllProgress(self._buildalltime)
    self.progress:addToParent(self.artg)

    self.progress:setPosition(ccp((self.artg:getNormalImage():getContentSize().width - self.progress._bgsp:getContentSize().width)/2, 0))


    --建筑中透明
    self.artg:setOpacity(155)
end
--根据当前状态显示建筑
function GameBuildClass:onInit()
    if self._status == BuildStatus_BuildComplete then
        self:onComplete(nil, true)
    else
        self:onBuild(true)
    end
end
---完成建造(fest:立即完成)
function GameBuildClass:onComplete(fest, binit)
    self._status = BuildStatus_BuildComplete
    --完全显示
    self.artg:setOpacity(255)

    --移除进度条
    if self.progress then
        self.artg:removeChild(self.progress._parent, true)
    end

    ---等级提升
    if self._lvup then
        self._lvup = false
        self.lv = self.lv + 1
        self:updateInfo()
    end

    if fest then
        self:GameFinshEvent()
    end
    if not binit then
        GFunc_ShowSMessage(string.format("[%s]已经建造完成", self.name))
    end
end
function GameBuildClass:GameFinshEvent()
    ---建造完成事件
    GameEvent_BuildEnd(self.bid)
    -- body
end
function GameBuildClass:update(dt)
    if self._status == BuildStatus_Build then
        self._buildtime = self._buildtime + dt
        if self._buildtime >= self._buildalltime then
            self:onComplete(true)
        else
            if self.progress then
                self.progress:update(self._buildtime)
            end
        end
    end

    self:updateYanjiu(dt)
end
---显示获得按钮
function GameBuildClass:onShowGainBtn()

    -- body
    --jiemian_019
    --local btnItem = GFunc_CreateButtonP("jiemian_004.png", buildcallback, 1.05)
    --btnItem:setPosition(ccp(_x,_y))
    --_pageMenu:addChild(btnItem,0,k)

end
----获得产出数据
function GameBuildClass:getOutMoney()
    local vmoney = self.vmoney and self.vmoney or 0

    --拥有商品的建筑生产也商品有关
    if self.param > 0 then
        --获得商品的价格
        for k, info in pairs(self.fieldTables) do
            vmoney = vmoney + GGameGetItemMoney(info.id)
        end
    end
    return vmoney
end
function GameBuildClass:getOutAgree()
    local agree = self.agree and self.agree or 0
    return agree
end
function GameBuildClass:getOutMagic()
    local magic = self.magic and self.magic or 0
    return magic
end

--收获
function GameBuildClass:onGain()
    --建造中的建筑无法收获
    if self._status == BuildStatus_Build then
        return
    end


    local kcost = 0 -- -(self.kcost and self.kcost or 0)
    local vmoney = self:getOutMoney()
    local agree = self:getOutAgree()
    local magic = self:getOutMagic()

    --扣除维护费
    PlayerInfos:addMoney(kcost)
    --文明点
    PlayerInfos:addAgree(PlayerInfos.mapID, agree)
    --魔法点
    PlayerInfos:addMagic(magic)

    -----累加收获值,需要玩家操作收获
    self.tempagree = self.tempagree + agree
    self.tempmoney = self.tempmoney + vmoney
    self.tempmagic = self.tempmagic + magic

    if self.tempmoney > 0 then
        --累积未收效次数
        self.tempgaintime = self.tempgaintime + 1
    end

    --城堡自动收获,
    if self.bid == 1 then
        self:onGainConfirm()
    end
end
---确认收获
function GameBuildClass:onGainConfirm()
    --参观费
    PlayerInfos:addMoney(self.tempmoney)

    ---获得的的收获大于100则显示金币获得效果
    if self.tempmoney then
        local px,py = self.artg:getPosition()
        local txt = CCLabelTTF:create(string.format("+%d",self.tempmoney), "Arial", GFGetFont(36))
        txt:setColor(ccc3(250,250,0))
        txt:setPosition(ccp(px, py+self.artg:getNormalImage():getContentSize().height*0.5))
        txt:runAction(CCSequence:createWithTwoActions(CCMoveBy:create(1.0, ccp(0, 50)), CCCallFunc:create(function() 
            GFunc_RemoveChild(txt)
            end)))
        GGameCityLayer:addChild(txt,10)
    end

    self.tempgaintime = 0
    self.tempagree = 0
    self.tempmoney = 0
    self.tempmagic = 0
end

--开始进行研究
function GameBuildClass:YanjiuBegin(itemID)
    --开始进行研究
    self.onYanjiu = 1
    self.Yanjiutime = 0
    self.YanjiuItemID = itemID
    --把研究的商品从物品表中移除
    if PlayerInfos:getItems()[itemID].sum or 0 > 0 then
        PlayerInfos:getItems()[itemID].sum = PlayerInfos:getItems()[itemID].sum - 1
    end
end
--研究结束
function GameBuildClass:YanjiuEnd(first)
    if self.YanjiuItemID ~= 0 then
        ---研究完成事件
        GameEvent_YanjiuEnd(self.YanjiuItemID)
    end
    --print("研究完成", self.YanjiuItemID)
    -- body
    self.onYanjiu = 0
    self.Yanjiutime = 0
    self.YanjiuItemID = 0

    if first and self.onYanjiu == 0 then
        if self.progressyj ~= nil then
            GFunc_RemoveChild(self.progressyj._parent)
            self.progressyj = nil
        end
    end
end
--研究进行中,更新
function GameBuildClass:updateYanjiu(dt)
    -- body
    if self.onYanjiu == 1 then
        self.Yanjiutime = self.Yanjiutime + dt
        if self.Yanjiutime >= GameYanjiu_Time then
            self:YanjiuEnd()
        end
        --显示进度条
        if self.progressyj == nil then
            self.progressyj = GameProgressCrols:new("jiemian_068.png", "jiemian_067.png")
            self.progressyj:setAllProgress(GameYanjiu_Time)
            self.progressyj:addToParent(self.artg)
            self.progressyj:setScale(0.3)
            self.progressyj:setPosition(ccp((self.artg:getNormalImage():getContentSize().width - self.progressyj:getContentSize().width)/2, 0))
        end
        self.progressyj:update(self.Yanjiutime)
    else
        if self.progressyj ~= nil then
            GFunc_RemoveChild(self.progressyj._parent)
            self.progressyj = nil
        end
    end

    if self.tempgaintime > 0 then
        self.gainBg:setVisible(true)
    else
        self.gainBg:setVisible(false)
    end

    --自动收获<<
    if self.tempgaintime >= 10 then
        self:onGainConfirm()
    end
end






