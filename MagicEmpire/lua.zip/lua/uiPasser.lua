-------------地图相关路径坐标数据
local mapPathDatas = {
	{[3] = {mapid = 0, x=980, y=95}, },
	{[1] = {x=469,y=55,mapid=15}, [2]={x=616,y=143,mapid=14}, [3]={x=764,y=228,mapid=13}, [4]={x=910,y=310,mapid=0}, },
	{[1] = {x=321,y=142,mapid=12}, [2]={x=468,y=229,mapid=11}, [3]= {x=616,y=315,mapid=10},  [4] = {x=764,y=402,mapid=9}, [5]={x=910,y=485,mapid=0},},
	{[1] = {x=174,y=230,mapid=8}, [2]={x=321,y=315,mapid=7}, [3]={x=468,y=401,mapid=6}, [4] = {x=615,y=487,mapid=5}, [5]={x=764,y=575,mapid=0},},
	{[1] = {x=39,y=310,mapid=0}, [2] = {x=173,y=403,mapid=4}, [3] ={x=321,y=488,mapid=3}, [4] = {x=468,y=575,mapid=2}, [5]={x=615,y=665,mapid=0},},
	{[2] = {x=39,y=488,mapid=0}, [3] ={x=173,y=575,mapid=0}, [4] = {x=321,y=665,mapid=0}, [5]={x=468,y=755,mapid=1},},
}
local brithPos = {x=1,y=3} --出生位置

---最大路人数量
local maxPasserSum = 6


local PasserAction_Stand	= 0x01
local PasserAction_Move		= 0x02

local PasserStatic_Stand	= 0x01 --静止
local PasserStatic_Moving	= 0x02 --移动中
local PasserStatic_Home		= 0x03 --回家了

local PasserDir_Left	= 0x01
local PasserDir_Right	= 0x02
local PasserDir_Up		= 0x03
local PasserDir_Down	= 0x04
---行人数据  资源  art..type.."0"..value
local PasserTables_Static = {
	[1] = {
		art="xingren_",
		down={stand={1,1}, move={2,3}},
		up={stand={4,4}, move={5,6}},
	},
	[2] = {
		art="xingren_",
		down={stand={1,1}, move={2,3}},
		up={stand={4,4}, move={5,6}},
	},
	[3] = {
		art="xingren_",
		down={stand={1,1}, move={2,3}},
		up={stand={4,4}, move={5,6}},
	},
	[4] = {
		art="xingren_",
		down={stand={1,1}, move={2,3}},
		up={stand={4,4}, move={5,6}},
	},
}


---生成以mapid为主键的路径表,快速查找
local mapIDPathDatas = {}
for row, infotable in pairs(mapPathDatas) do
	for col, infos in pairs(infotable) do
		--print(row,col,infos.mapid)
		mapIDPathDatas[infos.mapid] = {x=row,y=col}
	end
end

---用于判断相邻两点是否可移动
local function jugeMapPathMoved(row, col, torow, tocol)
	--print(row,col,torow,tocol)
	--为空则表示无法移动
	if mapPathDatas[torow] == nil or mapPathDatas[torow][tocol] == nil then
		return false
	end
	return true
end

-----------自动化行人系统
function createLayerCityPasser()
	local layer = nil

	local passerlist = {}

	--创建一个行人
	local function createPasser()
		--4种行人
		local tpes = {1,2,3,4}

		local passer = GameCityPasser:new(tpes[rand(1,#tpes)])
		passer:addParent(GGameCityLayer, 5)
		--print("大爷我出生啦!!", brithPos.x, brithPos.y)
		--出现在初始位置
		passer:setPositionMap(brithPos.x, brithPos.y)
		passer:onGotoShoping()
		table.insert(passerlist, passer)
	end

	local timesum = 0
	local lastshow = rand(1,2)
	local function update(dt)
		if GGameShowInterface ~= GGameInterface_City then
			return
		end

		for k, passer in pairs(passerlist) do
			if passer.status == PasserStatic_Home then
				passer:delete()
				passerlist[k] = nil
			else
				passer:update(dt)
			end
		end
	end

	layer = GFunc_CreateLayerEnterOrExit({update=update, fps=1.0/30.0})


	local function updatecreate(dt)
		if GGameShowInterface ~= GGameInterface_City then
			return
		end

		--每隔一段时间生成一个行人
		timesum = timesum + dt
		--最大人数是建筑数/2
		local masPasser = maxPasserSum
		local _sum = 0
		for k,v in pairs(PlayerInfos:getAllBuildInfos()) do
			_sum = _sum + 1
		end
		masPasser = math.ceil(_sum/2)

		local sumpasser = 0
		for k, passer in pairs(passerlist) do
			if passer.status ~= PasserStatic_Home then
				sumpasser = sumpasser + 1
			end
		end
		--print(sumpasser, masPasser+1)
		if sumpasser < masPasser+1 and timesum >= lastshow then
			createPasser()
			timesum = 0
			lastshow = rand(3,8)
		end
	end
	local layerup = GFunc_CreateLayerEnterOrExit({update=updatecreate, fps=0.5})
	layer:addChild(layerup)

	return layer
end

----------行人类
GameCityPasser = {}
GameCityPasser.__index = GameCityPasser
---
function GameCityPasser:new(type)
    local self = {}
    setmetatable(self, GameCityPasser)

    self.type = type
    self.info = PasserTables_Static[type]

    self.parent = CCNode:create()
    --当前动作
    self.action = 0
    --方向
    self.dir = 0
    --动作动画
    self.action_anim = nil
    ---默认站立
    self:onAction(PasserAction_Move, PasserDir_Up)

    --移动速度
    self.speed = 100
    --移动到位置
    self.moveto = ccp(0,0)
    --当前状态
    self.status = PasserStatic_Stand
    --当前所在地图点
    self.mapid = 0
    --当前导航路径
    self.navigation = {}

    ----浏览次数,结束了要回家哦
    self.seeSum = rand(2,5)

    return self
end

function GameCityPasser:delete()
	-- body
	GFunc_RemoveChild(self.parent)
	--print("删除掉")
end

--显示说话
function GameCityPasser:sayBy(msg)
	if msg == nil or msg == "" then
		return
	end

	---创建一个文本面板
	local parentSay = CCNode:create()
	parentSay:setPosition(ccp(60,60))
	self.parent:addChild(parentSay,2)

	local spbg = CCSprite:createWithSpriteFrameName("duihuakuang.png")
	parentSay:addChild(spbg)

	local txt = CCLabelTTF:create(msg, "Arial", 18 ,CCSizeMake(130,0), kCCTextAlignmentLeft)
	txt:setPosition(ccp(0,5))
	txt:setColor(ccc3(50,50,50))
	parentSay:addChild(txt)

	---显示一定时间后隐藏消失
    local arr1 = CCArray:create()
    arr1:addObject(CCDelayTime:create(2))
    arr1:addObject(CCFadeOut:create(0.5))
    local seq1 = CCSequence:create(arr1)
    txt:runAction(CCSequence:createWithTwoActions(seq1, CCCallFunc:create(function()
     	GFunc_RemoveChild(parentSay)
    end)))
end

function GameCityPasser:addParent(parent, rlevel)
	if rlevel == nil then
		rlevel = 0
	end

	-- body
	parent:addChild(self.parent, rlevel)
end

function GameCityPasser:onAction(action, dir)
	if self.action == action and self.dir == dir then
		return
	end
	self.action = action
	self.dir = dir

	----根据动作,方向,获得动画
	if self.action_anim then
		GFunc_RemoveChild(self.action_anim)
		self.action_anim = nil
	end

	local actinfo = nil
	if self.dir == PasserDir_Up or self.dir == PasserDir_Right then
		actinfo = self.info.up
	else
		actinfo = self.info.down
	end
	local bframe, iframe = 0,0
	if self.action == PasserAction_Stand then
		bframe = actinfo.stand[1]
		iframe = actinfo.stand[2]
	elseif self.action == PasserAction_Move then
		bframe = actinfo.move[1]
		iframe = actinfo.move[2]
	end

	self.action_anim = GFunc_CreateAnimation(string.format("%s%d", self.info.art, self.type), bframe, iframe, nil, 0.3, nil, 2)
	self.parent:addChild(self.action_anim)

	if self.dir == PasserDir_Up then
		self.action_anim:setFlipX(true)
	elseif self.dir == PasserDir_Down then
		self.action_anim:setFlipX(true)
	end
end

function GameCityPasser:setPositionMap(row, col)
	local bposinfo = mapPathDatas[row][col]
	self:setPosition(ccp(bposinfo.x, bposinfo.y))
	self.maprow = row
	self.mapcol = col
	--print(self.maprow, self.mapcol)
end

function GameCityPasser:setPosition(value)
	-- body
	self.parent:setPosition(value)
end

function GameCityPasser:onMove(pos)
	self.moveto = pos
	self.status = PasserStatic_Moving

	--得到移动的方向
	local px, py = self.parent:getPosition()
	local dir = PasserDir_Right
	if px < pos.x and py < pos.y then
		dir = PasserDir_Right
	elseif px < pos.x and py > pos.y then
		dir = PasserDir_Down
	elseif px > pos.x and py < pos.y then
		dir = PasserDir_Up
	else
		dir = PasserDir_Left
	end
	--print(dir)
	self:onAction(PasserAction_Move, dir)
end

function GameCityPasser:onMoveToBuild()
	local binfo = mapPathDatas[self.maprow][self.mapcol]
	local cbuild = PlayerInfos:getAllBuildInfos()[binfo.mapid]
	if cbuild == nil then
		return
	end

	local saylist = {"要是能住在这里就好啦", "挻不错的", "不愧是天空岛", "真漂亮啊", "赏心悦目"}

	local function addsay(msg)
		table.insert(saylist, msg)
	end
	local bid = cbuild.bid

	local strmsg = ""
	if bid == 1 then
		saylist = {"王子是住在这里吧!!", "好想见到王子啊", "王子殿下，快出来啊!","真是漂亮","气势磅礴啊","不愧是城堡!!","我能进去看看吗","在窗口好像看到一个人影"}
	elseif bid == 2 then
		addsay("唔~~这里不会发生爆炸吧")
		addsay("感觉到一股强大的魔力")
		addsay("不知道里面有没有糖果")
		addsay("怎么闻到一股烧焦的味道?")
	elseif bid == 3 then
		if #cbuild.fieldTables == 0 then
			addsay("什么都没有啊")
			addsay("这商店要倒闭啦")
			addsay("我想买些东西")
			addsay("摆些什么上去？")
			addsay("真无聊")
		else
			addsay(string.format("我要买些%s", cbuild.fieldTables[rand(1,#cbuild.fieldTables)].name))
			addsay("居然没有糖果V_V")
			addsay("真讨厌,全是武器,魔法啊")
			addsay("这武器不错")
			addsay("买了这些我也能成为魔法师吧")
			addsay("这是成为战士的必修课")
			addsay("啊,钱不够啦")
			addsay("唔~~~~~~~~~~~~")
			addsay("不错不错")
			addsay("挻便宜哦")
			addsay("为什么这个那么贵!")
			addsay("就不能打打折么")
		end
	elseif bid == 4 then
		if #cbuild.fieldTables == 0 then
			addsay("什么都没有啊")
			addsay("小动物跑哪去了呢？")
			addsay("说好的可爱的动物呢")
			addsay("真无聊")
		else
			addsay(string.format("这只%s好可爱!!", cbuild.fieldTables[rand(1,#cbuild.fieldTables)].name))
			addsay(string.format("我也想养些%s", cbuild.fieldTables[rand(1,#cbuild.fieldTables)].name))
			addsay(string.format("我也想养只%s", cbuild.fieldTables[rand(1,#cbuild.fieldTables)].name))
			addsay(string.format("那只%s在看我哦", cbuild.fieldTables[rand(1,#cbuild.fieldTables)].name))
			addsay("好多动物哦")
			addsay("真是太可爱了")
			addsay("不知道煮了好不好吃")
			addsay("其实我不太喜欢动物")
			addsay("回家养一些也许不错")
			addsay("快点长大吧")
		end
	elseif bid == 5 then
		if #cbuild.fieldTables == 0 then
			addsay("什么都没有啊")
			addsay("先种着什么吧")
			addsay("没有种植真是浪费哦")
			addsay("真无聊")
		else
			addsay(string.format("这些%s长得不错", cbuild.fieldTables[rand(1,#cbuild.fieldTables)].name))
			addsay(string.format("那个%s看起来好好吃", cbuild.fieldTables[rand(1,#cbuild.fieldTables)].name))
			addsay(string.format("我想吃%s", cbuild.fieldTables[rand(1,#cbuild.fieldTables)].name))
			addsay(string.format("请给我%s!!!", cbuild.fieldTables[rand(1,#cbuild.fieldTables)].name))
			addsay("肚子好饿")
			addsay("新鲜的农作物哦")
			addsay("快点长大吧")
			addsay("和我家的比起来差远啦")
		end
	elseif bid == 7 then
		addsay("感觉到一股强大的魔力")
		addsay("这水不知道能不能喝")
		addsay("这是魔法泉啦")
		addsay("我要尝尝!")
		addsay("不知道喝了之后能不能成为魔法师")
	elseif bid == 8 then
		addsay("赞!!!")
		addsay("心情舒畅")
		addsay("感觉要醉倒啦")
		addsay("这花不错")
		addsay("偷偷的摘下一朵!似乎没人发现!")
	elseif bid == 9 then
		addsay("进去泡个澡没人会发现吧")
		addsay("里面好像有鱼")
		addsay("好凉爽")
	elseif bid == 10 then
		addsay("这旗是干什么的？")
		addsay("随风飘飘~~~~")
		addsay("致敬!")
		addsay("我就是想看看而已")
	end

	self:sayBy(saylist[rand(1,#saylist)])
end

function GameCityPasser:onNavigation()
	--获得第一个导航点
	if #self.navigation > 0 then
		local pos = self.navigation[1]
		table.remove(self.navigation, 1)

		--获得坐标,开始移动
		local pathinfo = mapPathDatas[pos.row][pos.col]
		--print("移动下个点",pathinfo.x,pathinfo.y)
		self:onMove(pathinfo)

		--更新坐标先
		self.maprow = pos.row
		self.mapcol = pos.col
	else
		---如果是原点,则表示回家了
		if self.maprow == brithPos.x and self.mapcol == brithPos.y then
			--print("回家了!!!!")
			self.status = PasserStatic_Home
		else
			---根据不同的位置说不同的话
			self:onMoveToBuild()

			self.status = PasserStatic_Stand
			--全部移动完成了
			--print("给我休息下")
			--休息一会
			self:onAction(PasserAction_Stand, self.dir)
	      	--self.status = PasserStatic_Stand
	      	self.parent:runAction(CCSequence:createWithTwoActions(CCDelayTime:create(rand(2,4)), CCCallFunc:create(function()
	      		--print("休息够了,继续走吧")
	      		self:onGotoShoping()
	      	end)))
      	end
	end	
end

--随机移动
function GameCityPasser:onGotoShoping()
	--如果浏览次数没了就回家吧
	if self.seeSum == 0 then
	   	local saylist = {"时间不早了","该回家了","这地方真不错，有空再来","依依不舍","妈妈叫我回家吃饭了","下次再来","肚子饿了"}
	   	self:sayBy(saylist[rand(1,#saylist)])

	   	self.navigation = AStarNavigation({row=self.maprow, col=self.mapcol, torow=brithPos.x, tocol=brithPos.y, jugemove=jugeMapPathMoved, rowsum=7, colsum=8})
   		---开始导航
   		self:onNavigation()
		return
	end

   	--从玩家所有的建筑中,选择一个要去的建筑
   	local blist = {}
   	for k,cbuild in pairs(PlayerInfos:getAllBuildInfos()) do
   		table.insert(blist, cbuild)
   	end
   	--随机
   	local gotobuild = blist[rand(1,#blist)]

   	if gotobuild == nil then
   		return
   	end

   	---说话
   	local saylist = {"",""}
   	table.insert(saylist, string.format("开开心心",gotobuild.name))
   	table.insert(saylist, string.format("充满期待",gotobuild.name))
   	table.insert(saylist, string.format("到处逛逛",gotobuild.name))
   	table.insert(saylist, string.format("去 %s 看看",gotobuild.name))
   	table.insert(saylist, string.format("我要去 %s",gotobuild.name))
   	table.insert(saylist, string.format("听说这里的 %s 不错",gotobuild.name))

   	self:sayBy(saylist[rand(1,#saylist)])

   	---获得建筑所在的地图位置,posInfo{row,col}
   	local posInfo = mapIDPathDatas[gotobuild.mapid]
 	--print("起点:",self.maprow, self.mapcol, "终点:",posInfo.x, posInfo.y)
   	---计算出移动路径
   	self.navigation = AStarNavigation({row=self.maprow, col=self.mapcol, torow=posInfo.x, tocol=posInfo.y, jugemove=jugeMapPathMoved, rowsum=7, colsum=8})

   	--for _k,_v in pairs(self.navigation) do
   	--	print("路径",_v.row, _v.col)
   	--end
   	---开始导航
   	self:onNavigation()


	--浏览次数-1
	self.seeSum = self.seeSum - 1
end

function GameCityPasser:update(dt)
	--移动
	if self.status == PasserStatic_Moving then
		local px,py = self.parent:getPosition()
		--方向
		local normalize = ccpNormalize(ccp(self.moveto.x-px, self.moveto.y-py))

		px = px + normalize.x * dt * self.speed
		py = py + normalize.y * dt * self.speed
		--print(px,py)
		local normalizeto = ccpNormalize(ccp(self.moveto.x-px, self.moveto.y-py))
		if (normalize.x > 0 and normalizeto.x < 0) or (normalize.y > 0 and normalizeto.y < 0) or
            (normalizeto.x > 0 and normalize.x < 0) or (normalizeto.y > 0 and normalize.y < 0) then
            --到达位置
          	self:setPosition(ccp(self.moveto.x, self.moveto.y))
          	self:onNavigation()
       	else
          	self:setPosition(ccp(px,py))
        end

        ---根据移动到的位置更新自己的显示层级
        local rlevel = 7
        for k=1,10 do
            local _vinfo = TableRLevelPostion[k]
            if _vinfo == nil then
                break
            end
            if _vinfo.y < py then
                rlevel = _vinfo.rlevel
                break
            end
        end
        self.parent:getParent():reorderChild(self.parent, rlevel)
	end
end