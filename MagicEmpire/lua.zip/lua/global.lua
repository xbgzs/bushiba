math.randomseed(os.time()) --初始化随机种子?相当于srand()的过程
math.random(1,10000)
--资源类型
Res_Plist   = 0x01 --plist
Res_Png     = 0x02 --png
Res_Effs    = 0x03 --音效
Res_Bgm     = 0x04 --音乐



-- 获取设备大小FontSize
FontSize = 24
FontSizeBig = 32
function GFGetFont(v)
    return v
end
DWinSize = CCDirector:sharedDirector():getWinSize()


---------------- 全局计时器
local _frame = 0
local _lastResTime = os.clock()
local function update(dt)
    _frame = _frame + 1
    GameSound_Update()
    GameJavaHandlerUpdate()
    
    if PlayerInfos then
        PlayerInfos:addGameTime(dt)
    end
end
CCDirector:sharedDirector():getScheduler():scheduleScriptFunc(update, 2.0/60, false)

function runScene()
	return CCDirector:sharedDirector():getRunningScene()
end





----------------------上方上通用
UI_Menu = 0x01
UI_Mined = 0x02
UI_MyRoles  = 0x03
UI_Main = 0x04
UI_Load = 0x05

GGamePause = false --游戏暂停标识

--操作限时(每回合操作限制的时间)
GGameOpertionFight	= 5 --秒

--最大认同等级
GGameMaxagreeLevel	= 5 --

GMoveMapStatus	= 0xff --移动中状态

---玩家属性
PlayerProperty_Hp	= 0x01 --生命值
PlayerProperty_Def	= 0x02 --防御值
PlayerProperty_Avoid= 0x03 --闪避值

--物品类型
ItemType_Yanjiu	= 0x01 --研究
ItemType_Animal	= 0x02 --动物
ItemType_Shop	= 0x03 --商店
ItemType_Farm	= 0x04 --农场
ItemType_Property	= 0x05 --玩家属性/技能

--任务类型
GTaskType_Fight	= 0x01 --战斗
GTaskType_Moved	= 0x02 --移动
GTaskType_Express= 0x03 --快递
GTaskType_Area 	= 0x04 --发现新地区
GTaskType_Agree	= 0x05 --认同度到达
GTaskType_Build	= 0x06 --建造
GTaskType_Yanjiu= 0x07 --研究
GTaskType_AddShop= 0x08 --添加商品
--任务开启条件
GTaskOpenType_Argee	= 0x01		--认同度到达
GTaskOpenType_Task	= 0x02		--任务完成
GTaskOpenType_ToArea	= 0x03	--到达地区
GTaskOpenType_FinshPlace= 0x04	--完成平叛点
GTaskOpenType_FinshArea	= 0x05	--完成地区平叛点
GTaskOpenType_AcceptTask= 0x06 	--接受任务
GTaskOpenType_AreaOpen	= 0x07 --地区开启
--任务状态
GTaskStatus_Close	= 0x01 --关闭
GTaskStatus_Open	= 0x02 --开启
GTaskStatus_Accept	= 0x03 --已接受
GTaskStatus_FinshTemp = 0x04 --完成未提交
GTaskStatus_Finsh	= 0x05 --已完成


GameYanjiu_Time	= 100 -- 研究花费时间(秒)
GameWeekTimes	= 10 --游戏中每周需要的时间(秒)

---每季最赠送宝石数
GGameTimeCrystal	= 10

--辅助角色最大等级
GRoleMaxLevel = 20
--玩家最大等级
GPlayerMaxLevel	= 20
--最大文明等级
GAreaArgeeMaxLv	= 5

--最大角色数量
GMaxRoleCount = 4

---默认技能槽数值
GFightSkillSoltValue	= 10

--战斗层事件
GFightEvent_Fight	= 0x01 --战斗
GFightEvent_Item	= 0x02 --宝物
GFightEvent_Event	= 0x03 --事件

-------角色/类型/背景
--类型(颜色):1红，2蓝，3绿，4黄，5嫩绿，6紫
GColorType_Red = 1
GColorType_Buld = 2
GColorType_Greed	= 3
GColorType_Yellow	= 4
GColorType_LGreed	= 5
GColorType_Purple	= 6
GColorType_Health	= 0x09 --治疗砖块 fangk_009
GTableRoleTypeBg = {
	[GColorType_Red] = "fuzhutou_001",
	[GColorType_Buld] = "fuzhutou_003",
	[GColorType_Greed] = "fuzhutou_002",
	[GColorType_Yellow] = "fuzhutou_005",
	[GColorType_LGreed] = "fuzhutou_004",
	[GColorType_Purple] = "fuzhutou_006",
}
GTableRoleTypeBackBg = {
	[GColorType_Red] = "fuzhutou_022",
	[GColorType_Buld] = "fuzhutou_024",
	[GColorType_Greed] = "fuzhutou_023",
	[GColorType_Yellow] = "fuzhutou_026",
	[GColorType_LGreed] = "fuzhutou_025",
	[GColorType_Purple] = "fuzhutou_027",
}
GTableBrickColors = {
	[GColorType_Red] = {255,0,0},
	[GColorType_Buld] = {0,0,255},
	[GColorType_Greed] = {0,255,0},
	[GColorType_Yellow] = {255,255,0},
	[GColorType_LGreed] = {100,200,50},
	[GColorType_Purple] = {0,255,255},
	[GColorType_Health] = {255,155,255},
}


GGameInterface_City = 0x01
GGameInterface_GoFight = 0x02
GGameInterface_Fight = 0x03
GGameInterface_Other	= 0x04
--当前显示的界面
GGameShowInterface	= GGameInterface_City




