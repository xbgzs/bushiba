------
--建造菜单类
------
function createLayerBuildMenu(endfunc)
    local layer = nil
    
    GFunc_hideBuildList()
    local function closefunc()
        CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
        if endfunc then
            endfunc()
        end

        --GFunc_hideBuildList()
    end
    
    ------------
    local touchBegin = function(x,y)
    end
    local touchMoved = function(x,y)
    end
    local touchEnded = function(x,y)
    end
    local function exitlayer()
        GFInterface_BuildInfos = nil
    end
    ----------
    layer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,100), exfunc=exitlayer, touchBegin=touchBegin, touchMoved=touchMoved, touchEnded=touchEnded})

    GFInterface_BuildInfos = layer
    ------------
    CCDirector:sharedDirector():getRunningScene():addChild(layer)
    local _parent = CCNode:create()
    layer:addChild(_parent)
    
    --背景
    local uiWidth,uiHeight = 577, 693
    local spbg = gfuncCreateUIBG({height=uiHeight})
    spbg:setPosition(ccp(uiWidth/2, uiHeight/2))
    _parent:addChild(spbg)

    ----标题栏
    local spbg = CCSprite:createWithSpriteFrameName("jiemian_104.png")
    spbg:setPosition(ccp(uiWidth/2, uiHeight-53))
    _parent:addChild(spbg)

    --标题选择sp 
    local spbg = CCSprite:createWithSpriteFrameName("jiemian_003.png")
    spbg:setPosition(ccp(uiWidth/2, uiHeight-53))
    _parent:addChild(spbg)

    local menu = CCMenu:create()
    menu:setPosition(ccp(0,0))
    _parent:addChild(menu)
    
    --关闭
    local btnItem = GFunc_CreateButtonP("jiemian_105.png", function()
        closefunc()
    end, nil, 1.5)
    btnItem:setPosition(ccp(uiWidth-10, uiHeight-30))
    menu:addChild(btnItem)
    
    ------------------------
    local function buildcallback(tag)
        --选择需要建造的建筑
        --是否拥有足够的建造资源
        --在所有已开往开启的空位中显示可建造建筑
        GFunc_ShowBulidList(tag)

        closefunc()
    end


    -------显示建筑详细信息
    local function showbuildinfos(bid)
        layer:setTouchEnabled(false)
        local binfo = GameBuildClass:new(bid,0)
        GShowBuildInfos({info=binfo, endfunc=function()
            layer:setTouchEnabled(true)
        end, detail=true});
    end

    
    --翻页界面
    local layerPage = GameContainerPage:new(DWinSize.width, DWinSize.height)
    --layerPage:addToLayer(layer)
    local _parentNode = nil
    local _pageMenu = nil
    local _pageMenuInfo = nil
    
    local _visitNodeParent = GFunc_CreateLayerVisit(layer, 530, 600, 55, 160)
    _visitNodeParent:addChild(layerPage._parnet)

    layerPage:setPosition(ccp(-110,0))
    
    --建筑列表
    local pagesum = 4 --每页数量
    
    local bpx = 195
    local bpy = 575
    local inv = 270
    local invw = 250
    local isum = 0

    for k=1,20 do
        local vbuild = true
        local info = GFuncGetTableBuilds()[k]
        if info == nil then
            vbuild = false
        end

        if info and not info.hasbuild then
            vbuild = false
        end

        ---解锁状态
        if vbuild then
            vbuild = PlayerInfos:hasUnlockBuild(info.id)
        end

        --最大数量
        if vbuild then
            local _bsum = 0
            for _k, cbuild in pairs(PlayerInfos:getAllBuildInfos()) do
                if cbuild.bid == k then
                    _bsum = _bsum + 1
                end
            end
            if _bsum >= info.maxbuild then
                vbuild = false
            end
        end

        --是否开启
        if vbuild and info.art then
            if _parentNode == nil or isum % pagesum == 0 then
                _parentNode = CCNode:create()
                layerPage:addChild(_parentNode)
                
                _pageMenu = CCMenu:create()
                _pageMenu:setPosition(ccp(0,0))
                _parentNode:addChild(_pageMenu)

                _pageMenuInfo = CCMenu:create()
                _pageMenuInfo:setPosition(ccp(0,0))
                _parentNode:addChild(_pageMenuInfo)
            end
            local pageIndex = isum%4
            local _x = bpx + (pageIndex%2) * invw
            local _y = bpy - math.floor(pageIndex/2) * inv
            --背景
            local btnItem = GFunc_CreateButtonP("jiemian_004.png", buildcallback, 1.05)
            btnItem:setPosition(ccp(_x,_y))
            _pageMenu:addChild(btnItem,0,k)
            local _psize = btnItem:getNormalImage():getContentSize()

            ---显示详细信息按钮
            local btnItemInfos = GFunc_CreateButtonP("jiemian_005.png", function(tag)
                --print("详细")
                showbuildinfos(tag)
            end, nil, 3)
            btnItemInfos:setPosition(ccp(_x+_psize.width/2-20,_y+_psize.height/2-20))
            _pageMenuInfo:addChild(btnItemInfos, 0, k)


            --图片
            local spbg = CCSprite:createWithSpriteFrameName(string.format("%s.png", info.art))
            --spbg:setAnchorPoint(ccp(0,0))
            spbg:setPosition(ccp(_psize.width/2,_psize.height/2))
            btnItem:addChild(spbg)

            --建造费用
            local spmoney = GameNumbers:new(vNumberBFHui, NumberAlginment_Right)
            spmoney:setPosition(ccp(_psize.width-20,30))
            spmoney:addLayer(btnItem)
            spmoney:setString(info.money)

            --名称sp
            if info.namesp then
                --名称背景sp
                local spbg = CCSprite:createWithSpriteFrameName("jiemian_107.png")
                spbg:setPosition(ccp(_psize.width/2,_psize.height + 25))
                btnItem:addChild(spbg)

                local spbg = CCSprite:createWithSpriteFrameName(string.format("%s.png", info.namesp))
                spbg:setPosition(ccp(_psize.width/2,_psize.height + 25))
                btnItem:addChild(spbg)
            end

            --是否有足够金钱
            if PlayerInfos:getMoney() < info.money then
                btnItem:setEnabled(false)
                btnItem:setColor(ccc3(155,155,155))
                spbg:setColor(ccc3(155,155,155))
            end
            
            isum = isum + 1
        end
    end

    ----根据显示页数与当前而显示相关换页按钮
    local pageItemlist = {}
    local function clickPageItem(tag, callback)
        for k, item in pairs(pageItemlist) do
            if k == tag then
                item:setEnabled(false)
            else
                item:setEnabled(true)
            end
        end
        --print(tag,callback)
        if callback == nil then
            layerPage:showPage(tag)
        end
    end

    --根据页数显示按钮数
    for k=1, layerPage:getPageSum() do
        local btnItem = GFunc_CreateButtonDPOther("jiemian_112.png", "jiemian_113.png", function(tag)clickPageItem(tag)end, nil, 2.0)
        btnItem:setPosition(ccp(uiWidth-70 - ((k-1)*50), 40))
        local _pagekey = layerPage:getPageSum()-k
        pageItemlist[_pagekey] = btnItem
        menu:addChild(btnItem, 0, _pagekey)
    end

    ---前翻与后翻
    local btnNextPage = GFunc_CreateButtonP("jiemian_108.png", function()
        layerPage:Show_Layer(true)
    end, nil, 1.5)
    btnNextPage:setPosition(ccp(uiWidth-15, uiHeight/2-20))
    menu:addChild(btnNextPage)

    local function pageEndCallback(_showpage)
        --print("翻页完成",_showpage)
        clickPageItem(_showpage, true)
    end
    clickPageItem(0)

    layerPage:setNextPageFunc(pageEndCallback)
    
    ------------------------
    --界面显示位置
    _parent:setPosition(ccp(DWinSize.width/2 - uiWidth/2, DWinSize.height/2 - uiHeight/2))
end




