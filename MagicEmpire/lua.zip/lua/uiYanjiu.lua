------
--研究菜单类
------
local _interfaceShowTask = nil
function CloseInterfaceTask()
    if _interfaceShowTask then
        _interfaceShowTask()
        _interfaceShowTask = nil
    end
end

---记录新任务的数量
local GVNewTaskCount = 0
function GGameFuncNewTasks(v)
    if v == nil then
        v = 1
    end
    GVNewTaskCount = GVNewTaskCount + 1
end
function GGameFuncSetTaskCount(v)
    -- body
    if v == nil then
        v = 0
    end
    GVNewTaskCount = v
end
function GGameFuncInitTaskCount()
    GVNewTaskCount = 0
end
function GGameFuncGetTaskCount()
    -- body
    return GVNewTaskCount
end

---显示任务的详细信息
function GShowDialogTaskMessage(args)
    local tid,endfunc = args.tid, args.func

    local info = GFuncGetTaskForID(tid)
    local _mid = info.mid
    if info.type == GTaskType_Area then
        _mid = info.param
    end
    if _mid == nil then
        _mid = 0
    end

    local layer = nil
    local parentX, parentY = 0,0

    local function closeFunc(_args)
        if _args == nil then
            _args = {}
        end
        ----
        CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
        if endfunc then
            endfunc(_args)
        end
    end

    local function exitlayer()
        GFInterface_TaskDetail = nil
    end

    layer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150),fmbg=true, exfunc=exitlayer})
    CCDirector:sharedDirector():getRunningScene():addChild(layer)

    GFInterface_TaskDetail = layer

    local _parent = CCNode:create()
    layer:addChild(_parent)
    local _menu = CCMenu:create()
    _menu:setPosition(ccp(0,0))
    _parent:addChild(_menu,1)

    --背景
    local uiWidth,uiHeight = 577, 615
    local spbg = gfuncCreateUIBG({height=uiHeight})
    spbg:setPosition(ccp(uiWidth/2, uiHeight/2))
    _parent:addChild(spbg)

    ----标题栏
    local spbg = CCSprite:createWithSpriteFrameName("jiemian_104.png")
    spbg:setPosition(ccp(uiWidth/2, uiHeight-53))
    _parent:addChild(spbg)

    --描述bgsp
    local spvbg = CCScale9Sprite:createWithSpriteFrameName("jiemian_080.png", CCRectMake(20, 20, 10, 10))
    spvbg:setContentSize(CCSizeMake(500, 110))
    spvbg:setPosition(ccp(uiWidth/2, 440))
    _parent:addChild(spvbg)

    --其它信息sp
    local spbg = CCSprite:createWithSpriteFrameName("jiemianrenwu_002.png")
    spbg:setPosition(ccp(40, 220))
    spbg:setAnchorPoint(ccp(0,0))
    _parent:addChild(spbg)

    --报酬sp
    local spbg = CCSprite:createWithSpriteFrameName("jiemianrenwu_001.png")
    spbg:setPosition(ccp(40, 158))
    spbg:setAnchorPoint(ccp(0,0))
    _parent:addChild(spbg)


    --接受任务
    local function funcAcceptTask()
        --移动任务需要在当地才可以接受
        if info.type == GTaskType_Moved then
            local strMapname = MapArea_Static[_mid].name
            if info.mid ~= PlayerInfos.mapID then
                GFunc_ShowGameDialogMessage({msg=string.format("请先来 %s，这样我才能和你们一起移动", strMapname),
                    color=ccc3(250,245,170)})
                return
            end
        end
        GFuncAcceptTask(tid)
        closeFunc({accept=true,info=info})
    end
    --完成任务
    local function funcFinshTask()
        closeFunc({close=true, finsh=true, info=info})
    end

    --未接受的任务才显示接受按钮
    if info.status == GTaskStatus_Open then
        local btnItem = GFunc_CreateButtonP("jiemian_099.png", funcAcceptTask,nil,1.5)
        btnItem:setPosition(ccp(uiWidth/2, 70))
        _menu:addChild(btnItem)
    elseif info.status == GTaskStatus_FinshTemp then
        ---显示完成任务按钮
        local btnItem = GFunc_CreateButtonP("ictgetr.png", funcFinshTask,nil,1.5)
        btnItem:setPosition(ccp(uiWidth/2, 70))
        _menu:addChild(btnItem)
    end
    --已经完成的任务显示已完成
    if info.status == GTaskStatus_Finsh then
        local txt = CCLabelTTF:create("已完成", "Arial", 32)
        txt:setPosition(ccp(uiWidth/2, 70))
        _parent:addChild(txt)
    end

    --关闭
    local btnItem = GFunc_CreateButtonP("jiemian_105.png", function()
        closeFunc()
    end, nil, 1.5)
    btnItem:setPosition(ccp(uiWidth-10, uiHeight-30))
    _menu:addChild(btnItem)
    if args.close then
        btnItem:setEnabled(false)
        btnItem:setVisible(false)
    end

    -----描述
    --标题
    local txt = CCLabelTTF:create(info.name, "Arial", 32)
    txt:setPosition(ccp(uiWidth/2, uiHeight-53))
    _parent:addChild(txt)
    --未解决事件txt 序列/总数

    --描述txt
    local txt = CCLabelTTF:create(info.des or "", "Arial", 28, CCSizeMake(460, 0), kCCTextAlignmentLeft)
    txt:setAnchorPoint(ccp(0,1))
    txt:setPosition(ccp(60, 480))
    txt:setColor(ccc3(169,135,87))
    _parent:addChild(txt)

    --地区sp
    if MapArea_Static[_mid] then
        local spbg = CCSprite:createWithSpriteFrameName(string.format("%s.png",MapArea_Static[_mid].namesp))
        spbg:setPosition(ccp(360, 342))
        _parent:addChild(spbg)
    end
    --必须品(赠送物品)

    --时间num
    local time = info.time
    if time == nil then
        time = 999
    else
        time = info.time - info.elaptime
    end
    local txt = CCLabelTTF:create(string.format("%d 周", time), "Arial", 32)
    txt:setPosition(ccp(430, 240))
    txt:setAnchorPoint(ccp(1,0.5))
    _parent:addChild(txt)
    --报酬 钱num
    local spbg = CCSprite:createWithSpriteFrameName(SIconMoney)
    spbg:setAnchorPoint(ccp(0,0.5))
    spbg:setPosition(ccp(490, 180))
    _parent:addChild(spbg)

    local numberLv = GameNumbers:new(vNumberWhite, NumberAlginment_Right)
    numberLv:addLayer(_parent)
    numberLv:setPosition(ccp(480, 175))
    numberLv:setString(info.rmoney or 0)

    --必须品
    if info.type == GTaskType_Express and info.param then
        local rparaminfos = lua_string_split(info.param or "", "+")
        local param1 = rparaminfos[1]+0
        local param2 = rparaminfos[2]+0
        local txt = CCLabelTTF:create(string.format("%sx%d", ItemList_Static[param1].name, param2), "Arial", 32)
        txt:setPosition(ccp(430, 290))
        txt:setAnchorPoint(ccp(1,0.5))

        --是否有指定道具,没有则显示红色
        if PlayerInfos:getItem(param1) < param2 then
            txt:setColor(ccc3(255,80,5))
        end

        _parent:addChild(txt)
    end

    --报酬,物品
    if info.ritem then
        local rparaminfos = lua_string_split(info.ritem or "", "+")
        local param1 = rparaminfos[1]+0
        local param2 = rparaminfos[2]+0
        --print("赠品",info.ritem,param1,param2,ItemList_Static[param1].name)
        local txt = CCLabelTTF:create(string.format("%s*%d", ItemList_Static[param1].name, param2), "Arial", 32)
        txt:setPosition(ccp(170, 175))
        txt:setAnchorPoint(ccp(0,0.5))
        _parent:addChild(txt)
    end


    --界面显示位置
    parentX, parentY = DWinSize.width/2 - uiWidth/2, DWinSize.height/2 - uiHeight/2
    _parent:setPosition(ccp(parentX, parentY))
    --print(parentX, parentY)
end

---创建任务接受显示菜单
function createLayerTaskMenu(endfunc)
    local layer = nil
    local _container = nil
    local btnTables = {}
    local btnContainerTables = {}
    local parentX, parentY = 0,0

    local vTypeNoFinsh = 1
    local vTypeFinsh = 2

    --加载列表
    local reloadTaskList = nil

    ---获得所有已经解锁的任务列表
    local items = {}
    local function closeFunc(_args)
        if _args == nil then
            _args = {}
        end
        ----
        CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
        if endfunc then
            endfunc(_args)
        end
    end
    _interfaceShowTask = closeFunc

    local beginPickY = 0
    local function touchContainer(x,y,eventType)
        --print(x,y)
        local isclick = false
        if eventType == CCTOUCHENDED and (y >= 195 and y <= 720) and math.abs(beginPickY-y) < 20 then
            isclick = true
        end
        local _mx, _my = _container:getPosition()
        GFunc_SelectBtnRun(btnContainerTables,x-parentX-_mx,y-parentY-_my,eventType, isclick)
        if (y >= 195 and y <= 720) then
            _container:onTouch(x-parentX,y-parentY,eventType)
        end
    end

    local function touchBegin(x,y,eventType)
        beginPickY = y
        touchContainer(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x-parentX,y-parentY,eventType)
    end
    local function touchMoved(x,y, eventType)
        touchContainer(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x-parentX,y-parentY,eventType)
    end
    local function touchEnded(x,y,eventType)
        touchContainer(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x-parentX,y-parentY,eventType)
    end

    local function exitlayer()
        GFInterface_Tasks = nil
        _interfaceShowTask = nil
    end

    layer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,100),update=update,exfunc=exitlayer,
        touchBegin=touchBegin, touchMoved=touchMoved, touchEnded=touchEnded, fmbg = true})
    CCDirector:sharedDirector():getRunningScene():addChild(layer)

    GFInterface_Tasks = layer

    local _parent = CCNode:create()
    layer:addChild(_parent)
    local _menu = CCMenu:create()
    _menu:setPosition(ccp(0,0))
    _parent:addChild(_menu,1)

    local uiWidth,uiHeight = 577, 638
    local spbg = gfuncCreateUIBG({height=uiHeight})
    spbg:setPosition(ccp(uiWidth/2, uiHeight/2))
    _parent:addChild(spbg)


    ----标题栏
    local spbg = CCSprite:createWithSpriteFrameName("jiemian_104.png")
    spbg:setPosition(ccp(uiWidth/2, uiHeight-53))
    _parent:addChild(spbg)
    

    --遮罩
    local visitWidth = uiWidth-42
    local _nodeParentLayerVisit = GFunc_CreateLayerVisit(_parent, visitWidth, 520, 25, 25)
    --排列容器
    _container = GameSildeContainer:new(0, 0, SildeContainer_UpDown)
    _container:addToLayer(_nodeParentLayerVisit)

    local menu = CCMenu:create()
    menu:setPosition(ccp(0,0))
    _container:addElementChild(menu)


    local function accceptTask_s(info)
        local _strmsg = nil
        local strMapname = ""
        if info.mid then
            strMapname = MapArea_Static[info.mid].name
        end
        
        --移动任务需要在当地才可以接受
        if info.type == GTaskType_Moved then
            _strmsg = string.format("请尽快送我到 [%s]", strMapname)
        elseif info.type == GTaskType_Express then
            --必须品
            if info.param then
                local rparaminfos = lua_string_split(info.param or "", "+")
                local param1 = rparaminfos[1]+0
                local param2 = rparaminfos[2]+0
                _strmsg = string.format("我需要 %s x%d，我在 [%s] 等你，请赶快!", ItemList_Static[param1].name, param2, strMapname)
            end
        elseif info.type == GTaskType_Area then
            _strmsg = string.format("从出征界面前往下一个地区 [%s] 吧", MapArea_Static[info.param].name)
        elseif info.type == GTaskType_Fight then
            _strmsg = string.format("%s", info.des)
        end

        if _strmsg ~= nil then
            local function closemsg()
                layer:setTouchEnabled(true)
                layer.menu:setTouchEnabled(true)
            end
            local _argsmsg = {
                func=closemsg,
                color=ccc3(250,245,170),
                msg=_strmsg,
            }
            layer:setTouchEnabled(false)
            layer.menu:setTouchEnabled(false)
            GFunc_ShowGameDialogMessage(_argsmsg)
        end
    end


    local allItems = {}
    --获取已经开启的商品项目
    local inv = 66
    local psum = 6
    reloadTaskList = function(_type)
        local items = {}
        if _type == vTypeFinsh then
            for _k,_v in pairs(PlayerInfos.finshTasks) do
                table.insert(items, _k)
            end
        else
            for _k,_v in pairs(PlayerInfos.acceptTasks) do
                table.insert(items, _k)
            end
            for _k,_v in pairs(PlayerInfos.finshTempTasks) do
                table.insert(items, _k)
            end
            for _k,_v in pairs(PlayerInfos.nofinshTasks) do
                table.insert(items, _k)
            end
        end

        for _k,_v in pairs(btnContainerTables) do
            menu:removeChild(_v, true)
        end
        btnContainerTables = {}

        local index = 0
        for _k,_tid in pairs(items) do
            local info = GFuncGetTaskForID(_tid)
            --列出项目
            local function clickItem(tag)
                --显示任务详细
                layer:setTouchEnabled(false)
                layer:setVisible(false)
                layer.menu:setTouchEnabled(false)
                GShowDialogTaskMessage({tid=tag, func=function(_args)
                    layer:setTouchEnabled(true)
                    layer:setVisible(true)
                    layer.menu:setTouchEnabled(true)
                    if _args.accept then
                        accceptTask_s(_args.info)
                    end
                    if _args.finsh then
                        layer:setTouchEnabled(false)
                        layer.menu:setTouchEnabled(false)
                        PlayerInfos:onFinshTask(info.id, function()
                            layer:setTouchEnabled(true)
                            layer.menu:setTouchEnabled(true)
                        end)
                    end
                    if _args.accept or _args.close then
                        reloadTaskList()
                    end
                end})
            end
            local btnItem = GFunc_CreateButtonLabel("", clickItem, nil, CCSizeMake(uiWidth-60, inv))
            btnItem:setPosition(ccp(visitWidth/2, 520 - inv * index))
            menu:addChild(btnItem, 0, _tid)
            table.insert(btnContainerTables, btnItem)
            --背景
            --local color = nil
            if index % 2 == 0 then
                --color = ccc4f(206/255.0,221/255.0,106/255.0,1)
            else
                --color = ccc4f(250/255.0,245/255.0,170/255.0,1)
                local stencil = CCSprite:createWithSpriteFrameName("jiemian_114.png")
                stencil:setAnchorPoint(ccp(0,0.5))
                stencil:setPosition(ccp(0-40, inv/2))
                btnItem:addChild(stencil)
            end
            index = index + 1

            --local stencil = CCDrawNode:create()
            --stencil:drawSegment(ccp(-uiWidth/2,0), ccp(uiWidth,0), inv/2, color)
            --stencil:setPosition(ccp(uiWidth/2, inv/2))
            --btnItem:addChild(stencil)

            local itemname = info.name
            local sp = CCLabelTTF:create(itemname, "Arial", 32)
            sp:setAnchorPoint(ccp(0,0.5))
            sp:setPosition(ccp(0, inv/2))
            sp:setColor(ccc3(93,139,69))
            btnItem:addChild(sp)

            --任务状态>接受,未接受,已完成
            local strStutas = ""
            if info.status == GTaskStatus_Open then
                strStutas = ""
            elseif info.status == GTaskStatus_Accept then
                strStutas = "已接受"
            elseif info.status == GTaskStatus_FinshTemp or info.status == GTaskStatus_Finsh then
                strStutas = "已完成"
            end
            --print(info.name, info.status)
            local sp = CCLabelTTF:create(strStutas, "Arial", 28)
            sp:setAnchorPoint(ccp(1,0.5))
            sp:setPosition(ccp(visitWidth-50, inv/2))
            sp:setColor(ccc3(109,121,32))
            btnItem:addChild(sp)
        end
        _container:setSize(nil, inv*index- psum *inv)
    end

    -------///////////////
    local btnItemFinsh = nil
    local btnItemNoFinsh = nil
    local function changeTaskList(tag)
        btnItemFinsh:setEnabled(true)
        btnItemNoFinsh:setEnabled(true)
        if tag == vTypeFinsh then
            btnItemNoFinsh:setEnabled(false)
        else
            btnItemFinsh:setEnabled(false)
        end
        reloadTaskList(tag)
    end

    --可接受任务
    btnItemFinsh = GFunc_CreateButtonDPOther("jiemian_134.png", "jiemian_128.png", changeTaskList, nil, 1.5)
    btnItemFinsh:setPosition(ccp(200,uiHeight- 53))
    _menu:addChild(btnItemFinsh,0, vTypeNoFinsh)
    table.insert(btnTables, btnItemFinsh)

    --已解决任务
    btnItemNoFinsh = GFunc_CreateButtonDPOther("jiemian_135.png", "jiemian_129.png", changeTaskList, nil, 1.5)
    btnItemNoFinsh:setPosition(ccp(350,uiHeight- 53))
    _menu:addChild(btnItemNoFinsh,0, vTypeFinsh)
    table.insert(btnTables, btnItemNoFinsh)


    changeTaskList(vTypeNoFinsh)


    --关闭
    local btnItem = GFunc_CreateButtonP("jiemian_105.png", function()
        closeFunc()
    end, nil, 1.5)
    btnItem:setPosition(ccp(uiWidth-10, uiHeight-30))
    _menu:addChild(btnItem)
    table.insert(btnTables, btnItem)

    --界面显示位置
    parentX, parentY = DWinSize.width/2 - uiWidth/2, DWinSize.height/2 - uiHeight/2
    _parent:setPosition(ccp(parentX, parentY))


    -------------打开任务界面,初始化新任务数
    GGameFuncInitTaskCount()
end


-------------显示研究菜单
function createLayerYanJiuMenu(buildInfos, endfunc)
    local layer = nil
    local _container = nil
    local btnTables = {}
    local btnContainerTables = {}
    local parentX, parentY = 0,0

    --加载列表
    local reloadTaskList = nil

    -----如果正在研究中,则显示研究中界面
    --if buildInfos.onYanjiu == 1 then
    --    createLayerYanJiuRuning(buildInfos, endfunc)
    --    return
    --end

    ---获得所有所有拥有的研究道具列表
    local items = {}
    local function closeFunc(_args)
        if _args == nil then
            _args = {}
        end
        ----
        CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
        if endfunc then
            endfunc(_args)
        end
    end

    local beginPickY = 0
    local function touchContainer(x,y,eventType)
        local isclick = false
        if eventType == CCTOUCHENDED and (y >= 310 and y <= 700) and math.abs(beginPickY-y) < 20 then
            isclick = true
        end
        local _mx, _my = _container:getPosition()
        GFunc_SelectBtnRun(btnContainerTables,x-parentX-_mx,y-parentY-_my,eventType, isclick)
        if (y >= 310 and y <= 700) then
            _container:onTouch(x-parentX,y-parentY,eventType)
        end
    end

    local function touchBegin(x,y,eventType)
        beginPickY = y
        touchContainer(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x-parentX,y-parentY,eventType)
    end
    local function touchMoved(x,y, eventType)
        touchContainer(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x-parentX,y-parentY,eventType)
    end
    local function touchEnded(x,y,eventType)
        touchContainer(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x-parentX,y-parentY,eventType)
    end
    local function exitlayer()
        GFInterface_Yanjiu = nil
    end 

    layer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,155),update=update,exfunc=exitlayer,
        touchBegin=touchBegin, touchMoved=touchMoved, touchEnded=touchEnded, fmbg = true})
    CCDirector:sharedDirector():getRunningScene():addChild(layer)

    GFInterface_Yanjiu = layer

    local _parent = CCNode:create()
    layer:addChild(_parent)
    local _menu = CCMenu:create()
    _menu:setPosition(ccp(0,0))
    _parent:addChild(_menu,1)


    local uiWidth,uiHeight = 577, 638
    local spbg = gfuncCreateUIBG({height=uiHeight})
    spbg:setPosition(ccp(uiWidth/2, uiHeight/2))
    _parent:addChild(spbg)


    ----标题栏
    local spbg = CCSprite:createWithSpriteFrameName("jiemian_104.png")
    spbg:setPosition(ccp(uiWidth/2, uiHeight-53))
    _parent:addChild(spbg)
    

    --遮罩
    local visitWidth = uiWidth-42
    local _nodeParentLayerVisit = GFunc_CreateLayerVisit(_parent, visitWidth, 520, 25, 25)
    --排列容器
    _container = GameSildeContainer:new(0, 0, SildeContainer_UpDown)
    _container:addToLayer(_nodeParentLayerVisit)


    local menu = CCMenu:create()
    menu:setPosition(ccp(0,0))
    _container:addElementChild(menu)


    local function funcYanjiuBegin(info)
        --开始研究
        buildInfos:YanjiuBegin(info.id)
        closeFunc({reload=true})
    end


    local allItems = {}
    --获取已经开启的商品项目
    local inv = 66
    local psum = 6
    reloadTaskList = function(_type)
        local items = {}--PlayerInfos:getYanJius()

        local function additem(_info, _v)
            table.insert(items, {info=_info, sum= _v.sum})
        end

        ---玩家属性研究
        for k,v in pairs(PlayerInfos.finshyanjius) do
            local _infov = PlayerInfos:getItems()[k]
            local info = ItemList_Static[k]
            --print(k,_infov)
            if info and _infov.sum > 0 and info.type == ItemType_Property then
                ---已解锁
                local info = ItemList_Static[k]
                additem(info, _infov)
            end
        end

        ---道具研究
        for k,v in pairs(PlayerInfos:getItems()) do
            local info = ItemList_Static[k]
            if info and v.sum > 0 and info.type == ItemType_Yanjiu then
                if _type == 1 then
                    additem(info, v)
                else
                    if info.item then
                        if _type == 2 and ItemList_Static[info.item].type == ItemType_Shop then
                            additem(info, v)
                        elseif _type == 3 and ItemList_Static[info.item].type == ItemType_Farm then
                            additem(info, v)
                        end
                    elseif _type == 4 and info.role then
                        additem(info, v)
                    end
                end
            end
        end

        for _k,_v in pairs(btnContainerTables) do
            menu:removeChild(_v, true)
        end
        btnContainerTables = {}

        table.sort(items, function(a,b) return a.info.id < b.info.id end)

        local index = 0
        for _k,_info in pairs(items) do
            local info = _info.info
            local sum = _info.sum

            --列出项目
            local function clickItem(tag)
                ---是否有足够的研究点数
                if PlayerInfos:getMagic() < (items[tag].info.magic or 0) then
                    layer:setTouchEnabled(false)
                    GFunc_ShowGameDialogMessage({msg="用于研究的魔法点数不足~", func=function()
                        layer:setTouchEnabled(true)
                        end})
                    return
                end

                local function enddialogclose(_args)
                    layer:setTouchEnabled(true)
                    if _args.enter then
                        funcYanjiuBegin(items[tag].info)
                        --扣除相应的魔法点数
                        PlayerInfos:addMagic(-(items[tag].info.magic or 0))
                    end
                end
                layer:setTouchEnabled(false)
                GFunc_ShowDialogEnterClance({msg=string.format("开始研究\n%s",items[tag].info.name), func=enddialogclose})
            end
            local btnItem = GFunc_CreateButtonLabel("", clickItem, nil, CCSizeMake(visitWidth, inv))
            btnItem:setPosition(ccp(visitWidth/2, 520 - inv * index))
            menu:addChild(btnItem, 0, _k)
            table.insert(btnContainerTables, btnItem)
            --背景
            if index % 2 == 1 then
                local stencil = CCSprite:createWithSpriteFrameName("jiemian_114.png")
                stencil:setAnchorPoint(ccp(0,0.5))
                stencil:setPosition(ccp(0-40, inv/2))
                btnItem:addChild(stencil)
            end
            index = index + 1

            local itemname = info.name
            local sp = CCLabelTTF:create(itemname, "Arial", 28)
            sp:setAnchorPoint(ccp(0,0.5))
            sp:setPosition(ccp(0, inv/2))
            sp:setColor(ccc3(93,139,69))
            btnItem:addChild(sp)

            ---消耗魔法点
            local spoutMoney = GameNumbers:new(vNumberBFHui, NumberAlginment_Right)
            spoutMoney:setPosition(ccp(visitWidth-265, inv/2))
            spoutMoney:addLayer(btnItem)
            spoutMoney:setString(info.magic)
            --魔法点图标
            spmoneyIcon = CCSprite:createWithSpriteFrameName(SIconMagic)
            spmoneyIcon:setPosition(ccp(visitWidth-260, inv/2))
            spmoneyIcon:setAnchorPoint(ccp(0,0.5))
            btnItem:addChild(spmoneyIcon)

            --显示可研究的物品信息
            local spv = CCLabelTTF:create("", "Arial", 26)
            spv:setAnchorPoint(ccp(1,0.5))
            spv:setPosition(ccp(visitWidth-40, inv/2))
            spv:setColor(ccc3(230,150,25))
            btnItem:addChild(spv)

            ---如果已经有数据则表示研究/获得过了
            if PlayerInfos:getItems()[info.item] ~= nil then
                if info.type == ItemType_Property then
                    spv:setString("属性提升")
                else
                    spv:setString(string.format("获得 %s",ItemList_Static[info.item].name))
                end
            else
                spv:setString("未知")
            end
            if info.role ~= nil then
                spv:setString(string.format("经验up %s", GFuncGetTableRoles()[info.role].name))

                if info.role ~= nil and PlayerInfos:getAidPlayers()[info.role] == nil then
                    --没有则不可研究
                    spv:setColor(ccc3(220,220,220))
                    sp:setColor(ccc3(220,220,220))
                    btnItem:setEnabled(false)

                    spv:setString("未发现的勇者")
                else
                    spv:setString(string.format("经验up %s", GFuncGetTableRoles()[info.role].name))
                end
            end
        end
        _container:setSize(nil, inv*index- psum *inv)
    end

    -------///////////////
    local btnItemAll = nil
    local btnItemItem = nil
    local btnItemFrame = nil
    local btnItemRole = nil
    local function changeTaskList(tag)
        btnItemAll:setEnabled(true)
        btnItemItem:setEnabled(true)
        btnItemFrame:setEnabled(true)
        btnItemRole:setEnabled(true)
        if tag == 1 then
            btnItemAll:setEnabled(false)
        elseif tag == 2 then
            btnItemItem:setEnabled(false)
        elseif tag == 3 then
            btnItemFrame:setEnabled(false)
        elseif tag == 4 then
            btnItemRole:setEnabled(false)
        end
        reloadTaskList(tag)
    end

    local bpx = 140
    local bpy = uiHeight- 53
    local inv = 100
    --
    btnItemAll = GFunc_CreateButtonDPOther("jiemian_156.png", "jiemian_152.png", changeTaskList, nil, 1.5)
    btnItemAll:setPosition(ccp(bpx + inv * 0, bpy))
    _menu:addChild(btnItemAll,0, 1)
    table.insert(btnTables, btnItemAll)

    --
    btnItemItem = GFunc_CreateButtonDPOther("jiemian_157.png", "jiemian_153.png", changeTaskList, nil, 1.5)
    btnItemItem:setPosition(ccp(bpx + inv * 1, bpy))
    _menu:addChild(btnItemItem,0, 2)
    table.insert(btnTables, btnItemItem)

    btnItemFrame = GFunc_CreateButtonDPOther("jiemian_158.png", "jiemian_154.png", changeTaskList, nil, 1.5)
    btnItemFrame:setPosition(ccp(bpx + inv * 2, bpy))
    _menu:addChild(btnItemFrame,0, 3)
    table.insert(btnTables, btnItemFrame)

    btnItemRole = GFunc_CreateButtonDPOther("jiemian_159.png", "jiemian_155.png", changeTaskList, nil, 1.5)
    btnItemRole:setPosition(ccp(bpx + inv * 3, bpy))
    _menu:addChild(btnItemRole,0, 4)
    table.insert(btnTables, btnItemRole)

    changeTaskList(1)


    --关闭窗口
    local btnItem = GFunc_CreateButtonP("jiemian_105.png", function()
        closeFunc()
    end, nil, 2)
    btnItem:setPosition(ccp(uiWidth-10, uiHeight-30))
    _menu:addChild(btnItem)
    table.insert(btnTables, btnItem)

    --界面显示位置
    parentX, parentY = DWinSize.width/2 - uiWidth/2, DWinSize.height/2 - uiHeight/2
    _parent:setPosition(ccp(parentX, parentY))
end

function createNodeYanJiuRuning(args)
    local buildInfos = args.info
    local txtTitle = nil
    local progress = nil
    local txtTime = nil
    local btnItemFinsh = nil

    local function closeFunc(_args)
        if _args == nil then
            _args = {}
        end

        if args.funcfinsh then
            args.funcfinsh(_args)
        end
    end

    local function update(dt)
        ---
        if buildInfos.onYanjiu == 1 then
            --print(PlayerInfos.Yanjiutime)
            progress:update(buildInfos.Yanjiutime)
            txtTime:setString(string.format("剩余时间: %d 秒", ConsertInt(GameYanjiu_Time - buildInfos.Yanjiutime)))
        else
            txtTime:setString("研究完成")
            btnItemFinsh:setEnabled(false)
            btnItemFinsh:setVisible(false)
            closeFunc()
        end
    end

    local _parent = GFunc_CreateLayerEnterOrExit({update=update,fps=0.1})
    args.parent:addChild(_parent)

    --研究标题
    txtTitle = CCLabelTTF:create(string.format("[%s]研究正在进行中", ItemList_Static[buildInfos.YanjiuItemID].name), "Arial", 38)
    txtTitle:setAnchorPoint(ccp(0,0.5))
    txtTitle:setColor(ccc3(139,99,36))
    txtTitle:setPosition(ccp(50, 270))
    args.parent:addChild(txtTitle)


    --研究的进度条
    progress = GameProgressCrols:new("jiemian_068.png", "jiemian_067.png")
    progress:setAllProgress(GameYanjiu_Time)
    progress:setPosition(ccp(80, 210))
    progress:addToParent(args.parent)

    --剩余时间
    txtTime = CCLabelTTF:create("", "Arial", 28)
    txtTime:setAnchorPoint(ccp(0.5,0.5))
    txtTime:setColor(ccc3(139,99,36))
    txtTime:setPosition(ccp(args.uiWidth/2, 160))
    args.parent:addChild(txtTime)

    --立即完成建造按钮
    btnItemFinsh = createFirstbuttom(buildInfos, function(tag)
        buildInfos.Yanjiutime = GameYanjiu_Time
    end)
    btnItemFinsh:setPosition(ccp(args.uiWidth/2, 80))
    args.menu:addChild(btnItemFinsh)
    table.insert(args.btnTables, btnItemFinsh)

    update()
end