local scene = nil
local layer = nil

-- 菜单显示层
local function initWithLayer(endfunc)
    layer = nil
    
    ----------
    layer = GFunc_CreateLayerEnterOrExit()
    ------------
    
    local spbg = CCSprite:create("res/logo_bg.png")
    spbg:setAnchorPoint(ccp(0, 0))
    layer:addChild(spbg)
    
    local menu = CCMenu:create()
    menu:setPosition(ccp(0,0))
    layer:addChild(menu,2)
    --
    local menu2 = CCMenu:create()
    menu2:setPosition(ccp(0,0))
    layer:addChild(menu2,3)

    local function createDataInterface(index, pos)
        --存档
        local btnItemBg = GFunc_CreateButtonP("jiemian_020.png", function(tag)
            LoadingGameDatas(tag)
            createLayerMainMenu()
        end,1.05)
        btnItemBg:setPosition(pos)
        menu:addChild(btnItemBg,0,index)
        --确定sp
        --local spbg = CCSprite:createWithSpriteFrameName("jiemian_022.png")
        --spbg:setPosition(ccp(btnItemBg:getNormalImage():getContentSize().width/2, 20))
        --btnItemBg:addChild(spbg)
        ---存档
        local labeldata = CCLabelTTF:create(string.format("存档%s",index == 1 and "一" or "二"), "Arial", 28)
        labeldata:setAnchorPoint(ccp(0,1))
        labeldata:setPosition(ccp(10, btnItemBg:getNormalImage():getContentSize().height-10))
        labeldata:setColor(ccc3(0,0,0))
        btnItemBg:addChild(labeldata)

        ------------存档中的游戏时间
        local strdata = Config_LoadGameData(index)
        --print(strdata)
        if strdata ~= nil and strdata ~= "" then
            local sdata = unserialize(strdata)
            --游戏时间
            local _strtime = ConsertInt(sdata.citytime)
            --总周
            local iallweek = math.floor(_strtime/GameWeekTimes)
            --总月
            local iallmonth = math.floor(iallweek/4)
            --年
            local iyear = math.floor(iallmonth/12)+1
            --月
            local imonth = iallmonth%12+1
            --周
            local iweek = iallweek%4+1


            ---时间
            local labeltime = CCLabelTTF:create(string.format("%d年%d月%d周",iyear,imonth,iweek), "Arial", 28)
            labeltime:setAnchorPoint(ccp(0,0))
            labeltime:setPosition(ccp(30,15))
            labeltime:setColor(ccc3(139,99,36))
            btnItemBg:addChild(labeltime)
            --金钱
            local spoutMoney = GameNumbers:new(vNumberWhite, NumberAlginment_Right)
            spoutMoney:setPosition(ccp(295,90))
            spoutMoney:addLayer(btnItemBg)
            spoutMoney:setString(sdata.money+ memoryMoney)
            local spmoneyIcon = CCSprite:createWithSpriteFrameName(SIconMoney)
            spmoneyIcon:setAnchorPoint(ccp(0,0.5))
            spmoneyIcon:setPosition(ccp(300,90))
            btnItemBg:addChild(spmoneyIcon)
            --魔法
            --local spoutMoney = GameNumbers:new(vNumberWhite, NumberAlginment_Right)
            --spoutMoney:setPosition(ccp(295,60))
            --spoutMoney:addLayer(btnItemBg)
            --spoutMoney:setString(sdata.magic+ memoryMagic)
            --local spmoneyIcon = CCSprite:createWithSpriteFrameName(SIconMagic)
            --spmoneyIcon:setAnchorPoint(ccp(0,0.5))
            --spmoneyIcon:setPosition(ccp(300,60))
            --btnItemBg:addChild(spmoneyIcon)
            --水晶
            local spoutMoney = GameNumbers:new(vNumberWhite, NumberAlginment_Right)
            spoutMoney:setPosition(ccp(295,35))
            spoutMoney:addLayer(btnItemBg)
            spoutMoney:setString(sdata.crystal+ memoryCrystal)
            local spmoneyIcon = CCSprite:createWithSpriteFrameName(SIconCrystal)
            spmoneyIcon:setScale(0.6)
            spmoneyIcon:setAnchorPoint(ccp(0,0.5))
            spmoneyIcon:setPosition(ccp(300,35))
            btnItemBg:addChild(spmoneyIcon)

            --X按钮--删除存档
            local btnItem = GFunc_CreateButtonP("jiemian_021.png", function(tag)
                GFunc_ShowDialogEnterClance({color=ccc3(255,0,0),msg=string.format("警告:您想要清除[存档%s]中的数据吗？",tag==1 and "一" or "二"), func=function(_args)
                    if _args.enter then
                        --存档清空
                        Config_SaveGameData(tag, "")
                        --教程数据清空
                        CCUserDefault:sharedUserDefault():setStringForKey(string.format("tutorial%d",tag), "")
                        --存档相关的日期,时间，描述
                        CCUserDefault:sharedUserDefault():flush()

                        GameResumeShowScene()
                        createSceneMain()
                    end
                end})
            end, nil, 1.8)
            btnItem:setPosition(ccp(pos.x+190, pos.y+55))
            menu2:addChild(btnItem,0,index)
        else
            ---空白存档
            local spbgc = CCSprite:createWithSpriteFrameName("jiemian_026.png")
            spbgc:setPosition(ccp(btnItemBg:getNormalImage():getContentSize().width/2, btnItemBg:getNormalImage():getContentSize().height/2))
            btnItemBg:addChild(spbgc)
        end
    end
    createDataInterface(1, ccp(DWinSize.width/2, 345))
    createDataInterface(2, ccp(DWinSize.width/2, 205))


    ----游戏设置
    local isopen =false
    local spSetingbg = CCProgressTimer:create(CCSprite:createWithSpriteFrameName("jiemian_085.png"))
    spSetingbg:setType(kCCProgressTimerTypeBar)
    spSetingbg:setMidpoint(CCPointMake(0,0))
    spSetingbg:setBarChangeRate(CCPointMake(0, 1))
    spSetingbg:setAnchorPoint(ccp(0.5, 0))
    spSetingbg:setPosition(ccp(60,50))
    layer:addChild(spSetingbg)

    --声音
    local btnSoundItem = nil
    ---根据当前的声音情况显示不同的声音按钮
    local function changeSound(init)
        if init ~= true then
            Change_BgmStatus()
        end
        local sbtn = "jiemian_087.png"
        if btnSoundItem then
            menu:removeChild(btnSoundItem, true)
        end
        if Get_MusicStatus() == false then
            sbtn = "jiemian_088.png"
        end
        btnSoundItem = GFunc_CreateButtonP(sbtn, changeSound)
        btnSoundItem:setPosition(ccp(60, 190))
        if not isopen then
            btnSoundItem:setEnabled(false)
            btnSoundItem:setVisible(false)
        end
        menu:addChild(btnSoundItem)
    end
    changeSound(true)


    --关于
    local btnAboutItem = GFunc_CreateButtonP("jiemian_086.png", function()
        print("关于")
    end)
    btnAboutItem:setPosition(ccp(60, 120))
    btnAboutItem:setEnabled(false)
    btnAboutItem:setVisible(false)
    menu:addChild(btnAboutItem)


    local btnItem = GFunc_CreateButtonP("jiemian_083.png", function(tag)
        local action = nil
        if isopen then
            action = CCProgressTo:create(0.2, 0)
            isopen = false
            btnAboutItem:setEnabled(false)
            btnAboutItem:setVisible(false)
            btnSoundItem:setEnabled(false)
            btnSoundItem:setVisible(false)
        else
            action = CCProgressTo:create(0.2, 100)
            isopen = true
            btnAboutItem:setEnabled(true)
            btnAboutItem:setVisible(true)
            btnSoundItem:setEnabled(true)
            btnSoundItem:setVisible(true)
        end
        spSetingbg:runAction(action)
    end)
    btnItem:setPosition(ccp(60, 50))
    menu:addChild(btnItem,0,1)

    ----离开游戏
    local btnItem = GFunc_CreateButtonP("jiemian_084.png", function(tag)
        MainMenuCallback()
    end)
    btnItem:setPosition(ccp(DWinSize.width - 60, 50))
    menu:addChild(btnItem,0,1)

    initUpdate("","")
    local btnItem = GFunc_CreateButtonLabel("检查1更新", function()
        createLayerCheckUpdate()
    end,60)
    btnItem:setPosition(ccp(DWinSize.width - 150, DWinSize.height - 50))
    menu:addChild(btnItem,0,1)

    local btnItem = GFunc_CreateButtonLabel("重启", function()
        updateReset()
    end,60)
    btnItem:setPosition(ccp(150, DWinSize.height - 50))
    menu:addChild(btnItem,0,1)
end


function createSceneMain()
    scene = CCScene:create()

    initWithLayer()
    
    scene:addChild(layer)
    scene:addChild(CreateBackMenuItem(),2)
    GameReplaceScne(scene, UI_Main)
end


