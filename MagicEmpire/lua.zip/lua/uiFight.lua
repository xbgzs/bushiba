---进入下层延迟
local FGGotoNextDelay   = 0.5


---角色技能回调
local _GGameFightUseSkillFunc = nil
GGameFightUseSkillFunc = function(tag)
    if _GGameFightUseSkillFunc then
        _GGameFightUseSkillFunc(tag)
    end
end

-- 战斗界面
function createLayerFight(fightInfos, endfunc)
    local layer = nil
    local _fightlevel = 0 --战斗层数:初始1
    ---pvz参数
    local argsPuz = {row = 5, col = 6, width=100, height=100, beginX=20, beginY =20, types = {}}
    --砖块列表
    local typeTables = {1,2,3,GColorType_Health}--{1,2,3,4,5,GColorType_Health}

    ----根据游戏进程显示方块数
    --[[
    GColorType_Red = 1
    GColorType_Buld = 2
    GColorType_Greed    = 3
    GColorType_Yellow   = 4
    GColorType_LGreed   = 5
    GColorType_Purple   = 6
    GColorType_Health
    ]]
    local init_stypelist = {
        [GColorType_Red]=1,
        [GColorType_Buld]=1,
        [GColorType_Greed]=1,
        [GColorType_Yellow]=1,
        [GColorType_LGreed]=1,
    }
    local init_maxtypes = 6 --最大6个
    --绿色圣地 开启前,只显示5个砖块
    if not PlayerInfos:getOpenAreas()[4] then
        init_maxtypes = 5
        local init_sumplayer = 0
        --第一关只能最多3个勇者,所以出现的砖块数为3+1=4种
        for k,info in pairs(PlayerInfos:getAidPlayers()) do
            init_sumplayer = init_sumplayer + 1
        end
        if init_sumplayer < 4 then
            init_maxtypes = 4
        end
    else
        init_maxtypes = 6
    end

    typeTables = {1,2,3,4,5,GColorType_Health}
    if init_maxtypes < 6 then
        --初始的砖块类型
        local init_tslist = {}
        init_tslist[GColorType_Health] = 1 --治疗必须
        --根据出场的勇者设定需要的砖块
        for k,upy in pairs(PlayerInfos:getMyUseAidPlayer()) do
            init_tslist[upy.type] = 1
            --清除已经使用的类型
            init_stypelist[upy.type] = nil
        end
        ---根据缺少的数量再增加其它类型
        local init_sumuse = 0
        for k,v in pairs(init_tslist) do
            init_sumuse = init_sumuse + 1
        end
        local init_templist = {}
        for k,v in pairs(init_stypelist) do
            table.insert(init_templist, k)
        end
        for k=init_sumuse, init_maxtypes-1 do
            local _idx = rand(1,#init_templist)
            local ntype = init_templist[_idx]
            init_tslist[ntype] = 1
            --清除已经使用的类型
            table.remove(init_templist, _idx)
        end

        typeTables = {}
        for _k,_v in pairs(init_tslist) do
            table.insert(typeTables, _k)
            --print("添加类型",_k)
        end
    else
        --print("全类型")
    end

    --游戏参数
    argsPuz.types = typeTables

    ---当前战斗层信息
    local fightLevelInfo = nil
    local tutorial = false

    local gMonsterTables = {} --怪物列表
    ---已杀死怪物列表
    local gMonsterDeathTables = {}
    local createMyRoles = nil
    local deleteMonster = nil
    local GFuncGameFightEnds = nil
    local gPlayerTables = {}

    ----------操作计时
    local txtOpertionTime = nil
    local opertioning = false
    local opertiontime = 0


    GameFuncHideCity()
    GGameShowInterface = GGameInterface_Fight

    local function update(dt)
        -- body
        if opertioning then
            opertiontime = opertiontime + dt

            if opertiontime >= GGameOpertionFight then
                --强制放下砖块
                txtOpertionTime:setString(0)
                argsPuz.FuncPuzPutDown()
            else
                txtOpertionTime:setString(string.format("%.2f",GGameOpertionFight - opertiontime))
                --改变颜色
                if opertiontime >= GGameOpertionFight * 0.78 then
                    txtOpertionTime:setColor(ccc3(255,0,0))
                elseif opertiontime >= GGameOpertionFight * 0.4 then
                    txtOpertionTime:setColor(ccc3(255,180,111))
                end
            end
        end
    end

    ----------
    layer = GFunc_CreateLayerEnterOrExit({update = update})
    ------------
    --消除背景
    local spbg = CCSprite:createWithSpriteFrameName("jiemian_001.png")
    spbg:setAnchorPoint(ccp(0,0))
    spbg:setPosition(ccp(0,0))
    layer:addChild(spbg)
    --战斗地图
    local spbg = CCSprite:createWithSpriteFrameName(string.format("%s.png", MapArea_Static[fightInfos.mid].map))
    spbg:setAnchorPoint(ccp(0,1))
    spbg:setPosition(ccp(0,DWinSize.height))
    layer:addChild(spbg)
    --时间
    local spbg = CCSprite:createWithSpriteFrameName("GUI_time.png")
    spbg:setAnchorPoint(ccp(0,1))
    spbg:setPosition(ccp(20,DWinSize.height-10))
    layer:addChild(spbg)
    ----计时时间
    txtOpertionTime = CCLabelTTF:create(GGameOpertionFight, "Arial", 48)
    txtOpertionTime:setPosition(ccp(spbg:getContentSize().width+50, spbg:getContentSize().height/2))
    spbg:addChild(txtOpertionTime)

    PlayerInfos.hp = PlayerInfos.hpmax

    local gplayer = GamePlayerInfoClass:new()
    gplayer:addParent(layer)

    --地图进度
    local spbg = CCSprite:createWithSpriteFrameName("jiemian_072.png")
    spbg:setAnchorPoint(ccp(0,1))
    spbg:setPosition(ccp(440,DWinSize.height-10))
    layer:addChild(spbg)
    local numberPoress = GameNumbers:new(vNumberBFHui, NumberAlginment_Right)
    numberPoress:addLayer(layer)
    numberPoress:setPosition(ccp(630, DWinSize.height - 35))
    numberPoress:setString("0%")

    ---显示连击数值
    local _TableComboTips = {}
    local _TableComboTxts = {}
    for _k, _type in pairs(typeTables) do
        _TableComboTips[_type] = 0
    end
    local function createCombotips(_info)
        local _type = _info.type
        --不同的类型显示不同的颜色
        local _color = GTableBrickColors[_type]

        _TableComboTips[_type] = _TableComboTips[_type] + 1
        local txt = CCLabelTTF:create(string.format("combo %d", _TableComboTips[_type]), "Arial", 22+_TableComboTips[_type]*2)
        txt:setColor(ccc3(_color[1], _color[2], _color[3]))
        txt:setPosition(ccp(_info.x, _info.y))
        table.insert(_TableComboTxts, {txt=txt, type=_type, combo=_TableComboTips[_type]})
        layer:addChild(txt,5)
    end
    local function clearCombotipForType()

    end
    local function clearCombotips()
        for k,v in pairs(_TableComboTips) do
            _TableComboTips[k] = 0
        end

        for k,_info in pairs(_TableComboTxts) do
            layer:removeChild(_info.txt, true)
        end
        _TableComboTxts = {}
    end


    ----////获取最大的层数
    local function getMaxFightLevel()

        return GFuncGetTPaskFightLevel(fightInfos.id)
    end
    local maxFightsum = getMaxFightLevel()
    --print("战斗层数据::", fightInfos.id, maxFightsum)
    ---获取战斗层的相关信息
    local function getFightLevelInfos(level)
        --print("战斗层数据::2", fightInfos.id, _fightlevel)
        return GFuncGetPTaskFightInfo(fightInfos.id, _fightlevel)
    end

    ---
    local function showFightResutl(bwin)
        local function closeFunc()
            if endfunc then
                endfunc()
            end
            CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)

            GameFuncShowCity()
        end

        --显示结果
        createLayerFightResult({win = bwin, info=fightInfos}, closeFunc)
    end

    -------------战斗结束
    local function GFuncGamePTaskEnd(bwin)
        --print("战斗结束:结算",bwin)

        argsPuz.setOpertion(true)

        --先累加战斗经验
        local allexps = 0
        for k, mon in pairs(gMonsterDeathTables) do
            allexps = allexps + mon.exp
        end

        local roleSum = 0
        for k,v in pairs(gPlayerTables) do
            roleSum = roleSum+1
        end
        ---经验平均分配
        local getexp = ConsertInt(allexps/roleSum)

        ---经验值提升完毕
        local function funcGetExpEnd()
            ---玩家获得的经验值为总经验的1/5
            local pexp = ConsertInt(allexps / 3)
            local islvup = PlayerInfos:addExps(pexp)
            --显示玩家升级信息
            if islvup then
                GFunc_ShowGameDialogMessage({msg=string.format("您等级提升到 %d",PlayerInfos.lv), func=function()
                    -- body
                    --显示结算界面
                    showFightResutl(bwin)
                end})
            else
                --显示结算界面
                showFightResutl(bwin)
            end
        end

        local function tutorialfightRestult()
            --print("经验结束",GTempTutorialFight4)
            if not hasfinshTutorial(TStep6) and GTempTutorialFight4 then
                GTempTutorialFight4()
                GTempTutorialFight5 = function()
                    funcGetExpEnd()
                end
            else
                funcGetExpEnd()
            end
        end

        local function funcAddExp()
            local psum = 1
            --print("啊..",gPlayerTables)
            for k, fpy in pairs(gPlayerTables) do
                --print("添加经验",k,fpy)
                if psum == roleSum then
                    fpy:addExps(getexp, tutorialfightRestult)
                else
                    fpy:addExps(getexp)
                end
                psum = psum + 1
            end
        end

        --战斗结束剧情
        local function fightendEvent()
            GFuncFightEvent(fightLevelInfo, funcAddExp, bwin == true and 1 or 2)
        end


        local function tutorialfightEnd()
            if GTempTutorialFight2 then
                GTempTutorialFight3 = function()
                    fightendEvent()
                end
                GTempTutorialFight2()
            else
                fightendEvent()
            end
        end
        tutorialfightEnd()
    end

    ---/////////////////////////////事件开启/怪物
    local function createMonsterList(lvMonsterInfo, fightEvent)
        --出场完毕后执行
        local function onfightEnd()
            ---如果是宝物事件则获得宝箱
            if fightEvent == GFightEvent_Item then
                --获得奖励
                GFunc_GameDialogFightBoxReward({info=fightInfos, func=function( ... )
                    -- body
                    ---所有怪物死亡
                    for k,cmon in pairs(gMonsterTables) do
                        --之后继续执行
                        deleteMonster({monster=cmon, func=function()
                            local action = CCSequence:createWithTwoActions(CCDelayTime:create(FGGotoNextDelay), CCCallFunc:create(GFuncGameFightEnds))
                            CCDirector:sharedDirector():getRunningScene():runAction(action)
                        end})
                    end
                end})
            else
                --确认是否需要战斗前对话
                GFuncFightEvent(fightLevelInfo, GFuncGameNewRound)
                
                --操作战斗
                --GFuncGameNewRound()
            end

            if not tutorial and not hasfinshTutorial(TStep6) then
                TutorialTaskRun(TStep6)
                tutorial = true
            end
        end

        --根据怪物的数量计算出他们的站位
        local invSums = #lvMonsterInfo.mlist
        local bpx = -50
        local bpy = 640
        local inv = (DWinSize.width-bpx*2) / (invSums+1)

        --{msum=_msum, mlist=_mlist, level=_level}
        local lastmonster = nil
        local mlist = lvMonsterInfo.mlist or {}
        for k=1,#mlist do
            local mid = mlist[k]
            local monster = GameMonsterClass:new(mid, lvMonsterInfo.level)
            monster.key = k
            monster:addParent(layer)
            monster:setPosition(ccp(bpx + k*inv, bpy + math.random(0, 40)))
            if k == #mlist then
                monster:onPlayed(onfightEnd) --出场动画
            else
                monster:onPlayed()
            end
            --gMonsterTables[k] = monster
            table.insert(gMonsterTables, monster)
        end
    end
    --新一层的战斗,召唤怪物
    local function newLevelFight()
        argsPuz.setOpertion(true)

        _fightlevel = _fightlevel + 1
        --获取相应层数的相关信息
        local finfo = getFightLevelInfos()
        if finfo then
            fightLevelInfo = finfo
            local fightEvent = GFightEvent_Fight
            if fightLevelInfo.etype then
                local evtlist = {}
                local mlvs = lua_string_split(fightLevelInfo.etype, "|")
                for k,_info in pairs(mlvs) do
                    local events = lua_string_split(_info, ":")
                    local evt = events[1]+0
                    local elv = events[2]+0
                    for _k=1, elv do
                        table.insert(evtlist, evt)
                    end
                end
                fightEvent = evtlist[rand(1, #evtlist)]
            end

            --不同事件做不同处理
            local lvMonsterInfo
            if fightEvent == GFightEvent_Fight then
                --..0724:现只有战斗事件
                --获取怪物列表
                lvMonsterInfo = GFuncGetMonsterListForFInfo(fightLevelInfo)
            elseif fightEvent == GFightEvent_Item then
                ---出现宝箱
                lvMonsterInfo = {level=1,mlist={1000}}
            end
            createMonsterList(lvMonsterInfo, fightEvent)
        else
            ---如果没有了,则显示战斗全部完成
            GFuncGamePTaskEnd(true)
        end
        --更新战斗进度
        local psvalue = math.ceil((_fightlevel)/maxFightsum * 100 )
        if psvalue > 100 then
            psvalue = 100
        end
        --print(psvalue)
        numberPoress:setString(string.format("%d%s", psvalue,"%"))
        ---进入新的一层
    end
    --怪物死亡,移除
    deleteMonster = function(_args)
        local monster, func = _args.monster, _args.func
        ----
        local function runends()
            --移动相应的怪物
            for _k, cmon in pairs(gMonsterTables) do
                if cmon.key == monster.key then
                    table.remove(gMonsterTables, _k)
                    break
                end
            end
            --print("剩余 ",#gMonsterTables)
            --添加到死亡列表中
            table.insert(gMonsterDeathTables, monster)

            layer:removeChild(monster._parent, true)

            if _args.func then
                _args.func(gMonsterTables)
            end
        end
        monster:FuncGoDeath(runends)
    end

    ---///////////////出击角色加载
    createMyRoles = function()
        local proles = PlayerInfos:getMyUseAidPlayer()

        local invSums = #proles
        local bpx = -80
        local bpy = 590
        local inv = (DWinSize.width-bpx*2) / (invSums+1)

        for k=1,invSums do
            local rpinfo = proles[k]
            if rpinfo then
                local player = GamePlayerClass:new(rpinfo)
                player:setPosition(ccp(bpx + k*inv, bpy))
                player:addParent(layer,1)
                gPlayerTables[player.id] = player
            end
        end
    end
    createMyRoles()

    ----///////////////////////战斗
    ---新的战斗回合
    GFuncGameNewRound = function(step)
        --print("新操作___")
        --可操作
        argsPuz.setOpertion(false)

        if step == nil then
            --print("新回合")
            if GTempTutorialFight2 then
                GTempTutorialFight2()
            end

            txtOpertionTime:setColor(ccc3(255,255,255))
            txtOpertionTime:setString(GGameOpertionFight)
        end
        --所有可使用技能的角色显示技能高亮
        for k,py in pairs(gPlayerTables) do
            py:hasUseSkill()
        end
    end

    --一回合战斗结束
    GFuncGameFightEnds = function(isnew)
        if not isnew then
            gplayer:newRound()
        end

        --结果判定
        argsPuz.setOpertion(true)
        --玩家是否死亡
        --print("我的生命值...",gplayer.hp)
        if gplayer.hp <= 0 then
            GFuncGamePTaskEnd(false)
            return
        end

        ---默认角色技能槽累积增加
        if not isnew then
            for k, fpy in pairs(gPlayerTables) do
                fpy:addSkill()
            end
        end

        --判断是否还有怪物
        --print("剩余怪物,",#gMonsterTables)
        if #gMonsterTables <= 0 then
            ---没有怪物则战斗结束--进入下一层
            newLevelFight()
        else
            -----进入下一个回合
            GFuncGameNewRound(isnew)
        end
    end

        --角色战斗完成回调/判断怪物是否死亡
        local function roleFightEnd(_args)
            if _args.monster:isDeath() then
                --清空目标
                --如果当前有设置目标为此怪物的角色,则清空其目标
                for _k,_role in pairs(gPlayerTables) do
                    local _ftag = _role:getFightTag()
                    if _ftag and _ftag.key == _args.monster.key then
                        _role:setFightTag(nil)
                    end
                end
                --消失
                deleteMonster({monster=_args.monster, func=_args.func})
            else
                --下个角色攻击
                _args.func(gMonsterTables)
            end
        end

    ---所有角色攻击
    local function GFuncGameFight()
        --获得需要发出攻击的角色
        local fightlist = {}
        for k, cpy in pairs(gPlayerTables) do
            if cpy:hasFight() then
                table.insert(fightlist, cpy)
            end
        end

        local function monsterfightEndcallback()
            --print("怪物攻击结束回调")
            ---buff效果执行
            local _index = 0
            local function nextMonBuff()
                _index = _index + 1
                if _index <= #gMonsterTables then
                    local cmon = gMonsterTables[_index]
                    cmon:runbuff(nextMonBuff)
                    cmon:newRound()
                else
                    GFuncGameFightEnds()
                end
            end
            nextMonBuff()
            --[[
            for k,cmon in pairs(gMonsterTables) do
                cmon:runbuff()
            end

            ---新的战斗回合
            GFuncGameFightEnds()
            --]]
        end

        local function fightEndcallback()
            --print("角色攻击结束回调")

            clearCombotips()

            --怪物开始攻击
            local function runMonsterFight()
                local _args = {player=gplayer}

                ---获得所有可进行攻击的怪物
                local mlist = {}
                for _k,_cmon in pairs(gMonsterTables) do
                    if _cmon:hasFight() then
                        table.insert(mlist, _cmon)
                    end
                end

                GFuncMonsterFight(_args, mlist, monsterfightEndcallback)
            end
            
            local action = CCSequence:createWithTwoActions(CCDelayTime:create(FGGotoNextDelay), CCCallFunc:create(runMonsterFight))
            CCDirector:sharedDirector():getRunningScene():runAction(action)

            ---清空角色战斗连击
            for _k, _role in pairs(gPlayerTables) do
                _role:newRound()
            end
        end

        local _mlist = {}
        for k,cmon in pairs(gMonsterTables) do
            table.insert(_mlist, cmon)
        end

        --轮流发起攻击 fpylist, monsterlist, func
        local _args = {fpylist=fightlist, monsterlist=_mlist, func=fightEndcallback, fightfunc = roleFightEnd}
        GFuncGoFightMonster(_args)
    end

    ---////角色使用技能
    _GGameFightUseSkillFunc = function(_rid)
        --print("使用技能",_rid, gPlayerTables[_rid].name)
        gPlayerTables[_rid]:useSkill()
        argsPuz.FuncBeginOpertion()
        argsPuz.setOpertion(true)
        ----显示使用技能动画,并且执行效果
        GFuncFightUseSkill({crole=gPlayerTables[_rid], mlist=gMonsterTables, player=gplayer, func=function(taglist)
            -- body
            --GFuncGameNewRound()
            local tlist = {}
            for _k, _m in pairs(taglist) do
                table.insert(tlist, _m)
            end
            --print("技能动画完成", tlist)
            local _index = 0
            local nextTagfun = nil
            nextTagfun = function()
                _index = _index + 1
                --print(_index, #tlist, tlist)
                if _index <= #tlist then
                    local cmon = tlist[_index]
                    roleFightEnd({fpy = fpy, monster=cmon, func=nextTagfun})
                else
                    GFuncGameFightEnds(true)
                end
            end
            nextTagfun()
        end})
    end



    ---//////////////////////获得类型机率表
    --相关事件回调
    argsPuz["FuncEndRounds"] = function(self, _args)
        --参数_args.list:所有当前回合消除列表  _args.sum:消除次数  _args.info:当前消除砖块信息
        --print("_3._结束___|begins")
        --for _k, _info in pairs(_args.list) do
        --    print(string.format("类型:%d, 数量:%d, 中心位置:%d, %d", _info.type, _info.sum, _info.x, _info.y))
        --end
        --print("______ends|")

        argsPuz.setOpertion(true)
        ---治疗砖块
        gplayer:onTreatBrick(function()
            ----消除结束后,所有角色开始攻击
            GFuncGameFight()
        end)

    end
    argsPuz["FuncEndRoundPart"] = function(self, _args)
        --参数_args.list:所有当前回合消除列表  _args.sum:消除次数  _args.info:当前消除砖块信息
        --print("_2._完成:",_args.sum)
    end
    argsPuz["FuncBeginPuz"] = function(self, _args)
        --不可操作
        argsPuz.setOpertion(true)
        --参数_args.list:所有当前回合消除列表  _args.sum:消除次数  _args.info:当前消除砖块信息
        --print("_1._开始消除 ", _args.info.type, _args.info.sum, _args.info.x, _args.info.y)

        --在指定位置显示砖块的连击数值
        createCombotips(_args.info)


        --给相应类型的角色加上计点
        for _k, _py in pairs(gPlayerTables) do
            if _py.type == _args.info.type then
                _py:addCombo(_args.info.sum)
            end
        end

        if _args.info.type == GColorType_Health then
            gplayer:addTreatCombo(_args.info.sum)
        end
    end
    argsPuz["FuncBeginOpertion"] = function( ... )
        -- body
        --print("开始操作")
        ---开始操作,禁用所有技能
        --所有可使用技能的角色显示技能高亮
        for k,py in pairs(gPlayerTables) do
            py:hasUseSkill(false)
        end
    end
    argsPuz["FuncBeginPickGem"] = function(...)
        if not tutorial then
            opertioning = true
            opertiontime = 0
        end
    end
    argsPuz["FuncEndPickGem"] = function(...)
        opertioning = false
        --txtOpertionTime:setString(GGameOpertionFight)
    end
    ----PUZ系统
    --遮罩
    local _visitNodeParent = GFunc_CreateLayerVisit(layer, DWinSize.width, 520, 0, 0)
    _visitNodeParent:addChild(createLayerForPuzGame(argsPuz))
    


    newLevelFight()


    ----菜单界面
    local function onGameFightMenu()
        --出现菜单,
        local _layerConfig = nil
        local btnTables = {}

        local function closeFunc()
            layer:removeChild(_layerConfig, true)
        end
        --print("打开菜单")
        local function func_touchBegen(x,y,eventType)
            GFunc_SelectBtnRun(btnTables,x,y,eventType)
        end
        
        local function func_touchMoved(x,y,eventType)
            GFunc_SelectBtnRun(btnTables,x,y,eventType)
        end
        
        local function func_touchEnded(x,y,eventType)
            if not GFunc_SelectBtnRun(btnTables,x,y,eventType) then
                --点击界面直接关闭
                closeFunc()
            end
        end
        
        _layerConfig = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150),touchBegin=func_touchBegen, touchMoved=func_touchMoved, 
            touchEnded=func_touchEnded, fmbg=true})
        layer:addChild(_layerConfig,5)
        --确认按钮
        local _gmenu = CCMenu:create()
        _gmenu:setPosition(ccp(0,0))
        _layerConfig:addChild(_gmenu)
        local btnItem = GFunc_CreateButtonP("jiemian_094.png",function()
            ---血瓶
            closeFunc()
        end,nil, 1.2)
        btnItem:setPosition(ccp(240, 400))
        _gmenu:addChild(btnItem)
        table.insert(btnTables, btnItem)

        local btnItem = GFunc_CreateButtonP("jiemian_095.png",function()
            closeFunc()
            ---逃脱
            showFightResutl(false)
        end,nil, 1.2)
        btnItem:setPosition(ccp(400, 400))
        _gmenu:addChild(btnItem)
        table.insert(btnTables, btnItem)
    end

    ---///////////////////返回菜单按钮
    --local menu = CCMenu:create()
    --menu:setPosition(ccp(0,0))
    --layer:addChild(menu)
    
    --local btnItemGMenu = GFunc_CreateButtonP("jiemian_074.png", onGameFightMenu, 1.01, 1.2)
    --btnItemGMenu:setPosition(ccp(DWinSize.width/2, DWinSize.height+48))
    --menu:addChild(btnItemGMenu)
    CCDirector:sharedDirector():getRunningScene():addChild(layer)
end

---战斗对话事件,type==nil 战斗前,  type==1 战斗胜利, type==2 战斗失败
function GFuncFightEvent(finfo, func, type)
    ---如果是任务的话,确认是否有战斗前对话
    --还需要有特殊怪
    if finfo.task and finfo.fixedm then
        --怪物名称
        local mname = ""
        --读取剧情对话表
        local evtlist = {}
        --for k,info in pairs(StoryFightTable_Static) do
        for k=1, table.getn(StoryFightTable_Static) do
            local info = StoryFightTable_Static[k]
            --print(finfo.pid, info.tid, type, info.open)
            if info and finfo.pid == info.tid and type == info.open then
                table.insert(evtlist, info)
            end

            if info.nickname and mname == "" then
                mname = info.nickname
            end
        end
        --黑掉下屏幕
        local bgp = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
        --bgp:setContentSize(CCSizeMake(DWinSize.width, 628))
        CCDirector:sharedDirector():getRunningScene():addChild(bgp,10)

        local storyui = GGameRunEventStory({evtlist = evtlist, color=ccc4(0,0,0,0),func=function()
            if func then
                func()
            end
            GFunc_RemoveChild(bgp)
        end, width=640, height=200, left=160, top=0})
        if storyui then
            storyui.parent:setPosition(ccp(storyui.parentX, storyui.parentY + 500))
        end

        ---怪物头像显示
        local minfo =  MonsterList_Static[finfo.fixedm]
        if minfo then
            local sp = CCSprite:createWithSpriteFrameName(string.format("%s.png", minfo.art))
            sp:setScale(180/sp:getContentSize().height)
            sp:setAnchorPoint(ccp(0,0))
            sp:setPosition(ccp(30, 80))
            storyui.parent:addChild(sp)
        end
        --怪物名称
        local txtname = CCLabelTTF:create(mname, "Arial", 28, CCSizeMake(160,0),  kCCTextAlignmentCenter)
        txtname:setColor(ccc3(139,99,39))
        txtname:setPosition(ccp(100,50))
        storyui.parent:addChild(txtname)
    else
        if func then
            func()
        end
    end
end

---通过战斗信息表获取战斗中出场的怪物信
function GFuncGetMonsterListForFInfo(finfo)
    --怪物数量 msum
    local _msum = finfo.msum or 1
    --怪物出现的怪物,概率表 monster
    local monsterlist = {}
    local mlvs = lua_string_split(finfo.monster or "", "|")
    --print("获取怪物:",finfo.monster, mlvs)
    for k,info in pairs(mlvs) do
        local infovs = lua_string_split(info, ":")
        local mid = infovs[1]+0
        local mjl = infovs[2]+0
        --print(mid,mjl)
        for _k=1, mjl do
            table.insert(monsterlist, mid)
        end
    end
    --根据数量随机出怪物
    --怪物列表
    local _mlist = {}
    for k=1,_msum do
        local mid = monsterlist[rand(1,#monsterlist)]
        table.insert(_mlist, mid)
    end

    --特殊怪物出现/boss  出现在中间,有特殊BOSS的
    if finfo.fixedm then
        _mlist[math.floor(_msum/2)+1] = finfo.fixedm
    end

    --等级
    local _level = finfo.mlv

    return {msum=_msum, mlist=_mlist, level=_level}
end

--根据连击次数获得一个伤害值
local function GFuncGetFightHurt(atk, combo, puzsum, combosum)
    --最大连击次数为3次,
    --基础消除砖块系数:消除次数/连击次数(大于3则为3)
    --如果连击次数大于3,则伤害折算点从3开始
    local csum = 1
    if combosum then
        csum = combosum
        if combosum > 3 then
            csum = 3
        end
    end

    --根据消除的总数获得一定的伤害加成
    if puzsum == nil then
        puzsum = 3
    else
        --print(puzsum, csum, combosum)
        puzsum = puzsum/csum
    end
    atk = atk * (puzsum/3.0)

    --计算连击伤害加成
    local ratk = atk
    for k=1,combo-1 do
        ratk = ratk * 1.05
    end
    --print("伤害值",ratk)
    return ratk
end
-------角色攻击怪物
function GFuncGoFightMonster(args)

    local fpylist, monsterlist, func = args.fpylist, args.monsterlist, args.func
    --
    local index = 1
    local function nextPyfight()
        --没有目标则结束
        if fpylist[index] == nil then
            if func then
                func()
            end
            return
        end

        local fpy = fpylist[index]
        --浮动基础攻击
        local pybaseAtk = GFuncGameValueFloat(fpy.atk, 0.05)

        --攻击目标
        local fightTag = fpy:getFightTag()
        if fightTag == nil then
            --没有目标则随机设置一个
            fightTag = monsterlist[rand(1,#monsterlist)]
            fpy:setFightTag(fightTag)
        end

        index = index + 1

        --目标为空则跳过
        if fightTag == nil then
            nextPyfight()
            return
        end

        --攻击动画
        local fsum = 1
        local onfight = nil
        onfight = function()
            local anim = nil
            local function animEnd()
                --结束

                --连击判定>最大3次
                if fpy.fcombo > fsum-1 and fsum <= 3 then
                    --连击
                    onfight()
                else
                    --结束攻击/
                    --间隔0.5
                    local action = CCSequence:createWithTwoActions(CCDelayTime:create(0.5), CCCallFunc:create(function()
                        ---目标生命值小于0则死亡
                        args.fightfunc({fpy = fpy, monster=fightTag, func=function(newmlist)
                            monsterlist = newmlist
                            nextPyfight()
                            end})
                    end))
                    CCDirector:sharedDirector():getRunningScene():runAction(action)
                end

                if fpy.fcombo <= fsum or fsum > 3 then

                end
            end
            --根据攻击次数获得不同动画
            if fsum == 1 then
                anim = GFunc_CreateAnimation("lianzhan_1", 1, 3, 1, 0.1, animEnd, 2)
            elseif fsum == 2 then
                anim = GFunc_CreateAnimation("lianzhan_2", 1, 3, 1, 0.1, animEnd, 2)
            elseif fsum == 3 then
                anim = GFunc_CreateAnimation("lianzhan_3", 1, 5, 1, 0.1, animEnd, 2)
            end

            --,目标受到伤害,获得伤害值
            local hurt = GFuncGetFightHurt(pybaseAtk, fsum, fpy.fpuzsum, fpy.fcombo)
            fightTag:onHurt(hurt,nil,fsum)

            --攻击对象出击
            fpy:onFight()

            fsum = fsum + 1
            anim:setPosition(ccp(0, fightTag.spicon:getContentSize().height/2))
            fightTag._parent:addChild(anim)
        end
        onfight()
    end
    nextPyfight()
end

---------怪物攻击玩家
function GFuncMonsterFight(args, monsterlist, func)
    local index = 1
    local function nextmonfight()
        --直接攻击
        if monsterlist[index] == nil then
            if func then
                func()
            end
            return
        end
        local monster = monsterlist[index]
        monster:onFight()

        local hurt = GFuncGetFightHurt(monster.atk, 1)
        args.player:onHurt(hurt)

        --技能动画
        local anim = nil
        local function animEnd()
            nextmonfight()
        end
        if monster.type == GColorType_Red then
            anim = GFunc_CreateAnimation("digongred_", 1, 6, 1, 0.1, animEnd, 3)
        elseif monster.type == GColorType_Buld then
            anim = GFunc_CreateAnimation("digonglan_", 1, 6, 1, 0.1, animEnd, 3)
        else-- monster.type == GColorType_Greed then
            anim = GFunc_CreateAnimation("digonggreen_", 1, 6, 1, 0.1, animEnd, 3)
        end
        anim:setPosition(ccp(monster:getPosition().x, 590))
        CCDirector:sharedDirector():getRunningScene():addChild(anim)

        index = index + 1
    end
    nextmonfight()
end



-----游戏数值浮动设定
function GFuncGameValueFloat(value, vfloat)
    if vfloat == nil then
        vfloat = 0.1
    end
    return rand(value*(1.0-vfloat), value*(1.0+vfloat))
end