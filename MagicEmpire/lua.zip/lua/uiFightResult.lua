--------------
-- 战斗结果界面
function createLayerFightResult(args, endfunc)
    local layer = nil

    local fightInfos = args.info
    ---战斗结果
    local isWin = args.win
    --根据关卡获取奖励信息
    local stageInfo = {}--args.stage
    
    ----------
    local function onTouchBegin()
        if endfunc then
            endfunc()
        end
        CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)

        GTempTutorialFight7 = nil
    end
    GTempTutorialFight7 = onTouchBegin

    layer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,80),touchBegin=onTouchBegin,fmbg=true})
    ------------
    if isWin then
        --增加值
        local _ragree = fightInfos.ragree or 0
        local _rmoney = fightInfos.rmoney or 0

        local itemID = 0
        local itemSum = 0

        ---当前的认同值
        local _myagree = PlayerInfos:getAgree(fightInfos.mid)
        ---当前的认同等级
        local _myagreelv = PlayerInfos.AreaInfos[fightInfos.mid].lv


        local function addReward()
            --增加地区认同？/好友度 fightInfos.ragree
            PlayerInfos:addAgree(fightInfos.mid, _ragree)
            --金钱奖励增加
            PlayerInfos:addMoney(_rmoney)
            --增加物品
            PlayerInfos:addItems(itemID, itemSum)
        end

        --任务完成标识--效果显示完成后再增长
        local function addfinshfunc()
            if fightInfos.type == nil or fightInfos.type == 0 then
                ---平叛点战斗奖励任务随机获得
                if fightInfos.ritem then
                    local rparaminfos = lua_string_split(fightInfos.ritem or "", "|")
                    local _itemsTbl = {}
                    for _k,_item in pairs(rparaminfos) do
                        local _ritem = lua_string_split(_item or "", "+")
                        if #_ritem > 1 then
                            local _riID = _ritem[1] + 0
                            local _rcut = _ritem[2] + 0
                            for _kv=1,_rcut do
                                table.insert(_itemsTbl, _riID)
                            end
                        end
                    end
                    if #_itemsTbl > 0 then
                        itemID = _itemsTbl[rand(1,#_itemsTbl)]
                        itemSum = 1
                    end
                end

                --通过平叛点
                GFuncSetPlaceFinsh(fightInfos.id)
                --根据通过平叛点的次数,重新计算出获得认同值
                _ragree = math.floor(_ragree / (fightInfos.fight_sum or 1))
                print("通过啦,",_ragree, fightInfos.fight_sum)
                GameEvent_JugeTaskFinshEnd(GTaskType_Fight, {pid=fightInfos.id})

                addReward()
            else
                --任务完成
                GameEvent_JugeTaskFinshEnd(GTaskType_Fight, {tid=fightInfos.id})

                addReward()
            end
        end

        ---获取地区认同度
        local _itY = PlayerInfos:getAgree(fightInfos.mid)
        local _itYA = PlayerInfos:getNextAgree(fightInfos.mid)

        addfinshfunc()


        local spbgParent = CCSprite:createWithSpriteFrameName("jiemian_069.png")
        spbgParent:setPosition(ccp(DWinSize.width/2, DWinSize.height/2))
        layer:addChild(spbgParent)

        local pppyx = 227

        --认同度进度条
        local progress = GameProgressCrols:new("jiemian_068.png", "jiemian_067.png")
        progress:setAllProgress(_itYA)
        progress:update(_itY)
        progress:addToParent(spbgParent)
        progress:setPosition(ccp(170, DWinSize.height/2 - pppyx))

        --地名sp
        local spbg = CCSprite:createWithSpriteFrameName(string.format("%s.png",MapArea_Static[fightInfos.mid].namesp))
        spbg:setPosition(ccp(130, 570 - pppyx))
        spbgParent:addChild(spbg)
        --任务名sp
        local spbg = CCLabelTTF:create(fightInfos.name, "Arial", 36)
        spbg:setPosition(ccp(230, 623 - pppyx))
        spbgParent:addChild(spbg)
        --认同等级
        local txt = CCLabelTTF:create(string.format("地区认同等级 %d", _myagreelv), "Arial", 36)
        txt:setPosition(ccp(160,  520 - pppyx))
        spbgParent:addChild(txt)
        --认同度数字
        local spbg = CCSprite:createWithSpriteFrameName("jiemian_066.png")
        spbg:setPosition(ccp(360, 520 - pppyx))
        spbgParent:addChild(spbg)
        local numberAgreeLv = GameNumbers:new(vNumberWhite, NumberAlginment_Left)
        numberAgreeLv:addLayer(spbgParent)
        numberAgreeLv:setPosition(ccp(420, 520 - pppyx))
        numberAgreeLv:setString(string.format("%d/%d",_itY, _itYA))
        --报酬sp
        local spbg = CCSprite:createWithSpriteFrameName(SIconMoney)
        spbg:setPosition(ccp(545, 388 - pppyx))
        spbgParent:addChild(spbg)
        --报酬数值
        local numberLv = GameNumbers:new(vNumberWhite, NumberAlginment_Right)
        numberLv:addLayer(spbgParent)
        numberLv:setPosition(ccp(520, 385 - pppyx))
        numberLv:setString(0)
        --物品sp
        if itemID ~= 0 then
            local txt = CCLabelTTF:create(string.format("%sx%d", ItemList_Static[itemID].name, itemSum), "Arial", 36)
            txt:setPosition(ccp(DWinSize.width/2 , 92))
            spbgParent:addChild(txt)
        end

        ---金钱增长
        local _addmoney = 0
        local baddmoney = true
        local _ttmoneyadd = _rmoney / 30.0

        ---认同增加
        local _addagree = 0
        local baddagree = true
        local _ttadd = _ragree / 30.0
        local function update(dt)
            if baddagree then
                --累加认同值
                if _addagree < _ragree and _myagreelv < GGameMaxagreeLevel then
                    _addagree = _addagree + _ttadd
                    --如果大于下级认同值,更新
                    if _itY + _addagree >= _itYA then
                        --_itY = PlayerInfos:getAgree(fightInfos.mid)
                        _itYA = PlayerInfos:getNextAgree(fightInfos.mid)
                        progress:setAllProgress(_itYA)
                        _myagreelv = PlayerInfos.AreaInfos[fightInfos.mid].lv
                        --print("超过",_itY,_itYA)
                        txt:setString(string.format("地区认同等级 %d", _myagreelv))
                    end
                    --print(_itY + _addagree)
                    numberAgreeLv:setString(string.format("%d/%d", ConsertInt(_itY + _addagree), ConsertInt(_itYA)))
                    progress:update(_itY + _addagree)
                else
                    baddagree = false
                end
            end

            if baddmoney then
                _addmoney = _addmoney + _ttmoneyadd
                if _addmoney < _rmoney then
                    numberLv:setString(ConsertInt(_addmoney))
                else
                    numberLv:setString(_rmoney)
                    baddmoney = false
                end
            end
        end
        local templayer = GFunc_CreateLayerEnterOrExit({update = update, fps=1/30})
        layer:addChild(templayer)
    else
        local spbg = CCSprite:createWithSpriteFrameName("jiemian_060.png")
        spbg:setPosition(ccp(DWinSize.width/2, DWinSize.height*0.8))
        layer:addChild(spbg)

        ---统计失败次数
        PlayerInfos:addFightlost()
    end
    
    CCDirector:sharedDirector():getRunningScene():addChild(layer)
end