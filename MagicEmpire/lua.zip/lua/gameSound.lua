
local SoundPath = "sound/"
local SoundEffsPath = "sound/"

GetFiles = function(file)
    local strPath = string.format("%s%s",SoundPath,file)
    if SoundTypeTabls[file] == SType_BG then
    elseif SoundTypeTabls[file] == SType_Eff then
        strPath = string.format("%s%s",SoundEffsPath,file)
    end
    return CCFileUtils:sharedFileUtils():fullPathForFilename(strPath)
end


-- 当前播放状态
local _PlayBgmSt    = true
local _PlayEffSt    = true
--当前播放背景音乐
local _PlayBgm = nil
--当前音量
local _ValumeBgm = 1.0
local _ValumeEff = 1.0
-- 加载/初始化游戏音乐音效
function Init_GameSound()
    -- 加载
    --for file, v in pairs(SoundTypeTabls) do
    --    if v == SType_BG then
    --        SimpleAudioEngine:sharedEngine():preloadBackgroundMusic(GetFiles(file))
    --    elseif v == SType_Eff then
    --        SimpleAudioEngine:sharedEngine():preloadEffect(GetFiles(file))
    --    end
    --    
    --    --print("loading sound...",file)
    --end
    
    --Play_BackgroundMusic(sm_Menu, true, true)
    
    -- 音乐音效设置
    if Config_SoundOff() == 0 then
        _PlayBgmSt = true
        _PlayEffSt = true
    else
        _PlayBgmSt = false
        _PlayEffSt = false
    end
    
end

-- 播放音乐,(file:文件, loop:是否循环 reload:强制重新播放(在相当文件的情况下))
function Play_BackgroundMusic(file, loop, reload)
    if _PlayBgmSt then
        if reload == nil then
            reload = false
        end
        if loop == nil then
            loop = true
        end
        if reload or _PlayBgm ~= file then
            local filesp = GetFiles(file)
            SimpleAudioEngine:sharedEngine():playBackgroundMusic(filesp,loop)
            _PlayBgm = file
        end
    end
end

-- 播放音效
local lastFrameEffs = {}
function Play_Effect(file, loop, reload)
    if _PlayEffSt and file then
        if loop == nil then
            loop = false
        end
        
        if reload == nil then
            reload = false
        end
        
        --同一帧的相同音效抛弃
        if not reload and lastFrameEffs[file] ~= nil then
            return
        end
        lastFrameEffs[file] = true
        
        local filesp = GetFiles(file)
        return SimpleAudioEngine:sharedEngine():playEffect(filesp, loop)
    end
end

function Stop_EffectByID(id)
    SimpleAudioEngine:sharedEngine():stopEffect(id)
end
function Pause_EffectByID(id)
    SimpleAudioEngine:sharedEngine():pauseEffect(id)
end

function Stop_AllEffect()
    SimpleAudioEngine:sharedEngine():stopAllEffects()
end

-- 设置背景音乐音量
function setBackgroundMusicVolume(volume)
    SimpleAudioEngine:sharedEngine():setBackgroundMusicVolume(volume)
end
-- 设置音效音量
function setEffectsVolume()
    SimpleAudioEngine:sharedEngine():setEffectsVolume(volume)
end

function Play_Bgm(bpy)
    if not _PlayBgmSt or bpy then
        _PlayBgmSt = true
        
        if _PlayBgm == nil then
            _PlayBgm = sm_Menu
        end
        
        Play_BackgroundMusic(_PlayBgm, true, true)
    end
end
function Play_Eff()
    _PlayEffSt    = true
end
function Stop_Bgm()
    if _PlayBgmSt then
        _PlayBgmSt = false
        SimpleAudioEngine:sharedEngine():stopBackgroundMusic()
    end
end
function Stop_Eff()
    _PlayEffSt    = false
    --SimpleAudioEngine:sharedEngine():stopAllEffects()
end
function Change_BgmStatus()
    if _PlayBgmSt then
        Stop_Bgm()
    else
        Play_Bgm()
    end
    
    -- 保存音乐音效开关设置
    if _PlayBgmSt then
        Config_SoundOff(0)
    else
        Config_SoundOff(1)
    end
end
function Change_EffStatus()
    if _PlayEffSt then
        Stop_Eff()
    else
        Play_Eff()
    end
end

function Get_MusicStatus()
    return _PlayBgmSt
end

function Get_EffStatus()
    return _PlayEffSt
end

function GameSound_Update()
    lastFrameEffs = {}
end



