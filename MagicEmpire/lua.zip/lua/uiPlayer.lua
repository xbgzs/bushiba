------
--玩家信息
------
function GShowDialogPlayerInfos(endfunc)
    local layer = nil
    local _container = nil
    local btnTables = {}
    local btnContainerTables = {}
    local parentX, parentY = 0,0

    local pvisitPx = 25
    local pvisitPy = 25

    local _itemParent = nil
    local menuchild = nil

    local selectType = nil
    local vTypeStatus = 1
    local vTypeRole = 2
    local vTypeReward = 3
    local vTypeArea = 4

    --加载列表
    local reloadinfo = nil

    ---获得所有已经解锁的任务列表
    local items = {}
    local function closeFunc(_args)
        if _args == nil then
            _args = {}
        end
        ----
        CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
        if endfunc then
            endfunc(_args)
        end
    end

    local beginPickY = 0
    local function touchContainer(x,y,eventType)
        --print(x,y)
        local isclick = false
        if eventType == CCTOUCHENDED and (y >= 170 and y <= 750) and math.abs(beginPickY-y) < 15 then
            isclick = true
        end
        local _mx, _my = _container:getPosition()
        GFunc_SelectBtnRun(btnContainerTables,x-parentX-_mx - pvisitPx*2,y-parentY-_my,eventType, isclick)
        if (y >= 170 and y <= 750) then
            _container:onTouch(x-parentX,y-parentY,eventType)
        end
    end

    local function touchBegin(x,y,eventType)
        beginPickY = y
        touchContainer(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x-parentX,y-parentY,eventType)
    end
    local function touchMoved(x,y, eventType)
        touchContainer(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x-parentX,y-parentY,eventType)
    end
    local function touchEnded(x,y,eventType)
        touchContainer(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x-parentX,y-parentY,eventType)
    end

    local function exitlayer()
        GFInterface_PlayerInfo = nil
    end

    layer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,100),exfunc = exitlayer,update=update,touchBegin=touchBegin, touchMoved=touchMoved, touchEnded=touchEnded, fmbg = true})
    CCDirector:sharedDirector():getRunningScene():addChild(layer)
    GFInterface_PlayerInfo = layer

    local _parent = CCNode:create()
    layer:addChild(_parent)
    local _menu = CCMenu:create()
    _menu:setPosition(ccp(0,0))
    _parent:addChild(_menu,1)

    local uiWidth,uiHeight = 577, 690
    local spbg = gfuncCreateUIBG({height=uiHeight})
    spbg:setPosition(ccp(uiWidth/2, uiHeight/2))
    _parent:addChild(spbg)

    ----标题栏
    local spbg = CCSprite:createWithSpriteFrameName("jiemian_104.png")
    spbg:setPosition(ccp(uiWidth/2, uiHeight-53))
    _parent:addChild(spbg)

    --遮罩
    local visitWidth = 530
    local _nodeParentLayerVisit = GFunc_CreateLayerVisit(_parent, visitWidth, 570, pvisitPx, pvisitPy)
    --排列容器
    _container = GameSildeContainer:new(0, 0, SildeContainer_UpDown)
    _container:addToLayer(_nodeParentLayerVisit)


    local function accceptTask_s(info)
    end

    local function locklayer()
        layer:setTouchEnabled(false)
        --layer.menu:setTouchEnabled(false)
    end
    local function unlocklayer()
        layer:setTouchEnabled(true)
    end

    --获取已经开启的商品项目
    local inv = 66
    local psum = 6

    reloadinfo = function(_type)
        if _itemParent then
            _container:removeChild(_itemParent)
            _itemParent = nil
            menuchild = nil
        end
        _itemParent = CCNode:create()

        menuchild = CCMenu:create()
        menuchild:setPosition(ccp(0,0))
        _itemParent:addChild(menuchild)
        _container:addElementChild(_itemParent)

        local items = {}
        btnContainerTables = {}
        if _type == vTypeStatus then
            ---玩家信息显示
            local spbg = GCreatePlayerProperty()
            spbg:setPosition(ccp(10, uiHeight - 110))
            _itemParent:addChild(spbg)

            local fitempx = 10
            local fitempy = 340
            local finv = 67

            ---数据统计
            --任务完成数
            local taskfinshsum = 0
            for _k,_info in pairs(GFuncGetTableTaskInfos()) do
                if _info.status == GTaskStatus_Finsh or _info.status == GTaskStatus_FinshTemp then
                    taskfinshsum = taskfinshsum + 1
                end
            end
            --发现道具数
            local finditemsum = 0
            --研发总次数
            local itemyjsums = 0
            for _k, _info in pairs(PlayerInfos.itemlists) do
                finditemsum = finditemsum + 1
                itemyjsums = itemyjsums + _info.sumyj or 0
            end
            --被击退数
            local flostsum = PlayerInfos.fightlost
            --剩余时间
            

            --------任务完成数
            --背景sp
            local spbg = CCSprite:createWithSpriteFrameName("jiemian_114.png")
            spbg:setAnchorPoint(ccp(0,0.5))
            spbg:setPosition(ccp(0, fitempy))
            _itemParent:addChild(spbg)
            local spbg = CCSprite:createWithSpriteFrameName("jiemian_138.png")
            spbg:setAnchorPoint(ccp(0,0.5))
            spbg:setPosition(ccp(fitempx, fitempy))
            _itemParent:addChild(spbg)
            local number = GameNumbers:new(vNumberBFHui)
            number:setPosition(ccp(fitempx+180, fitempy))
            number:setString(taskfinshsum)
            number:addLayer(_itemParent)

            ------发现物品数
            local spbg = CCSprite:createWithSpriteFrameName("jiemian_139.png")
            spbg:setAnchorPoint(ccp(0,0.5))
            spbg:setPosition(ccp(fitempx, fitempy - 1*finv))
            _itemParent:addChild(spbg)
            local number = GameNumbers:new(vNumberBFHui)
            number:setPosition(ccp(fitempx+180, fitempy - 1*finv))
            number:setString(finditemsum)
            number:addLayer(_itemParent)

            -----研发道具数
            --背景sp
            local spbg = CCSprite:createWithSpriteFrameName("jiemian_114.png")
            spbg:setAnchorPoint(ccp(0,0.5))
            spbg:setPosition(ccp(0, fitempy - 2*finv))
            _itemParent:addChild(spbg)
            local spbg = CCSprite:createWithSpriteFrameName("jiemian_140.png")
            spbg:setAnchorPoint(ccp(0,0.5))
            spbg:setPosition(ccp(fitempx, fitempy - 2*finv))
            _itemParent:addChild(spbg)
            local number = GameNumbers:new(vNumberBFHui)
            number:setPosition(ccp(fitempx+180, fitempy - 2*finv))
            number:setString(itemyjsums)
            number:addLayer(_itemParent)

            ---被击退数
            local spbg = CCSprite:createWithSpriteFrameName("jiemian_141.png")
            spbg:setAnchorPoint(ccp(0,0.5))
            spbg:setPosition(ccp(fitempx, fitempy - 3*finv))
            _itemParent:addChild(spbg)
            local number = GameNumbers:new(vNumberBFHui)
            number:setPosition(ccp(fitempx+180, fitempy - 3*finv))
            number:setString(flostsum)
            number:addLayer(_itemParent)

            ----剩余时间
            --背景sp
            local spbg = CCSprite:createWithSpriteFrameName("jiemian_114.png")
            spbg:setAnchorPoint(ccp(0,0.5))
            spbg:setPosition(ccp(0, fitempy - 4*finv))
            _itemParent:addChild(spbg)
            local spbg = CCSprite:createWithSpriteFrameName("jiemian_142.png")
            spbg:setAnchorPoint(ccp(0,0.5))
            spbg:setPosition(ccp(fitempx, fitempy - 4*finv))
            _itemParent:addChild(spbg)
            local number = GameNumbers:new(vNumberBFHui)
            number:setPosition(ccp(fitempx+180, fitempy - 4*finv))
            number:setString("--")
            number:addLayer(_itemParent)

            --jiemian_114


            --等级/经验/生命值/金币/魔法点
            --lv sp
            local spbg = CCSprite:createWithSpriteFrameName("jiemian_038.png")
            spbg:setAnchorPoint(ccp(0,0.5))
            spbg:setPosition(ccp(5, uiHeight - 80))
            --_itemParent:addChild(spbg)
            --lv数字
            local numberLv = GameNumbers:new(vNumberWhite, NumberAlginment_Left)
            --numberLv:addLayer(_itemParent)
            numberLv:setPosition(ccp(60, uiHeight -80))
            numberLv:setString(PlayerInfos.lv)

            local txthp = CCLabelTTF:create(string.format("%d", PlayerInfos.hpmax), "Arial", 32)
            txthp:setPosition(ccp(260, uiHeight - 120))
            txthp:setColor(ccc3(109,121,32))
            --_itemParent:addChild(txthp)

            local txtmoney = CCLabelTTF:create(string.format("金币：%d", PlayerInfos:getMoney()), "Arial", 32)
            txtmoney:setAnchorPoint(ccp(0,0.5))
            txtmoney:setPosition(ccp(5, uiHeight -125))
            txtmoney:setColor(ccc3(109,121,32))
            --_itemParent:addChild(txtmoney)

            local txtmagic = CCLabelTTF:create(string.format("魔法点：%d", PlayerInfos:getMagic()), "Arial", 32)
            txtmagic:setAnchorPoint(ccp(0,0.5))
            txtmagic:setPosition(ccp(5, uiHeight -160))
            txtmagic:setColor(ccc3(109,121,32))
            --_itemParent:addChild(txtmagic)

            --时间/收复地区/任务完成/
            --年
            local iyear = PlayerInfos.citytimeformat[1]
            --月
            local imonth = PlayerInfos.citytimeformat[2]
            --周
            local iweek = PlayerInfos.citytimeformat[3]
            local strmsg = string.format("%d年%d月%d周",iyear, imonth, iweek)
            local txgtime = CCLabelTTF:create(strmsg, "Arial", 32)
            txgtime:setAnchorPoint(ccp(0,0.5))
            txgtime:setPosition(ccp(uiWidth-200, uiHeight - 150))
            txgtime:setColor(ccc3(109,121,32))
            --_itemParent:addChild(txgtime)

        elseif _type == vTypeRole then
            -- 角色列表
            local index = 0
            psum = 6
            ---可选择成员一览
            local proles = PlayerInfos:getAidPlayers()
            --print("数量:",table.getn(proles))
            local rpsum = 0
            for _k=1,15 do
                local info = PlayerInfos:getAidPlayers()[_k]
                local px, py = 70 + (rpsum%3)*170, 550 - 120 * math.floor(rpsum/3)
                if info then
                    --头像
                    local newHead = createRoleIcon(info, function(tag)
                        locklayer()
                        GFuncShowGmaeRoleInfos({info=proles[tag], func=unlocklayer})
                    end)
                    local btnItem = newHead.btn
                    btnItem:setPosition(ccp(px, py))
                    menuchild:addChild(btnItem, 0, _k)
                    table.insert(btnContainerTables, btnItem)
                else
                    ---未获得的勇者显示为问号
                    local spnor = CCSprite:createWithSpriteFrameName("jiemian_055.png")
                    spnor:setPosition(ccp(px, py))
                    _itemParent:addChild(spnor)
                end
                rpsum = rpsum + 1
            end
            _container:setSize(nil, 200)
        elseif _type == vTypeReward then
            -- 建筑收益显示
            local index = 0
            psum = 6
            --只显示已开启地区的信息
            local infoitems = {}
            for _k,_info in pairs(PlayerInfos.myBuildInfos) do
                table.insert(infoitems,_info)
            end
            --排序
            table.sort(infoitems, function(itemA,itemB)
                return itemA.bid < itemB.bid or itemA.bid == itemB.bid and itemA:getOutMoney() > itemB:getOutMoney()
            end)
            for _k,_info in pairs(infoitems) do
                local info = _info
                --列出项目
                local function clickItem(tag)
                    --layer:setTouchEnabled(false)
                    --layer.menu:setTouchEnabled(false)
                    locklayer()
                    GShowBuildInfos({info=infoitems[tag], endfunc=function()
                        unlocklayer()
                    end});
                end
                local btnItem = GFunc_CreateButtonLabel("", clickItem, nil, CCSizeMake(visitWidth, inv))
                btnItem:setPosition(ccp(visitWidth/2 - 45, 560 - inv * index))
                menuchild:addChild(btnItem, 0, _k)
                table.insert(btnContainerTables, btnItem)
                --背景
                local color = nil
                if index % 2 == 1 then
                    local stencil = CCSprite:createWithSpriteFrameName("jiemian_114.png")
                    stencil:setPosition(ccp(uiWidth/2, inv/2))
                    btnItem:addChild(stencil)
                end
                index = index + 1

                --名称
                local sp = CCSprite:createWithSpriteFrameName(string.format("%s.png",GFuncGetTableBuilds()[info.bid].namesp))
                sp:setAnchorPoint(ccp(0,0.5))
                sp:setPosition(ccp(180, inv/2))
                btnItem:addChild(sp)

                --lv sp
                local sp = CCLabelTTF:create(string.format("lv%d", info.lv), "Arial", 32)
                sp:setAnchorPoint(ccp(0,0.5))
                sp:setPosition(ccp(80, inv/2))
                sp:setColor(ccc3(156,110,32))
                btnItem:addChild(sp)

                local icopx, icopy = uiWidth-120, inv/2
                ----根据不同的产出,获得显示内容
                local spoutMoney = GameNumbers:new(vNumberBFHui, NumberAlginment_Right)
                spoutMoney:setPosition(ccp(icopx, icopy))
                spoutMoney:addLayer(btnItem)

                local spmoneyIcon = nil
                local vmoney = 0
                if info:getOutAgree() > 0 then
                    --认同值
                    spmoneyIcon = CCSprite:createWithSpriteFrameName("jiemian_151.png")
                    vmoney = info:getOutAgree()
                elseif info:getOutMagic() > 0 then
                    --魔法点图标
                    spmoneyIcon = CCSprite:createWithSpriteFrameName(SIconMagic)
                    vmoney = info:getOutMagic()
                else
                    --金币图标
                    spmoneyIcon = CCSprite:createWithSpriteFrameName(SIconMoney)
                    vmoney = info:getOutMoney()
                end
                spoutMoney:setString(vmoney)
                spmoneyIcon:setAnchorPoint(ccp(0,0.5))
                btnItem:addChild(spmoneyIcon)
                spmoneyIcon:setPosition(ccp(icopx+15,icopy))

            end
            _container:setSize(nil, inv*index- psum *inv)
        elseif _type == vTypeArea then
            --AreaInfos
            -- 地区显示
            local index = 0
            psum = 6
            --只显示已开启地区的信息
            for _k,_v in pairs(PlayerInfos.areaOpenlist) do
                local info = PlayerInfos.AreaInfos[_k]
                --列出项目
                local function clickItem(tag)
                    --layer:setTouchEnabled(false)
                    --layer.menu:setTouchEnabled(false)
                end
                local btnItem = GFunc_CreateButtonLabel("", clickItem, nil, CCSizeMake(visitWidth, inv))
                btnItem:setPosition(ccp(visitWidth/2 - 45, 565 - inv * index))
                menuchild:addChild(btnItem, 0, _k)
                table.insert(btnContainerTables, btnItem)
                --背景
                local color = nil
                if index % 2 == 1 then
                    local stencil = CCSprite:createWithSpriteFrameName("jiemian_114.png")
                    stencil:setPosition(ccp(uiWidth/2, inv/2))
                    btnItem:addChild(stencil)
                end
                index = index + 1

                --名称
                --local itemname = MapArea_Static[_k].name
                --local sp = CCLabelTTF:create(itemname, "Arial", 32)
                --sp:setAnchorPoint(ccp(0,0.5))
                --sp:setPosition(ccp(120, inv/2))
                --sp:setColor(ccc3(93,139,69))
                --btnItem:addChild(sp)
                local sp = CCSprite:createWithSpriteFrameName(string.format("%s.png",MapArea_Static[_k].namesp))
                sp:setAnchorPoint(ccp(0,0.5))
                sp:setScale(0.7)
                sp:setPosition(ccp(90, inv/2))
                btnItem:addChild(sp)

                --lv sp
                local sp = CCLabelTTF:create(string.format("lv%d", info.lv), "Arial", 32)
                sp:setAnchorPoint(ccp(0,0.5))
                sp:setPosition(ccp(30, inv/2))
                sp:setColor(ccc3(156,110,32))
                btnItem:addChild(sp)
                --local spbg = CCSprite:createWithSpriteFrameName("jiemian_038.png")
                --spbg:setAnchorPoint(ccp(0,0.5))
                --spbg:setPosition(ccp(25, inv/2))
                --btnItem:addChild(spbg)
                --lv数字
                --local numberLv = GameNumbers:new(vNumberWhite, NumberAlginment_Left)
                --numberLv:addLayer(btnItem)
                --numberLv:setPosition(ccp(80, inv/2))
                --numberLv:setString(info.lv)

                --等级/认同度
                --local sp = CCLabelTTF:create(string.format("认同度:%d/%d", info.agree, PlayerInfos:getNextAgree(_k)), "Arial", 28)
                --sp:setAnchorPoint(ccp(0,0.5))
                --sp:setPosition(ccp(340, inv/2))
                --sp:setColor(ccc3(109,121,32))
                --btnItem:addChild(sp)


                local spmoneyIcon = CCSprite:createWithSpriteFrameName("jiemian_151.png")
                spmoneyIcon:setAnchorPoint(ccp(0,0.5))
                spmoneyIcon:setPosition(ccp(uiWidth-140, inv/2))
                btnItem:addChild(spmoneyIcon)
                local numberLv = GameNumbers:new(vNumberWhite, NumberAlginment_Right)
                numberLv:addLayer(btnItem)
                numberLv:setPosition(ccp(uiWidth-145, inv/2))
                numberLv:setScale(0.8)
                numberLv:setColor(ccc3(139,99,36))
                numberLv:setString(string.format("%d/%d",info.agree, PlayerInfos:getNextAgree(_k)))
            end
            _container:setSize(nil, inv*index- psum *inv)
        end
    end

    -------///////////////
    local btnItemStatus = nil
    local btnItemRole = nil
    local btnItemReward = nil
    local btnItemArea = nil
    local function changeTaskList(tag)
        btnItemStatus:setEnabled(true)
        btnItemRole:setEnabled(true)
        btnItemReward:setEnabled(true)
        btnItemArea:setEnabled(true)
        if tag == vTypeRole then
            btnItemRole:setEnabled(false)
        elseif tag == vTypeReward then
            btnItemReward:setEnabled(false)
        elseif tag == vTypeArea then
            btnItemArea:setEnabled(false)
        else
            tag = vTypeStatus
            btnItemStatus:setEnabled(false)
        end
        reloadinfo(tag)
        selectType = tag
    end

    local bpx = 140
    local bpy = uiHeight- 53
    local inv = 100

    --状态
    btnItemStatus = GFunc_CreateButtonDPOther("jiemian_130.png", "jiemian_124.png", changeTaskList, nil, 1.2)
    btnItemStatus:setPosition(ccp(bpx, bpy))
    _menu:addChild(btnItemStatus,0, vTypeStatus)
    table.insert(btnTables, btnItemStatus)

    --勇者
    btnItemRole = GFunc_CreateButtonDPOther("jiemian_131.png", "jiemian_125.png", changeTaskList, nil, 1.2)
    btnItemRole:setPosition(ccp(bpx + inv * 1, bpy))
    _menu:addChild(btnItemRole,0, vTypeRole)
    table.insert(btnTables, btnItemRole)

    --收益
    btnItemReward = GFunc_CreateButtonDPOther("jiemian_132.png", "jiemian_126.png", changeTaskList, nil, 1.2)
    btnItemReward:setPosition(ccp(bpx + inv * 2, bpy))
    _menu:addChild(btnItemReward,0, vTypeReward)
    table.insert(btnTables, btnItemReward)

    --地区
    btnItemArea = GFunc_CreateButtonDPOther("jiemian_133.png", "jiemian_127.png", changeTaskList, nil, 1.2)
    btnItemArea:setPosition(ccp(bpx + inv * 3, bpy))
    _menu:addChild(btnItemArea,0, vTypeArea)
    table.insert(btnTables, btnItemArea)


    changeTaskList()



    --关闭
    local btnItem = GFunc_CreateButtonP("jiemian_105.png", function()
        closeFunc()
    end, nil, 2)
    btnItem:setPosition(ccp(uiWidth-10, uiHeight-30))
    _menu:addChild(btnItem)
    table.insert(btnTables, btnItem)

    --界面显示位置
    parentX, parentY = DWinSize.width/2 - uiWidth/2, DWinSize.height/2 - uiHeight/2
    _parent:setPosition(ccp(parentX, parentY))
end

function GCreatePlayerProperty()
    local _parent = CCNode:create()

    ---玩家信息显示
    local spbg = CCSprite:createWithSpriteFrameName("jiemian_119.png")
    spbg:setAnchorPoint(ccp(0,1))
    _parent:addChild(spbg)

    --生命值
    local spmoney = GameNumbers:new(vNumberWhite, NumberAlginment_Right)
    spmoney:setPosition(ccp(260, 155))
    spmoney:addLayer(spbg)
    spmoney:setString(PlayerInfos.hpmax)

    --防御
    local spmoney = GameNumbers:new(vNumberWhite)
    spmoney:setPosition(ccp(250, 95))
    spmoney:addLayer(spbg)
    spmoney:setString(PlayerInfos.def)

    --回避
    local spmoney = GameNumbers:new(vNumberBFHui, NumberAlginment_Right)
    spmoney:setPosition(ccp(220, 32))
    spmoney:addLayer(spbg)
    spmoney:setString(string.format("%d%s",PlayerInfos.avoid,"%"))

    return _parent
end


-------显示勇者的详细信息
function GFuncShowGmaeRoleInfos(args)
    local info, endfunc = args.info, args.func

    local layer = nil
    local parentX, parentY = 0,0
    -- 
    local function touchBegin(x,y,eventType)
        --GFunc_SelectBtnRun(btnTables,x-parentX,y-parentY,eventType)
    end
    local function touchMoved(x,y, eventType)
        --GFunc_SelectBtnRun(btnTables,x-parentX,y-parentY,eventType)
    end
    local function touchEnded(x,y,eventType)
        --GFunc_SelectBtnRun(btnTables,x-parentX,y-parentY,eventType)
        CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
        if endfunc then
            endfunc()
        end
    end

    if not args.nobg then
        layer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,100),touchBegin=touchBegin, touchMoved=touchMoved, touchEnded=touchEnded, fmbg = true})
    else
        layer = GFunc_CreateLayerEnterOrExit()
    end

    local layerindex = 0
    if args.lindex then
        layerindex = args.lindex
    end
    CCDirector:sharedDirector():getRunningScene():addChild(layer, layerindex)


    local _parent = CCNode:create()
    layer:addChild(_parent)
    local _menu = CCMenu:create()
    _menu:setPosition(ccp(0,0))
    _parent:addChild(_menu,1)

    local uiWidth,uiHeight = 580, 300
    local spbg = CCScale9Sprite:createWithSpriteFrameName("jiemian_004.png", CCRectMake(30, 30, 10, 10))
    spbg:setContentSize(CCSizeMake(uiWidth,uiHeight))
    spbg:setPosition(ccp(uiWidth/2, uiHeight/2))
    _parent:addChild(spbg)

    --名字
    local newHead = createRoleIcon(info)
    local spbg = newHead.btn
    spbg:setEnabled(false)
    spbg:setPosition(ccp(100, uiHeight - 50))
    _parent:addChild(spbg)

    --技能描述
    local skdes = ""
    if info.des then
        skdes = info.des--SkillTables_Static[info.skill].des or ""
    end

    --描述
    local txtn = CCLabelTTF:create(skdes, "Arial", 32, CCSizeMake(uiWidth-80, 125), kCCTextAlignmentLeft)
    txtn:setAnchorPoint(ccp(0,1))
    txtn:setColor(ccc3(0,0,0))
    txtn:setPosition(ccp(25,uiHeight - 130))
    _parent:addChild(txtn)


    --属性相关
    --伤害
    local txtn = CCLabelTTF:create(string.format("攻击力:%d", info.atk), "Arial", 32)
    txtn:setAnchorPoint(ccp(0,1))
    txtn:setColor(ccc3(255,44,50))
    txtn:setPosition(ccp(200,uiHeight - 20))
    _parent:addChild(txtn)

    --经验
    local txtn = CCLabelTTF:create(string.format("经验值: %d / %d", info.expsum, info.expup), "Arial", 32)
    txtn:setAnchorPoint(ccp(0,1))
    txtn:setColor(ccc3(109,121,32))
    txtn:setPosition(ccp(200,uiHeight - 70))
    _parent:addChild(txtn)

    --界面显示位置
    parentX, parentY = DWinSize.width/2 - uiWidth/2, DWinSize.height/2 - uiHeight/2
    _parent:setPosition(ccp(parentX, parentY))

    return {layer=layer, parent = _parent, parentY = parentY, parentX = parentX, closefunc = touchEnded}
end