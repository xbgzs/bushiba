------gameUpdate.lua
KEY_OF_VERSION = "current-version-code"
KEY_OF_DOWNLOADED_VERSION = "downloaded-version-code"
--更新服务器链接
local serverUrl = "https://raw.github.com/xbgzs/bushiba/master/MagicEmpire/"
--需要更新的压缩文件与其版本信息列表
local UpdateDataTables = {
	{package = "lua", name="脚本"},
	{package = "res_map", name = "界面"},
}

---更新当前文件的本地版本号
local function gameGameUpdateDefault(package)
    require "lua/gameConfig"
	GFuc_SetUserStDerfault("download-"..package, GFuc_GetUserStDerfault(KEY_OF_VERSION))
end

--设置当前检测文件的相关信息
local function gameInitUpdateFile(package)
	--设定当前文件的本地版本号
	GFuc_SetUserStDerfault(KEY_OF_VERSION, GFuc_GetUserStrDefault("download-"..package))
	--设定文件url
	initUpdate(serverUrl..package..".zip",  serverUrl..package)

	print("当前...",serverUrl..package..".zip",  serverUrl..package)
end

---检查文件更新
local function gameCheckUpdate(package)
	gameInitUpdateFile(package)
	checkUpdate()
end
---更新文件
local function gameGameUpdate(package)
	GFuc_SetUserStDerfault(KEY_OF_DOWNLOADED_VERSION, "")
	gameInitUpdateFile(package)
	updateUpdate()
end


-----------检查更新界面
function createLayerCheckUpdate()
    local layer = nil
    local txttips = nil
    local updatePercent = 0
    local progress = nil

    local nextcheckupdate = nil
    local funcGameUpdateBegin = nil
    local funcGameUpdateNext = nil

    local Status_CheckUpdate    = 0x01
    local Status_None       = 0x02
    local Status_Update     = 0x03
    local status = Status_CheckUpdate

    local nowUpdate = nil

    local function closefunc()
        GFunc_RemoveChild(layer)
    end


    local function setUpdatehandler(result, param)
        layer:setTouchEnabled(false)

        if result == UPDATE_NOUPDATE then
            --检查下一个更新
            nextcheckupdate()
        elseif result == UPDATE_HASUPDATE then
            status = Status_None
            txttips:setString("")
            GFunc_ShowDialogEnterClance({msg="发现了新的游戏版本，需要进行更新吗？",func=function(_args)
                if _args.enter then
                	funcGameUpdateBegin()
                else
                    closefunc()
                end
            end})
        elseif result == UPDATE_SUCCESS then
        	--更新完成
        	if nowUpdate then
            	gameGameUpdateDefault(nowUpdate.package)
            end
            --下一个
            funcGameUpdateNext()
        elseif result == UPDATE_PROGRESS then
            updatePercent = param
            progress:update(updatePercent+0)
        elseif result == UPDATE_ERROR then
            status = Status_None
            txttips:setString("")
            GFunc_ShowGameDialogMessage({msg="更新时发生了错误",func=function()
                closefunc()
            end})
        end
    end
    ---更新回调
    GFuncSetJavaHandler(BYZ_UPDATE_HANDLE, setUpdatehandler)

    local checktime = 0
    local function update(dt)
        if status == Status_CheckUpdate then
            checktime = checktime + dt
            local strtips = "正在检查更新,请稍后"
            local psum = math.floor(checktime*10) / 5 % 4
            for k=1,psum do
                strtips = strtips.."."
            end
            txttips:setString(strtips)
        elseif status == Status_Update then
            checktime = checktime + dt
            local strtips = "更新中"
            local psum = math.floor(checktime*10) / 5 % 11
            local strtipsp = ""
            for k=1,psum do
                strtipsp = strtipsp.."."
            end
            strtips = string.format("%s%s%s", strtips, updatePercent, "%")
            if nowUpdate then
            	strtips = nowUpdate.name.."文件 "..strtips
            end
            txttips:setString(strtips.."\n"..strtipsp)
        end
    end

    --逐个文件判断更新
    local function funcCheckUpdate()
    	local index = 0

    	nextcheckupdate = function()
	    	index = index + 1
    		if index > #UpdateDataTables then
    			--全部检查完毕,没有发现更新
	            status = Status_None
	            txttips:setString("")
	            GFunc_ShowGameDialogMessage({msg="未发现更新",func=function()
	                closefunc()
	            end})
    		else
    			status = Status_CheckUpdate
    			---检查下一个更新文件
	    		local info = UpdateDataTables[index]
	    		gameCheckUpdate(info.package)
    		end
    	end
    	nextcheckupdate()
    	---更新状态为检查更新
    	status = Status_CheckUpdate
    end
    funcCheckUpdate()


    ------逐个文件开始更新游戏
    funcGameUpdateBegin = function()
    	local index = 0

    	funcGameUpdateNext = function()
	    	index = index + 1
    		if index > #UpdateDataTables then
    			--结束更新
	            status = Status_None
	            txttips:setString("")
	            GFunc_ShowGameDialogMessage({msg="更新完成!",func=function()
	            	--重启
	                updateReset()
	            end})
           	else
		        progress:setVisible(true)
		        updatePercent = 0
		        status = Status_Update
		        --继续更新下一个
	    		nowUpdate = UpdateDataTables[index]
	    		gameGameUpdate(nowUpdate.package)
           	end
    	end
    	funcGameUpdateNext()
    end



    layer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,100),update=update, fmbg=true, lindex=500})

    txttips = CCLabelTTF:create("", "Arial", 48)
    txttips:setPosition(ccp(DWinSize.width/2, DWinSize.height/2))
    layer:addChild(txttips)
    

    ---更新进度条
    progress = GameProgressCrols:new("jiemian_068.png", "jiemian_067.png")
    progress:setAllProgress(100)
    progress:setPosition(ccp(DWinSize.width/2 - progress._bgsp:getContentSize().width/2, DWinSize.height/2 + 80))
    progress:addToParent(layer)
    progress:setVisible(false)

    CCDirector:sharedDirector():getRunningScene():addChild(layer,15)
end