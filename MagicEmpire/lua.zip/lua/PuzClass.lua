---------------三消算法类
JugeType_Puz    = 0x01
JugeType_PuzList= 0x02


PuzClass = {}
PuzClass.__index = PuzClass
---
function PuzClass:new(rows, cols, types)
    local self = {}   
    setmetatable(self, PuzClass)
    
    self._rows = rows --行数
    self._cols = cols --列数
    self._types = types --类型列表
    self._tables = {} --砖块列表
    
    self._jugetables = {} --已判定砖块列表(每回合需清空
    --判断消除类型
    self.puzType = JugeType_Puz

    -----------------------------
    self._func_cgem = nil --创建新砖块回调
    
    return self
end

--初始化所有方块
function PuzClass:init(func)
    if func then
        self:setCallback_CGemFunc(func)
    end
    self.bInit = true
    for r=1, self._rows do
        for c=1,self._cols do
            self:newGem(r, c)
        end
    end
    self.bInit = false
end
--新回合需要刷新______
function PuzClass:newRound()
    self._jugetables = {}
end
--添加已判定
function PuzClass:addJugeGem(r,c)
    self._jugetables[self:getGPos(r,c)] = true
end
--是否已经判定
function PuzClass:hasJugeGem(r,c)
    if self._jugetables[self:getGPos(r,c)] then
        return true
    end
    return false
end

--创建方块后的回调
function PuzClass:setCallback_CGemFunc(func)
    self._func_cgem = func
end

--创建一个砖块
function PuzClass:newGem(r, c, t, types)
    if t == nil then
        if types == nil then
            types = {}
            for k,v in pairs(self._types) do
                table.insert(types, v)
            end
        end

        --非可直接消除
        local function cgemtype(rtyps)
            local idx = rand(1, #rtyps)
            t = rtyps[idx]
            self._tables[self:getGPos(r,c)] = t
            --初始化不需要可连成的砖块
            if self.bInit then
                local rdata = self:jugePuzs(r, c, t, JugeType_PuzList)
                --超过最小消除数量则消除,并且生成新的砖块
                if #rdata >= 3 then
                    table.remove(rtyps, idx)
                    --再生成次
                    cgemtype(rtyps)
                end
            end
        end
        cgemtype(types)
    end
    self._tables[self:getGPos(r,c)] = t
    
    if self._func_cgem then
        self._func_cgem(r,c,t)
    end
end
--坐标转换成数值
function PuzClass:getGPos(r, c)
    return r*self._cols + c
end

--返回列表
function PuzClass:getTables()
    return self._tables
end

--设置位置的方块类型
function PuzClass:setGemType(r, c, t)
    self._tables[self:getGPos(r,c)] = t
end

--交换两个位置的方块
function PuzClass:swapGems(r1, c1, r2, c2)
    local tempt = self._tables[self:getGPos(r1,c1)]
    self._tables[self:getGPos(r1,c1)] = self._tables[self:getGPos(r2,c2)]
    self._tables[self:getGPos(r2,c2)] = tempt
end

--判断此位置的方块是否连成三消(jt:判定类型(直线,连续
function PuzClass:jugeGemPuzs(cgem, types)
    return self:jugePuzs(cgem.row, cgem.col, cgem.types, types)
end
function PuzClass:jugePuzs(r, c, _type, _jtype)
    local _rdata = {}
    
    if _jtype == nil then
        _jtype = self.puzType
    end
    
    --获取判定的类型
    if _type == nil then
        _type = self._tables[self:getGPos(r,c)]
    else
        --如果类型与当前位置的不同,直接返回
        if _type ~= self._tables[self:getGPos(r,c)] then
            return _rdata
        end
    end
    -----传统直线三消
    if _jtype == JugeType_Puz then
        _rdata = self:jugePuzForPuz(r, c, _type)
    elseif _jtype == JugeType_PuzList then
        _rdata = self:jugePuzForList(r, c, _type)
    end
    return _rdata
end
--传统三消,直接判定
function PuzClass:jugePuzForPuz(r, c, _type, sc)
    local _rdata = {}
    _rdata = self:jugePuzForPuzAgain(r,c,_type)

    local hasAddnode ={}

    --达成相关的十字消除,需要再次判定
    if #_rdata >= 3 and not sc then
        for _k, _info in pairs(_rdata) do
            --不重复判定添加
            hasAddnode[self:getGPos(_info.row, _info.col)] = true
            --
            self._jugetables[self:getGPos(_info.row, _info.col)] = false
            local _againrdata = self:jugePuzForPuz(_info.row, _info.col, _type, true)
            if #_againrdata >= 3 then
                for _ka, _infoa in pairs(_againrdata) do
                    if not hasAddnode[self:getGPos(_infoa.row, _infoa.col)] then
                        table.insert(_rdata, _infoa)
                    end
                end
            end
        end
    end

    return _rdata
end

function PuzClass:GetGemType(r, c)
    local rtype = nil
    if not self:hasJugeGem(r,c) then
        rtype = self._tables[self:getGPos(r, c)]
    end
    return rtype
end

function PuzClass:jugePuzForPuzAgain(r, c, _type)
    --分别获得四周数量
    local _lc,_rc,_ur,_dr = 0,0,0,0
    --左
    local _c = c - 1
    while _c >= 1 and _type == self:GetGemType(r, _c) do
        _lc = _lc + 1
        _c = _c - 1
    end
    --右
    local _c = c + 1
    while _c <= self._cols and _type == self:GetGemType(r, _c) do
        _rc = _rc + 1
        _c = _c + 1
    end
    --上
    local _r = r - 1
    while _r >= 1 and _type == self:GetGemType(_r, c) do
        _ur = _ur + 1
        _r = _r - 1
    end
    --下
    local _r = r + 1
    while _r <= self._rows and _type == self:GetGemType(_r, c) do
        _dr = _dr + 1
        _r = _r + 1
    end
    --添加至已判定列表中
    _lc = c - _lc
    _rc = c + _rc
    _ur = r - _ur
    _dr = r + _dr
    --已添加判定节点
    --返回所有符合条件的方块数据
    local _rdata = {}
    table.insert(_rdata, {row=r, col=c})
    local function addRdata(_rrow,_rcol)
        if _rrow ~= r or _rcol ~= c then
            table.insert(_rdata, {row=_rrow, col=_rcol})
        end
    end
    --为避免重复判定砖块,所以添加至已判定砖块中
    --并且添加达成条件的砖块到返回列表中
    for bcol = _lc, _rc do
        self:addJugeGem(r, bcol)
        if _rc - _lc >= 2 then
            addRdata(r, bcol)
        end
    end
    for brow = _ur, _dr do
        self:addJugeGem(brow, c)
        if _dr - _ur >= 2 then
            addRdata(brow, c)
        end
    end
    
    return _rdata
end
--判断三消,连接即消除
function PuzClass:jugePuzForListAccess(...)
    local r, c, _type, _hasAccess, _nodes = ...
    --是否超出范围
    if r < 1 or c < 1 or r > self._rows or c > self._cols then
        return _nodes
    end
    
    local key = self:getGPos(r, c)
    --是否已经访问过
    if _hasAccess[key] then
        return _nodes
    end
    
    --添加至已经访问的节点中
    _hasAccess[key] = true
    
    --是否相同
    if self._tables[key] == _type then
        --添加到链接节点中
        table.insert(_nodes, {row=r, col=c})
        --相同则判定周边没有被访问的节点
        --上
        self:jugePuzForListAccess(r+1, c, _type, _hasAccess, _nodes)
        --下
        self:jugePuzForListAccess(r-1, c, _type, _hasAccess, _nodes)
        --左
        self:jugePuzForListAccess(r, c-1, _type, _hasAccess, _nodes)
        --右
        self:jugePuzForListAccess(r, c+1, _type, _hasAccess, _nodes)
    end
    return _nodes
end

function PuzClass:jugePuzForList(r, c, _type)
    local _hasAccess = {} --已访问节点
    local _nodes = {} --链接节点
    
    local rdata = {}
    --开始逐个节点访问
    rdata = self:jugePuzForListAccess(r,c, _type, _hasAccess, _nodes)
    return rdata
end










