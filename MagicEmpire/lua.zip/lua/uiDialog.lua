----uiDialog
GGameDialogIsShow = false
------在游戏结果之前,如果拥有复活道具,则显示复活界面
GFunc_ShowGameDialogMessage = function(args)
    local layer = nil
    local show = false
    local msg = args.msg
    local func = args.func
    local function touchEnded()
        if not show then
            return
        end

        GGameDialogIsShow = false
        if layer then
            CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
        end
        if func then
            func()
        end
    end
    local function touchBegin()
    end

    local function exlayer()
        GFInterface_MessageDialog = nil
    end
    
    GGameDialogIsShow = true
    layer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,100),touchBegin=touchBegin, touchMoved=function()end, 
        touchEnded=touchEnded, exfunc=exlayer, fmbg=true, lindex=100})
    GFInterface_MessageDialog = layer
    
    -- 背景图片
    local _bgBrick = CCScale9Sprite:createWithSpriteFrameName("jiemian_010.png", CCRectMake(25, 25, 20, 20))
    _bgBrick:setContentSize(CCSizeMake(440, 320))
    _bgBrick:setAnchorPoint(ccp(0.5, 0.5))
    _bgBrick:setPosition(ccp(DWinSize.width/2, DWinSize.height/2))
    layer:addChild(_bgBrick)
    --放大背景
    _bgBrick:setScale(0.1)
    
    -- 文本
    local _lbMessage = CCLabelTTF:create(msg, "Arial", 32, CCSizeMake(400, 150), kCCTextAlignmentCenter)
    _lbMessage:setPosition(ccp(DWinSize.width/2, DWinSize.height/2))
    _lbMessage:setVisible(false)
    _lbMessage:setColor(ccc3(255,255,255))--248,236,184))
    layer:addChild(_lbMessage)
    
    _bgBrick:runAction(CCSequence:createWithTwoActions(CCScaleTo:create(0.2, 1.0), CCCallFunc:create(function()
        _lbMessage:setVisible(true)
        show = true
    end)))
    
    CCDirector:sharedDirector():getRunningScene():addChild(layer, 15)
end

---------拥有确认与取消的对话框
GFunc_ShowDialogEnterClance = function(args)
    local msg = args.msg
    local func = args.func
    local layerParent = args.layer

    local btnTables = {}

    local layer = nil --CCLayer:create()
    local function closeFunc(_args)
        if layer then
            CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
        end
        if _args == nil then
            _args = {}
        end
        
        if func then
            func(_args)
        end

        GGameDialogIsShow = false
    end
    
    
    GGameDialogIsShow = true
    ----////////////////
    local function func_touchBegen(x,y,eventType)
        --print(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x,y,eventType)
    end
    
    local function func_touchMoved(x,y,eventType)
        --print(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x,y,eventType)
    end
    
    local function func_touchEnded(x,y,eventType)
        --print(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x,y,eventType)
    end
    
    layer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,100),touchBegin=touchBegin, touchMoved=function()end, 
        touchEnded=touchEnded, fmbg=true, lindex=100})
    
    -- 背景图片
    local uiWidht, uiHeight = 480, 320
    local _bgBrick = CCScale9Sprite:createWithSpriteFrameName("jiemian_010.png", CCRectMake(25, 25, 20, 20))
    _bgBrick:setContentSize(CCSizeMake(uiWidht, uiHeight))
    _bgBrick:setAnchorPoint(ccp(0.5, 0.5))
    _bgBrick:setPosition(ccp(DWinSize.width/2, DWinSize.height/2))
    layer:addChild(_bgBrick)
    --放大背景
    _bgBrick:setScale(0.1)
    
    --确认按钮
    local menu = CCMenu:create()
    menu:setPosition(ccp(0,0))
    _bgBrick:addChild(menu)
    local btnEnterItem = GFunc_CreateButtonLabel("确认",function()
        closeFunc({enter=true})
    end, 32)
    btnEnterItem:setPosition(ccp(uiWidht*0.35, uiHeight*0.2))
    btnEnterItem:setVisible(false)
    menu:addChild(btnEnterItem)
    table.insert(btnTables, btnEnterItem)
    
    local btnCancelItem = GFunc_CreateButtonLabel("取消",function()
        closeFunc()
    end, 32)
    btnCancelItem:setPosition(ccp(uiWidht*0.65, uiHeight*0.2))
    menu:addChild(btnCancelItem)
    table.insert(btnTables, btnCancelItem)
    btnCancelItem:setVisible(false)

    local color = nil
    if args.color then
        color = args.color
    else
        color = ccc3(255,255,255)
    end
    
    -- 文本
    local _lbMessage = CCLabelTTF:create(msg, "Arial", 32, CCSizeMake(450, 150), kCCTextAlignmentCenter)
    _lbMessage:setPosition(ccp(uiWidht/2, uiHeight/2))
    _lbMessage:setVisible(false)
    _lbMessage:setColor(color)
    _bgBrick:addChild(_lbMessage)
    
    _bgBrick:runAction(CCSequence:createWithTwoActions(CCScaleTo:create(0.2, 1.0), CCCallFunc:create(function()
        _lbMessage:setVisible(true)
        btnEnterItem:setVisible(true)
        btnCancelItem:setVisible(true)
    end)))
    
    
    CCDirector:sharedDirector():getRunningScene():addChild(layer, 15)
end



-----------获得奖励报酬
function GFunc_GameDialogReward(args)
    local show = false
    local layer = nil
    local money = args.money or 0
    local itemID = args.itemid
    local itemSum = args.itemsum
    local func = args.func
    local function touchEnded()
        if not show then
            return
        end

        if layer then
            CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
        end
        if func then
            func()
        end
        GGameDialogIsShow = false


        if hasfinshTutorial(TStep6) and not hasfinshTutorial(TStep7) then
            TutorialTaskRun(TStep7)
            tutorial = true
        end
    end
    local function touchBegin()
    end

    if money == 0 and itemID == 0 then
        show = true
        touchEnded()
        return
    end
    
    GGameDialogIsShow = true
    layer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,100),touchBegin=touchBegin, touchMoved=function()end, 
        touchEnded=touchEnded, fmbg=true, lindex=100})
    
    -- 背景图片
    local uiWidht, uiHeight = 440, 320
    local _bgBrick = CCScale9Sprite:createWithSpriteFrameName("jiemian_010.png", CCRectMake(25, 25, 20, 20))
    _bgBrick:setContentSize(CCSizeMake(uiWidht, uiHeight))
    _bgBrick:setAnchorPoint(ccp(0.5, 0.5))
    _bgBrick:setPosition(ccp(DWinSize.width/2, DWinSize.height/2))
    layer:addChild(_bgBrick)
    --放大背景
    _bgBrick:setScale(0.1)


    local txtTitle = CCLabelTTF:create("获得报酬!", "Arial", 36)
    txtTitle:setPosition(ccp(uiWidht/2, uiHeight*0.7))
    txtTitle:setColor(ccc3(255,255,255))
    _bgBrick:addChild(txtTitle)
    
    --报酬sp
    local spbg = nil
    local numberLv = nil
    if money ~= 0 then
    spbg = CCSprite:createWithSpriteFrameName(SIconMoney)
    spbg:setAnchorPoint(ccp(0,0.5))
    spbg:setPosition(ccp(uiWidht/2+50, uiHeight/2))
    _bgBrick:addChild(spbg)
    spbg:setVisible(false)
    --报酬数值
    numberLv = GameNumbers:new(vNumberWhite, NumberAlginment_Right)
    numberLv:addLayer(_bgBrick)
    numberLv:setPosition(ccp(uiWidht/2+45, uiHeight/2))
    numberLv:setString(money or 0)
    numberLv:setVisible(false)
    end
    --print("获得报酬 ",money)

    --物品sp
    local txtItem = nil
    if itemID ~= 0 then
        txtItem = CCLabelTTF:create(string.format("%sx%d", ItemList_Static[itemID].name, itemSum), "Arial", 36)
        txtItem:setPosition(ccp(uiWidht/2, uiHeight*0.35))
        txtItem:setColor(ccc3(255,255,255))
        _bgBrick:addChild(txtItem)
    end
    if txtItem then
        txtItem:setVisible(false)
    end

    _bgBrick:runAction(CCSequence:createWithTwoActions(CCScaleTo:create(0.1, 1.0), CCCallFunc:create(function()
        if spbg then spbg:setVisible(true) end
        if numberLv then numberLv:setVisible(true) end
        if txtItem then
            txtItem:setVisible(true)
        end

        show = true
    end)))
    
    CCDirector:sharedDirector():getRunningScene():addChild(layer, 15)
end



-----------获得宝箱奖励报酬
function GFunc_GameDialogFightBoxReward(args)
    local layer = nil
    local fightInfos = args.info
    local itemID = 0
    local itemSum = 0
    local func = args.func
    local function touchEnded()
        if layer then
            CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
        end
        if func then
            func()
        end
    end
    local function touchBegin()
    end
    
    layer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,100),touchBegin=touchBegin, touchMoved=function()end, 
        touchEnded=touchEnded, fmbg=true})
    
    -- 背景图片
    local uiWidht, uiHeight = 440, 320
    local _bgBrick = CCScale9Sprite:createWithSpriteFrameName("jiemian_010.png", CCRectMake(25, 25, 20, 20))
    _bgBrick:setContentSize(CCSizeMake(uiWidht, uiHeight))
    _bgBrick:setAnchorPoint(ccp(0.5, 0.5))
    _bgBrick:setPosition(ccp(DWinSize.width/2, DWinSize.height/2))
    layer:addChild(_bgBrick)
    --放大背景
    _bgBrick:setScale(0.1)

    -----得到可获得的物品
    if fightInfos.ritem then
        local rparaminfos = lua_string_split(fightInfos.ritem or "", "|")
        local _itemsTbl = {}
        for _k,_item in pairs(rparaminfos) do
            local _ritem = lua_string_split(_item or "", "+")
            if #_ritem > 1 then
                local _riID = _ritem[1] + 0
                local _rcut = _ritem[2] + 0
                ---必须有道具
                if _riID ~= 0 then
                for _kv=1,_rcut do
                    table.insert(_itemsTbl, _riID)
                end
                end
            end
        end
        if #_itemsTbl > 0 then
            itemID = _itemsTbl[rand(1,#_itemsTbl)]
            itemSum = 1
        end
    else
        touchEnded()
        return
    end


    local txtTitle = CCLabelTTF:create("打开宝箱后，您获得了", "Arial", 36)
    txtTitle:setPosition(ccp(uiWidht/2, uiHeight*0.7))
    txtTitle:setColor(ccc3(255,255,255))
    _bgBrick:addChild(txtTitle)
    
    --报酬sp
    local spbg = nil
    local numberLv = nil
    if money or 0 ~= 0 then
    spbg = CCSprite:createWithSpriteFrameName(SIconMoney)
    spbg:setAnchorPoint(ccp(0,0.5))
    spbg:setPosition(ccp(uiWidht/2+50, uiHeight/2))
    _bgBrick:addChild(spbg)
    spbg:setVisible(false)
    --报酬数值
    numberLv = GameNumbers:new(vNumberWhite, NumberAlginment_Right)
    numberLv:addLayer(_bgBrick)
    numberLv:setPosition(ccp(uiWidht/2+45, uiHeight/2))
    numberLv:setString(money or 0)
    numberLv:setVisible(false)
    end

    --物品sp
    local txtItem = nil
    if itemID ~= 0 then
        txtItem = CCLabelTTF:create(string.format("%sx%d", ItemList_Static[itemID].name, itemSum), "Arial", 36)
        txtItem:setPosition(ccp(uiWidht/2, uiHeight*0.35))
        txtItem:setColor(ccc3(255,255,255))
        _bgBrick:addChild(txtItem)
    end
    if txtItem then
        txtItem:setVisible(false)
    end

    _bgBrick:runAction(CCSequence:createWithTwoActions(CCScaleTo:create(0.1, 1.0), CCCallFunc:create(function()
        if spbg then spbg:setVisible(true) end
        if numberLv then numberLv:setVisible(true) end
        if txtItem then
            txtItem:setVisible(true)
        end
    end)))
    
    CCDirector:sharedDirector():getRunningScene():addChild(layer, 15)
end