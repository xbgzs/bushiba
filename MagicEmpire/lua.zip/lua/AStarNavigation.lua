
-----寻路算法
--1. 从起点开始，起点的f = 1 + g,  1表示此节点已走过的路径是1，g是此节点到终点的估计距离， 放入链表openlist中。
--可以假设g值的计算使用勾股定理公式来计算此点到终点的直线距离。
--2. 当openlist不为空时，从中取出一个最小f值的节点x。
--3.如果x等于终点，找到路径，算法结束。否则走第4步.
--4. 遍历x的所有相邻点，对所有相邻点使用公式f,计算出f值后，
--先检查每个相邻节点y是否在链表openlist和closelist中，
--如果在openlist中的话的话，更新y节点的f值，保留最小的f值，
--如果在closelist中的话，并且此时f值比closelist中的f值小，则更新f值，将y节点从closelist中移到openlist中。否则不做操作。
--如果不在以上两表中，按最小顺序排序将y插入链表openlist。最后将x插入closelist表中。
--如果相邻点不是路径，比如是障碍，那就跳过。
--5.继续2,3,4步直到找到终点， 或者直到openlist为空表示没找到路径。
--row:,col:起始坐标， torow,tocol:目标坐标  ViewMovedFor(row,col,row2,col2):判断相邻的两点是否可移动
function AStarNavigation(args)
    local row, col, torow, tocol, ViewMovedFor, _row_max, _col_max = args.row, args.col, args.torow, args.tocol, args.jugemove, args.rowsum, args.colsum
    local hasAccess = {}    --已访问
    local paths = {}
    local readyAccess = {}  --准备访问
    local noAccess = {}     --未访问
    
    local jugeRoad = nil
    
    local ARow = row
    local ACol = col
    
    ---
    ---待处理表
    local openlist = {}
    local _olist = {}
    ----已处理表
    local closelist = {}
    local _clist = {}
    
    
    local function getkey(r, c)
        if r< 0 or r >= _row_max then
            r = 100
        end
        if c < 0 or c >= _col_max then
            c = 100
        end
        return r*_col_max+c
    end
    
    
    
    local function removeopen(_row, _col)
        _olist[getkey(_row,_col)] = nil
    end
    local function removeclose(_row, _col)
        _clist[getkey(_row,_col)] = nil
        
        for k,info in pairs(closelist) do
            if info.row == _row and info.col == _col then
                closelist[k] = nil
                table.remove(closelist,k)
                break
            end
        end
    end
    --最终路径长度f = 起点到该点的已知长度h + 该点到终点的估计长度g。
    local function fvalue(_row, _col)
        return 1 + ccpLength(ccp(_row-torow, _col-tocol))
    end
    --添加到openlist中
    local function addToOpen(_info)
        removeclose(_info.row, _info.col)
        
        table.insert(openlist, _info)
        _olist[getkey(_info.row, _info.col)] = _info
        
    end
    
    local function sortfvalue(a,b)
        local rst = true
        if a  == nil or b == nil then
            rst = true
        else
            rst = a.lenght <= b.lenght
        end
        return rst
    end
    local function sorttables(_table)
        local newlist = {}
        for k=1,#_table-1 do
            local info = _table[k]
            local info2 = _table[k+1]
            if not sortfvalue(info, info2) then
                _table[k] = info2
                _table[k+1] = info
            end
        end
        
    end
    local function sortopen()
        if #openlist >= 2 then
            sorttables(openlist)
        end
    end
    ---添加到closelist中
    local function addToClose(_info)
        removeopen(_info.row, _info.col)
        
        --计算点到终点的距离
        table.insert(closelist, _info)
        _clist[getkey(_info.row, _info.col)] = _info
        
    end
    local function sortclose()
        if #openlist > 2 then
            sorttables(closelist)
        end
    end
    
    ----是否在openlist中
    local function hasOpenlist(_row, _col)
        if _olist[getkey(_row,_col)] then
            return _olist[getkey(_row,_col)]
        end
        return nil
    end
    ----是否在closelist中
    local function hasCloselist(_row, _col)
        if _clist[getkey(_row,_col)] then
            return _clist[getkey(_row,_col)]
        end
        return nil
    end
    
    ----初始化所有表信息
    local nvmapdatas = {}
    for col=0, _col_max-1 do
        for row=0, _row_max-1 do
            if nvmapdatas[row] == nil then
                nvmapdatas[row] = {}
            end
            nvmapdatas[row][col] = {row=row, col=col, lenght=fvalue(row, col), frow=nil, fcol=nil}
        end
    end
    local function getDataForPos(row,col)
        if nvmapdatas[row] and nvmapdatas[row][col] then
            return nvmapdatas[row][col]
        end

        return nil
    end
    
    jugeRoad = function()
        --2.当openlist不为空时，从中取出一个最小f值的节点x。
        if #openlist > 0 then
            --
            local _grid = openlist[1]
            local _brow = _grid.row
            local _bcol = _grid.col
            
            ---获取当前点的信息
            local _myinfo = getDataForPos(_brow,_bcol)
            
            openlist[1] = nil
            table.remove(openlist, 1)
            --3.如果x等于终点，找到路径，算法结束。否则走第4步.
            if _brow == torow and _bcol == tocol then
                addToClose(_myinfo)
                return true
            else
                --4. 遍历x的所有相邻点，对所有相邻点使用公式f,计算出f值后，
                --先检查每个相邻节点y是否在链表openlist和closelist中，
                --如果在openlist中的话的话，更新y节点的f值，保留最小的f值，
                --如果在closelist中的话，并且此时f值比closelist中的f值小，则更新f值，将y节点从closelist中移到openlist中。否则不做操作。
                --如果不在以上两表中，按最小顺序排序将y插入链表openlist。最后将x插入closelist表中。
                --如果相邻点不是路径，比如是障碍，那就跳过。
                local templist = {}
                local function jugeForStep4(_row, _col)
                    if ViewMovedFor(_row, _col, _brow, _bcol) then
                        --4.1.先检查每个相邻节点y是否在链表openlist和closelist中，
                        local _oinfo = hasOpenlist(_row, _col)
                        local _cinfo = nil
                        if _oinfo then
                            --4.1.1.如果在openlist中的话的话，更新y节点的f值，保留最小的f值，
                        else
                            local _cinfo = hasCloselist(_row, _col)
                            if _cinfo then
                                ----4.1.2.如果在closelist中的话，并且此时f值比closelist中的f值小，则更新f值，将y节点从closelist中移到openlist中。否则不做操作。
                            else
                                local _tempInfo = getDataForPos(_row,_col)
                                if _tempInfo then
                                _tempInfo.frow = _brow
                                _tempInfo.fcol = _bcol
                                table.insert(templist, _tempInfo)
                                end
                            end
                        end
                    end
                end
                
                jugeForStep4(_brow + 1, _bcol)
                jugeForStep4(_brow - 1, _bcol)
                jugeForStep4(_brow, _bcol + 1)
                jugeForStep4(_brow, _bcol - 1)
                
                for _k, _info in pairs(templist) do
                    addToOpen(_info)
                end
                
                --添加至关闭列表中
                addToClose(_myinfo)
                
                sortopen()
                
                if not jugeRoad(_brow, _bcol) then
                    --removeclose(_brow, _bcol)
                end
            end
        else
            return false
        end
        
        return true
    end
    
    --从初始位置开始判定
    --添加至已访问列表中
    --addpos(row, col)
    table.insert(openlist, {row=ARow, col=ACol, lenght=1+ccpLength(ccp(ARow-torow, ACol-tocol))})
    _olist[getkey(ARow,ACol)] = true
    
    local roadlist = {}
    jugeRoad()
    
    --从最后一条信息中按父节点获取路径
    local lastNode = closelist[#closelist]
    local rlist = {}
    while lastNode.frow ~= nil do
        --总是插入第一个位置
        table.insert(rlist, 1, {row=lastNode.row, col=lastNode.col})
        lastNode = nvmapdatas[lastNode.frow][lastNode.fcol]
    end
    
    return rlist
end