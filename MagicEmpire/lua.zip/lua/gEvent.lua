-----///gameEvent
--游戏事件通知相关
local function GameEvent_JugeTaskFinsh(type, param1, param2)
	if param2 == nil then
		param2 = 0
	end

	---任务解锁
	for taskID,info in pairs(GFuncGetTableTaskInfos()) do
		if info.status == GTaskStatus_Close then
			--是否达成条件
			local isfinsh = true
			if info.opentype == "-1" then
				isfinsh = false
			end

			for _k,_openinfo in pairs(info.openlist) do
				if _openinfo.finsh == false and _openinfo.type == type then
					-----
					if _openinfo.param1 == param1 and _openinfo.param2 == param2 then
						--达成条件
						_openinfo.finsh = true
					else
						isfinsh = false
					end
				else
					if _openinfo.finsh == false then
						isfinsh = false
					end
				end
			end

			if isfinsh then
				GFuncAddNewTask(taskID)
			end
		end
	end

	----建筑解锁
	for bid,info in pairs(GFuncGetTableBuilds()) do
		if PlayerInfos.openbuilds[bid] == nil or PlayerInfos.openbuilds[bid] == 0 then
			--是否达成条件
			local isfinsh = true
			for _k,_openinfo in pairs(info.openlist) do
				if _openinfo.finsh == false and _openinfo.type == type then
					-----
					if _openinfo.param1 == param1 and _openinfo.param2 == param2 then
						_openinfo.finsh = true
					else
						isfinsh = false
					end
				else
					if _openinfo.finsh == false then
						isfinsh = false
					end
				end
			end
			if isfinsh then
				GFunc_ShowSMessage(string.format("建筑 [%s] 已经解锁!",GFuncGetTableBuilds()[bid].name))
				PlayerInfos:unlockBuild(bid)
			end
		end
	end

	----研究解锁
	for bid,info in pairs(GFuncGetTableYanJius()) do
		if PlayerInfos.finshyanjius[bid] == nil or PlayerInfos.finshyanjius[bid] == 0 then
			--是否达成条件
			local isfinsh = true
			for _k,_openinfo in pairs(info.openlist) do
				if _openinfo.finsh == false and _openinfo.type == type then
					-----
					if _openinfo.param1 == param1 and _openinfo.param2 == param2 then
						_openinfo.finsh = true
					else
						isfinsh = false
					end
				else
					if _openinfo.finsh == false then
						isfinsh = false
					end
				end
			end
			if isfinsh then
				GFunc_ShowSMessage(string.format("研究 [%s] 已经解锁!",GFuncGetTableYanJius()[bid].name))
				PlayerInfos:unlockYanjiu(bid)
			end
		end
	end

	----角色解锁
	for aid,info in pairs(GFuncGetTableRoles()) do
		if PlayerInfos.AidRoles[aid] == nil and #info.openlist > 0 then
			--是否达成条件
			local isfinsh = true
			for _k,_openinfo in pairs(info.openlist) do
				if _openinfo.finsh == false and _openinfo.type == type then
					-----
					if _openinfo.param1 == param1 and _openinfo.param2 == param2 then
						_openinfo.finsh = true
					else
						isfinsh = false
					end
				else
					if _openinfo.finsh == false then
						isfinsh = false
					end
				end
			end
			if isfinsh then
				GFunc_ShowSMessage(string.format("勇者 [%s] 已经解锁!",GFuncGetTableRoles()[aid].name))
				PlayerInfos:unlockAidPlayer(aid)
			end
		end
	end
end

--//地区认同度等级提升
function GameEvent_AgreeLevelUp(mid, lv)
	---判断开启任务
	GameEvent_JugeTaskFinsh(GTaskOpenType_Argee, mid, lv)

	GFunc_ShowSMessage(string.format("[%s] 的认同度等级达到了 lv%d", MapArea_Static[mid].name, lv))

	--判断任务完成
	if not init then
		GameEvent_JugeTaskFinshEnd(GTaskType_Agree, {mid=mid,lv=lv})
	end
end

--//通过了一个平叛点
function GameEvent_PlaceFinsh(pid, init)
	if not init then
		GameEvent_JugeTaskFinsh(GTaskOpenType_FinshPlace, pid)
	
		--是否通过了此地区的所有平叛点
		local isallend = true
		----
		local mid = GFuncGetPlaceInfos(pid).mid
		for k,info in pairs(GFuncGetAllPlace(mid)) do
			if not GFuncGetPlaceFinsh(info.id) then
				isallend = false
				break
			end
		end


		if isallend then
			GameEvent_AreaFinsh(mid)
		end

        Config_AutoSaveGameData()
	end
end

--//通过了一个地区的所有平叛点
function GameEvent_AreaFinsh(mid)
	GameEvent_JugeTaskFinsh(GTaskOpenType_FinshArea, mid)
end

--//任务达成条件
function GameEvent_TaskTempFinsh(tid, init)
	local info = GFuncGetTaskForID(tid)
	info.status = GTaskStatus_FinshTemp

	if not init then
		GFunc_ShowSMessage(string.format("任务 [%s] 已经达成!",info.name))
	end
end

--//完成了一个任务
function GameEvent_TaskFinsh(tid, init)
	local info = GFuncGetTaskForID(tid)
	info.status = GTaskStatus_Finsh

	if not init then
		--GFunc_ShowSMessage(string.format("任务 [%s] 已经达成!",info.name))

		GameEvent_JugeTaskFinsh(GTaskOpenType_Task, tid)
        Config_AutoSaveGameData()
	end
end

--//移动到了一个新的区域
function GameEvent_GotoArea(mid)
	GameEvent_JugeTaskFinsh(GTaskOpenType_ToArea, mid)

	GFunc_ShowSMessage(string.format("已经到达 [%s] 了!", MapArea_Static[mid].name))

	GameEvent_JugeTaskFinshEnd(GTaskType_Moved, mid)

	GFunc_GotoFightMpaRefsh()
end

--//开启了一个新的任务
function GameEvent_OpenTask(tid, init)
	local info = GFuncGetTaskForID(tid)
	info.status = GTaskStatus_Open


	if not init then
		GFunc_ShowSMessage(string.format("开启任务 [%s]",info.name))

		GGameFuncNewTasks()

        --Config_AutoSaveGameData()

        ----添加新事件
        GameTaskOpenEvent_AddTaskd(tid)
	end
end

--//接受一个任务
function GameEvent_AcceptTask(tid, init)
	local info = GFuncGetTaskForID(tid)
	info.status = GTaskStatus_Accept

	--当接受新的发现地区任务时，开启新的区域
	--任务类型是GTaskType_Area的,则添加此地区至玩家开启地区列表
	if not init then
		if info.type == GTaskType_Area then
			PlayerInfos:OpenNewArea(info.param)

			GFunc_ShowSMessage(string.format("开放新的区域 [%s]",MapArea_Static[info.param].name))
		end
		
		GameEvent_JugeTaskFinsh(GTaskOpenType_AcceptTask, tid)
	end
end

--//开启了一个新的地区
function GameEvent_OpenArea(mid)
    GameEvent_JugeTaskFinsh(GTaskOpenType_AreaOpen, mid)
end

---判定任务完成情况
function GameEvent_JugeTaskFinshEnd(type, args)
	--
	local rtempID = {}
	--移动/新区域/运送类任务都关联着 GTaskType_Moved类型
	if type == GTaskType_Moved then ---移动完成
		local mid = args
		--查找相关的任务,
		for tid, v in pairs(PlayerInfos.acceptTasks) do
			local info = GFuncGetTaskForID(tid)
			if (info.mid == mid and info.type == GTaskType_Moved) or (info.type == GTaskType_Area and info.param == mid) then
				--
				table.insert(rtempID, tid)
			end
		end
	elseif type == GTaskType_Express then   --快递任务
		local tid = args
		local info = GFuncGetTaskForID(tid)
		----是否有足够的物品
    	if info.param then
    	    local rparaminfos = lua_string_split(info.param or "", "+")
    	    local param1 = rparaminfos[1]+0
    	    local param2 = rparaminfos[2]+0

    	    --是否有指定道具,没有则显示红色
   		    if PlayerInfos:getItem(param1) >= param2 then
    	      	--减少物品
    	      	PlayerInfos:addItems(param1, param2)
   	    	end
    	end
    	table.insert(rtempID, tid)
	elseif type == GTaskType_Fight then  --战斗任务
		local tid = args.tid
		local pid = args.pid
		if tid then
			local info = GFuncGetTaskForID(tid)
			table.insert(rtempID, tid)
		elseif pid then
			--平叛点战斗任务
			for tid, v in pairs(PlayerInfos.acceptTasks) do
				local info = GFuncGetTaskForID(tid)
				if info.type == GTaskType_Fight and info.param == pid then
					table.insert(rtempID, tid)
				end
			end
		end
	elseif type == GTaskType_Agree then  --认同度任务
		local mid = args.mid
		local agreelv = args.lv
		--print("认同值到达:",mid,agreelv)
		for tid, v in pairs(PlayerInfos.acceptTasks) do
			local info = GFuncGetTaskForID(tid) if info.mid == mid and info.type == GTaskType_Agree and info.param <= agreelv then
				table.insert(rtempID, tid)
			end
		end
	elseif type == GTaskType_Yanjiu then --研究任务
		local iID = args
		for tid, v in pairs(PlayerInfos.acceptTasks) do
			local info = GFuncGetTaskForID(tid)
			if info.type == GTaskType_Yanjiu and info.param == iID then
				table.insert(rtempID, tid)
			end
		end
	elseif type == GTaskType_Build then --建造任务
		local bid = args
		for tid, v in pairs(PlayerInfos.acceptTasks) do
			local info = GFuncGetTaskForID(tid)
			if info.type == GTaskType_Build and info.param == bid then
				table.insert(rtempID, tid)
			end
		end
	elseif type == GTaskType_AddShop then --添加商品
		local bid = args
		for tid, v in pairs(PlayerInfos.acceptTasks) do
			local info = GFuncGetTaskForID(tid)
			if info.type == GTaskType_AddShop and (info.param == nil or info.param == bid) then
				table.insert(rtempID, tid)
			end
		end
	end


	for k,tid in pairs(rtempID) do
		--完成的任务先保存到已完成任务临时列表中,当待在城堡界面时提示完成
		GFuncSetTaskFinshTemp(tid)
	end
end

--一件道具的研发完成了
function GameEvent_YanjiuEnd(itemID)
 	--研究的商品变成新的物品添加至道具列表中
  	local info = ItemList_Static[itemID]
  	
  	--道具研究次数+1
  	local myiteminfo = PlayerInfos:getItems()[itemID]
  	if myiteminfo then
  		myiteminfo.sumyj = myiteminfo.sumyj + 1
  	end
 	if info then
 		if info.item and info.type == ItemType_Property then
 			local value = info.money or 0
   			---直接增加角色属性
   			local strpro = ""
   			local strvalue = string.format("%d",value)
   			if info.item == PlayerProperty_Hp then
   				PlayerInfos:addProHp(value)
   				strpro = "生命值"
   			elseif info.item == PlayerProperty_Def then
   				PlayerInfos:addProDef(value)
   				strpro = "防御值"
   			elseif info. item == PlayerProperty_Avoid then
   				PlayerInfos:addProAvoid(value)
   				strpro = "闪避值"
   			end
   			--GFunc_ShowGameDialogMessage({msg=string.format("玩家 %s 提升了 %s",strpro, strvalue)})
   			GFunc_ShowSMessage(string.format("玩家 %s 提升了 %s",strpro, strvalue))
   		elseif info.item then
    	    --添加新的物品
     	    PlayerInfos:addItems(info.item, 1)
     	    --GFunc_ShowGameDialogMessage({msg=string.format("[%s] 的研究完成啦\n 获得了 [%s]x1",info.name, ItemList_Static[info.item].name),
     	    --	func = function()
     	    --		--教程
     	    --	end})
     	    GFunc_ShowSMessage(string.format("[%s] 的研究完成啦,获得了 [%s]x1",info.name, ItemList_Static[info.item].name))
      	elseif info.role then
     	    --角色道具只增加角色经验
     	    local roleInfos = PlayerInfos:getAidPlayers()[info.role]
     	    if roleInfos then
     	    	--增加经验值,根本研究的次数获得增加值
     	    	local sumyj = 1
     	    	if myiteminfo then
     	    		sumyj = myiteminfo.sumyj
     	    	end

     	    	--研究道具获得经验:(等级+总研究数量)*50
     	    	local sumexp = (roleInfos.lv + sumyj) * 50
     	    	roleInfos:addExps(sumexp)
     	    end
        end
    end

    ---///研究完成任务
    GameEvent_JugeTaskFinshEnd(GTaskType_Yanjiu, itemID)
end

-----//////建造完成事件
function GameEvent_BuildEnd(bid)
	-- body
	GameEvent_JugeTaskFinshEnd(GTaskType_Build, bid)

	GFuncTutorialTempFunc()
end

-----//////建造完成事件
function GameEvent_AddShopEnd(bid)
	-- body
	GameEvent_JugeTaskFinshEnd(GTaskType_AddShop, bid)
end

function GameEvent_NewYear(iyear, init)
end
function GameEvent_NewMonth(imonth, init)
    ---每月自动保存
 	if not init then
  		Config_AutoSaveGameData()
  	end
end
function GameEvent_NewWeek(iweek, init)
	--每周结算一次建筑收益
	if not init then
		--所有建筑收获
    	for k, cbuild in pairs(PlayerInfos:getAllBuildInfos()) do
   			cbuild:onGain()
  		end
  	end
end


-------------
--待执行游戏事件列表
GGameEvent_UnlockRole	= 0x01 --解锁角色
GTableEventTables = {}
function GameEvent_AddGameEvent(eid, type, param)
	-- body
	table.insert(GTableEventTables, {eid=eid, type=type, param=param})
end

--游戏事件执行
local onRunGameEventStory = false

function GEvtGTableEventTables()
	return GTableEventTables
end
function GEvtHasonRunGameEventStory()
	return onRunGameEventStory
end

function GameEvent_RunGameEvent()
	--
	--print(onRunGameEventStory, #GTableEventTables)
	if not onRunGameEventStory and #GTableEventTables > 0 then
		local info = GTableEventTables[1]
		table.remove(GTableEventTables,1)
		onRunGameEventStory = true
		GGamePause = true

		---关闭界面
		CloseInterfaceTask()

		local eid = info.eid
		---显示解锁的角色信息
		local _args = {}
		if info.type == GGameEvent_UnlockRole then
			local _showRinfo = GFuncShowGmaeRoleInfos({info=PlayerInfos:getAidPlayers()[info.param], lindex=16, nobg=true})
			_args["info"] = _showRinfo
			_showRinfo.parent:setPosition(ccp(_showRinfo.parentX, _showRinfo.parentY + 100))
		end

		local function gameeventEnd()
			onRunGameEventStory = false
			GGamePause = false
			if info.type == GGameEvent_UnlockRole then
				GFunc_RemoveChild(_args.info.layer)
			end
		end
		
		---事件执行
		local _UIinfo = GGameRunEventStory({func=gameeventEnd, eid = eid, width=600, height=200})
		_UIinfo.parent:setPosition(ccp(_UIinfo.parentX, _UIinfo.parentY + 200))
	end

end
----角色解锁
function GameEvent_GameEventUnlockRole(aid, func)
	local rinfo = RoleInfos_Static[aid]
	local eid = rinfo.event
	---显示解锁的角色信息
	local _args = {}
	local _showRinfo = GFuncShowGmaeRoleInfos({info=PlayerInfos:getAidPlayers()[aid], lindex=16, nobg=true})
	_args["info"] = _showRinfo
	_showRinfo.parent:setPosition(ccp(_showRinfo.parentX, _showRinfo.parentY + 100))

	GGamePause = true
	local function gameeventEnd()
		GFunc_RemoveChild(_args.info.layer)
		GGamePause = false
		if func then
			func()
		end
	end
		
	---事件执行
	local _UIinfo = GGameRunEventStory({func=gameeventEnd, eid = eid, width=600, height=200})
	_UIinfo.parent:setPosition(ccp(_UIinfo.parentX, _UIinfo.parentY + 200))
end


----新的任务事件
GTableEventTaskTables = {}
function GameTaskOpenEvent_AddTaskd(tid)
	table.insert(GTableEventTaskTables, tid)
end
local mOpenTaskOpenEvent = false
function GameTaskOpenEvent_Update(dt)
	if GGameShowInterface == GGameInterface_City and not GGamePause and not GGameFuncHasInterfaceShow() then
		for k, tid in pairs(GTableEventTaskTables) do
			local evtlist = {}
	        for _k=1, table.maxn(StoryTaskOpen_Static) do
	        	local _info = StoryTaskOpen_Static[_k]
	        	if _info and _info.tid == tid then
	        		table.insert(evtlist, _info)
	        	end
	        end

	        GGamePause = true
	        mOpenTaskOpenEvent = true
	        local storyui = GGameRunEventStory({evtlist = evtlist, func=function()
	        	mOpenTaskOpenEvent = false
	        	GGamePause = false
	        end, width=560, height=200})
	        if storyui then
	        	storyui.parent:setPosition(ccp(storyui.parentX,storyui.parentY+400))
	        end

	        table.remove(GTableEventTaskTables, k)
	        break
		end
	end
end