local Gems_Rows = 7
local Gems_Cols = 6
local brick_bpx = 50
local brick_bpy = 50
local brick_width = 80
local brick_height = 80
--获得砖块坐标
local function getGemPos(r,c)
    return (c-1)*brick_width+brick_bpx + brick_width/2, (r-1)*brick_height+brick_bpy + brick_height/2
end
--获得拾取的位置
local function getGridXForPos(x,y)
    if x < brick_bpx or x > brick_bpx + brick_width * Gems_Cols then
        return 1
    end
    local v = math.floor((x - brick_bpx) / brick_width) + 1
    return v + 0
end
local function getGridYForPos(x,y)
    if y < brick_height or y > brick_bpy + brick_height * Gems_Rows then
        return 1
    end
    local v = math.floor((y - brick_bpy) / brick_height) + 1
    return v + 0
end
local function getGridForPos(x,y)
    return getGridYForPos(x,y),getGridXForPos(x,y)
end
--获取KEY值
local function getGridKey(r,c)
    return r*Gems_Cols + c
end
local function getGridKeyForPos(x,y)
    local r,c = getGridForPos(x,y)
    return getGridKey(r,c)
end
--通过KEY获取坐标
local function getGridForKey(key)
    local c = (key-1) % Gems_Cols + 1
    local r = math.floor((key-1) / Gems_Cols)
    
    return r,c
end
--是否在拾取范围内
local function HasPickArce(x,y)
    if x < brick_bpx or x > brick_bpx + brick_width * Gems_Cols then
        return false
    end
    if y < brick_bpy or y > brick_bpy + brick_height * Gems_Rows then
        return false
    end
    return true
end
--获取已经走出的左右边缘位置
local function GetArceLeftRight(x)
    local dleft = brick_bpx + brick_width /2
    local dright = brick_bpx + brick_width * Gems_Cols - brick_width /2
    if x < dleft then
        return dleft
    end
    if x > dright then
        return dright
    end
    return x
end
local function GetArceUpDown(y)
    local dup = brick_bpy + brick_height / 2
    local ddown = brick_bpy + brick_height * Gems_Rows - brick_height / 2
    if y < dup then
        return dup
    end
    if y > ddown then
        return ddown
    end
    
    return y
end

local _keyindex = 0
local function GetKeyIndex()
    _keyindex = _keyindex + 1
    return _keyindex
end


------------砖块类
local _GemTypesbatchNode = nil

PuzGemClass = {}
PuzGemClass.__index = PuzGemClass
---
function PuzGemClass:new(r, c, t)
    local self = {}   
    setmetatable(self, PuzGemClass)
    local brick = CCSprite:createWithSpriteFrameName(string.format("fangk_00%d.png",t))
    brick:setAnchorPoint(ccp(0.5, 0.5))
    brick:setPosition(ccp(getGemPos(r, c)))
    
    local id = GetKeyIndex()
    local key = getGridKey(r,c)
    _GemTypesbatchNode:addChild(brick, 0, id)
    
    self.id = id
    self.key = key
    self.row = r --行数
    self.col = c --列数
    self.types = t
    self.img = brick
    
    return self
end

function PuzGemClass:setPosition(x,y)
    self.img:setPosition(ccp(x,y))
end

function PuzGemClass:getPosition()
    return self.img:getPosition()
end

function PuzGemClass:onMove(pos, func)
    local lx, ly = self:getPosition()

    if pos == nil then
        pos = ccp(getGemPos(self.row, self.col))
    end
    local function runends()
        --更新key
        self.key = getGridKey(self.row, self.col)

        ---移动停止效果
        self.img:setAnchorPoint(ccp(0.5,0))
        self.img:setPosition(ccp(pos.x, pos.y - self.img:getContentSize().height/2))
        self.img:runAction(CCSequence:createWithTwoActions(CCScaleTo:create(0.1, 0.6), CCCallFunc:create(function()
            self.img:runAction(CCSequence:createWithTwoActions(CCScaleTo:create(0.1, 1.0), CCCallFunc:create(function()
                self.img:setAnchorPoint(ccp(0.5,0.5))
                self.img:setPosition(pos)
                if func then
                    func()
                end
            end)))
        end)))
    end
    
    if self["act_move"] == nil then
        self.act_move = nil
    else
        self.img:stopAction(self.act_move)
    end
    
    local lenght = math.abs(ccpLength(ccp(self.img:getPosition())) - ccpLength(pos))
    local x,y = self.img:getPosition()
    local mtt = lenght / 1000.0
    --local mtt = mtt + mtt % 0.1 * 5
    self.act_move = CCSequence:createWithTwoActions(CCMoveTo:create(mtt, pos), CCCallFunc:create(runends))
    

    self.img:runAction(self.act_move)

    return mtt
end

function PuzGemClass:delete()
    _GemTypesbatchNode:removeChild(self.img, true)
end


function GGamePuzClearAllBrick()
    
end


--////////////////////////////////////////////////
--参数{row = 行数, col = 列数, width=方块宽, height=方块高, beginX=显示偏移X, beginY =显示偏移Y, types = 砖块列表({类型A,类型B……})
--回调参数{FuncEndRounds=一回合全部消除结束,FuncEndRoundPart=完成一回消除,FuncBeginPuz=开始消除砖块}
-- 菜单显示层
function createLayerForPuzGame(args)
    local layer = GFunc_CreateLayerEnterOrExit()
    
    ---------------
    _keyindex = 0
    ---------------
    local setGemGrid = nil
    local funcSwapGrids = nil
    local onPuzFilling = nil
    local onPuzGems = nil

    ---操作标识-操作消除过程中无法再操作
    local onOpertion = false
    --限制操作
    local function setOpertion(value)
        onOpertion = value
    end
    args["setOpertion"] = setOpertion
    
    ---设置配置
    if args then
        Gems_Rows = 7
        Gems_Cols = 6
        brick_bpx = 50
        brick_bpy = 50
        brick_width = 80
        brick_height = 80
        if args.row then
            Gems_Rows = args.row
        end
        if args.col then
            Gems_Cols = args.col
        end
        if args.beginX then
            brick_bpx = args.beginX
        end
        if args.beginY then
            brick_bpy = args.beginY
        end
        if args.width then
            brick_width = args.width
        end
        if args.height then
            brick_height = args.height
        end
    end
    
    ---生成砖块
    local puzclass = PuzClass:new(Gems_Rows, Gems_Cols, args.types)
    
    _GemTypesbatchNode = CCSpriteBatchNode:create(Png_BrickPng, Gems_Rows * Gems_Cols)
    layer:addChild(_GemTypesbatchNode,2)
    
    ----------------------------------主数据
    local tableGrids = {}
    local tableGridIDs = {}
    local function func_updategridGem(cgem)
        cgem.key = getGridKey(cgem.row, cgem.col)
        tableGrids[cgem.key] = cgem

        puzclass:setGemType(cgem.row, cgem.col, cgem.types)
        --空砖块不需要
        if cgem.id then
            tableGridIDs[cgem.id] = cgem
        end
    end

    local function func_newgem(r,c,t)
        local cgem = PuzGemClass:new(r,c,t)
        func_updategridGem(cgem)
    end
    ----------------------------------主数据

    puzclass:setCallback_CGemFunc(func_newgem)
    ---首次战斗/教程任务
    local tutorial = false
    if not hasfinshTutorial(TStep6) then
        tutorial = true
    end
    -------------教程用砖块生成
    if tutorial then
        GGameTutorialInitPuzBrick(puzclass)
    else
        puzclass:init(func_newgem)
    end

    --结束一个回合
    local _typeLists = {}
    local roundPartSums = 0
    local function endRounds()
        if args.FuncEndRounds then
            args:FuncEndRounds({list=_typeLists, sum=roundPartSums})
        end
        roundPartSums = 0
        _typeLists = {}
    end
    --结束一个小回合
    local function endRoundPart()
        if args.FuncEndRoundPart then
            args:FuncEndRoundPart({list=_typeLists, sum=roundPartSums})
        end

        roundPartSums = roundPartSums + 1
        onPuzFilling()
    end
    --消除一个砖块统计
    local function mFuncAddPuzGems(_rdata)
        --类型
        local gemtables = puzclass:getTables()
        local _type = gemtables[getGridKey(_rdata[1].row, _rdata[1].col)]
        --数量
        local _sum = #_rdata
        --中心位置
        local _px, _py = 0,0
        for _k, _info in pairs(_rdata) do
            local cgem = tableGrids[getGridKey(_info.row, _info.col)]
            local _getx, _gety = cgem:getPosition()
            _px = _getx + _px
            _py = _gety + _py
            --print(_info.row, _info.col)
        end
        local _px = _px / _sum
        local _py = _py / _sum

        local _puzinfo = {sum=_sum, x=_px, y=_py, type=_type}
        table.insert(_typeLists, _puzinfo)

        if args.FuncBeginPuz then
            local _rargs = {list=_typeLists, sum=roundPartSums, info=_puzinfo}
            --print("_______")
            args:FuncBeginPuz(_rargs)
        end
    end


    --复次消除/全部移动结束后
    local function funcPuzLast(allmovebrick)
        --未移动则不计算
        if #allmovebrick == 0 then
            return
        end

        if args.FuncBeginOpertion then
            args.FuncBeginOpertion()
        end

        --print("全部移动完毕")

        --是否有需要消除的
        local hasPuzs = false
        local psum = 0
        --每次清除都会调用一次
        local function puzEnds()
            psum = psum + 1
            if psum == #allmovebrick then
                --print("puz:全部清除完成")
                puzclass:newRound()
                --全部清除完成后排列砖块
                if hasPuzs then
                    endRoundPart()
                else
                    --结束
                    endRounds()
                end
            end
        end

        for k, gem in pairs(allmovebrick) do
            local rdata = puzclass:jugeGemPuzs(gem)
            puzclass:newRound()
            --print("消除判定:",gem.row,gem.col,gem.types, gem.id,#rdata)
            --超过最小消除数量则消除,并且生成新的砖块
            if #rdata >= 3 then
                hasPuzs = true
                mFuncAddPuzGems(rdata)
                onPuzGems(rdata, puzEnds)
            else
                puzEnds()
            end
        end
    end
    
    ----砖块填充((填充后从上往下放置
    onPuzFilling = function ()
        --重建table
        local gemtables = puzclass:getTables()
        
        --所有移动砖块
        local allmovebrick = {}

        --空位开始
        local nultables = {}
        
        for _c = 1, Gems_Cols do
            nultables[_c] = Gems_Rows+1
            for _r = 1, Gems_Rows do
                ---找到空砖块
                if gemtables[getGridKey(_r,_c)] == OreType_Null then
                    nultables[_c] = _r

                    ---从空位开始寻找非空位
                    local _rnull = _r
                    for _rn = _r + 1, Gems_Rows do
                        if gemtables[getGridKey(_rn,_c)] ~= OreType_Null then
                            --找到非空位,交换两个位置的砖块
                            local cgem = tableGrids[getGridKey(_rn,_c)]
                            funcSwapGrids(cgem, {row=_rnull, col=_c, types=OreType_Null})
                            --移动到新位置
                            cgem:onMove()
                            --更新空砖块位置(上移一个位置)
                            _rnull = _rnull + 1
                            --更新空位
                            nultables[_c] = _rnull
                            table.insert(allmovebrick, cgem)
                        end
                    end
                    break
                end
            end
        end
        --最后一个砖块
        local lastbrick = nil
        local movelong = 0
        ----重新填充
        for _c = 1, Gems_Cols do
            local rsum = 0
            for _r = nultables[_c], Gems_Rows do
                --开始生成
                rsum = rsum + 1
                puzclass:newGem(_r, _c)
                local cgem = tableGrids[getGridKey(_r, _c)]
                if cgem then
                    --显示在最上面,
                    cgem:setPosition(getGemPos(rsum + Gems_Rows, _c))
                    --向下移动
                    local mtt = cgem:onMove()

                    table.insert(allmovebrick, cgem)

                    if mtt > movelong then
                        lastbrick = cgem
                        movelong = mtt
                    end
                end
            end
        end

        --puzclass:newRound()

        --最后一个砖块执行判断
        if lastbrick then
            lastbrick:onMove(nil, function()
                funcPuzLast(allmovebrick)
            end)
        end
    end
    
    ----砖块填充((在原来的位置填充
    local function onPuzFillingNoMoved()
        --重建table
        local gemtables = puzclass:getTables()
        
        --
        for _c = 1, Gems_Cols do
            for _r = 1, Gems_Rows do
                if gemtables[getGridKey(_r,_c)] == OreType_Null then
                    --重新新的砖块
                    puzclass:newGem(_r, _c)
                    local cgem = tableGrids[getGridKey(_r, _c)]
                    if cgem then
                        --原地出现
                        cgem.img:runAction(CCFadeIn:create(0.5))
                    end
                end
            end
        end
    end
    
    --消除砖块
    onPuzGems = function(rdata, func)
        local delsum = 0 --删除数
        local function deleteAll(tag)
            --print("__1",delsum,tag:getTag())
            local cgem = tableGridIDs[tag:getTag()]
            cgem:delete()
            puzclass:setGemType(cgem.row, cgem.col, OreType_Null)
            --清除相应ID砖块
            tableGridIDs[cgem.id] = nil
            delsum = delsum + 1
            --print("删除:",cgem.row, cgem.col, cgem.id, delsum, #rdata)
            if delsum == #rdata then
                --重新填充
                --onPuzFilling()
                --print("puz:清除完成")
                if func then
                    func()
                end
            end
        end
        
        for k, info in pairs(rdata) do
            --清空位置
            puzclass:setGemType(info.row, info.col, OreType_Null)
            --移动效果
            local cgem = tableGrids[getGridKey(info.row, info.col)]
            --print("__v",cgem.key,cgem.types, info.row,info.col)
            local action = CCFadeOut:create(0.5)
            action = CCSequence:createWithTwoActions(action, CCCallFuncN:create(deleteAll))
            cgem.img:runAction(action)
        end
    end
    
    setGemGrid = function(cgem, row, col)
        cgem.row = row
        cgem.col = col
        --tableGrids[getGridKey(cgem.row, cgem.col)] = cgem
        func_updategridGem(cgem)
        --if cgem.img then
        --    cgem.img:setTag(cgem.key)
        --end
        
    end
    
    
    ------交换砖块
    funcSwapGrids = function(gem1, gem2)
        local tempR, tempC = gem1.row, gem1.col
        setGemGrid(gem1, gem2.row, gem2.col)
        setGemGrid(gem2, tempR, tempC)
    end
    
    --记录所有交换过的砖块
    local swapTables = {}
    ----拾取
    local pickGem = nil
    local function funcPickGem(pick)
        if pick then
            pickGem = pick
            --显示在最前
            --_GemTypesbatchNode:removeChild(pickGem.img, false)
            --_GemTypesbatchNode:addChild(pickGem.img, 0, pickGem.key)
        end
    end

    --教程限制操作区域
    local function tutorialOpention(x,y,eventType)
        if hasfinshTutorial(TStep6) then
            return true
        end

        --获取领取的点
        local r,c = getGridForPos(x,y)
        --print("____",GTempTutorialPuzOpertion, r, c,x,y)
        if GTempTutorialPuzOpertion == 0x01 then
            local vrlsit = {{1,4}, {1,3},{2,3},{3,3},{4,3},{5,3}}
            if pickGem and eventType == CCTOUCHENDED then
                --print("______",pickGem.row, pickGem.col)
                if vrlsit[#vrlsit][1] == pickGem.row and vrlsit[#vrlsit][2] == pickGem.col then
                    ---完成操作
                    GTempTutorialFight1()
                    return true
                else
                    return false
                end
            end

            if not HasPickArce(x,y) then
                return false
            end

            if pickGem == nil then
                --开始只能拾取位置
                if r == 1 and c == 4 then
                    return true
                end
            else
                --允许拾取点
                local templsit = {}
                table.insert(templsit, {pickGem.row, pickGem.col})
                local index = 1

                for k, v in pairs(vrlsit) do
                    if v[1] == pickGem.row and v[2] == pickGem.col then
                        if k == #vrlsit then
                        else
                            table.insert(templsit, {vrlsit[k+1][1], vrlsit[k+1][2]})
                        end
                    end
                end

                for k, v in pairs(templsit) do
                    --print(r,c,v[1],v[2])
                    if v[1] == r and v[2] == c then
                        return true
                    end
                end
            end
        elseif GTempTutorialPuzOpertion == 0x02 then
            local vrlsit = {{4,5},{3,5}}
            if pickGem and eventType == CCTOUCHENDED then
                --print("______",pickGem.row, pickGem.col)
                if vrlsit[#vrlsit][1] == pickGem.row and vrlsit[#vrlsit][2] == pickGem.col then
                    ---完成操作
                    GTempTutorialFight1()
                    return true
                else
                    return false
                end
            end

            if not HasPickArce(x,y) then
                return false
            end

            if pickGem == nil then
                --开始只能拾取位置
                if r == 4 and c == 5 then
                    return true
                end
            else
                --允许拾取点
                local templsit = {}
                table.insert(templsit, {pickGem.row, pickGem.col})
                local index = 1

                for k, v in pairs(vrlsit) do
                    if v[1] == pickGem.row and v[2] == pickGem.col then
                        if k == #vrlsit then
                            --移动结束
                            --print("结束移动---")
                            lastpos_v = nil
                        else
                            table.insert(templsit, {vrlsit[k+1][1], vrlsit[k+1][2]})
                        end
                    end
                end

                for k, v in pairs(templsit) do
                    --print(r,c,v[1],v[2])
                    if v[1] == r and v[2] == c then
                        return true
                    end
                end
            end
        end

        return false
    end
    
    ---操作layer
    local function touchBegin(x,y,eventType)
        if tutorialOpention(x,y,eventType) == false then
            return
        end

        if onOpertion then
            return
        end
        if HasPickArce(x,y) then
            --判断拾取
            funcPickGem(tableGrids[getGridKeyForPos(x,y)])

            if pickGem then
                args.FuncBeginPickGem()
            end
        end
    end
    local lastPickPos = {x=0,y=0}
    local function touchMoved(x,y,eventType)
        if tutorialOpention(x,y,eventType) == false then
            return
        end

        if onOpertion then
            return
        end
        --已经拾取则移动,未拾取则拾取
        if pickGem or HasPickArce(x,y) then
            lastPickPos.x = x
            lastPickPos.y = y
            local x = GetArceLeftRight(x)
            local y = GetArceUpDown(y)
            if pickGem then
                pickGem:setPosition(x,y)
                --当前拾取的砖块与接触的砖块不是同一砖时,交换
                local moveGrid = tableGrids[getGridKeyForPos(x,y)]
                --print("交换",pickGem.row,pickGem.col,pickGem.key,  moveGrid.row,moveGrid.col, moveGrid.key)
                if pickGem.id ~= moveGrid.id then
                    --交换
                    funcSwapGrids(pickGem, moveGrid)
                    --移动至新位置
                    moveGrid:onMove()

                    swapTables[pickGem.key] = pickGem
                    swapTables[moveGrid.key] = moveGrid
                    --table.insert(swapTables, pickGem)
                    --table.insert(swapTables, moveGrid)
                end
            else
                funcPickGem(tableGrids[getGridKeyForPos(x,y)])

                if pickGem then
                    args.FuncBeginPickGem()
                end
            end
        end
    end
    local function touchEnded(x,y,eventType)
        if tutorialOpention(x,y,eventType) == false then
            return
        end
        
        if onOpertion then
            return
        end
        if pickGem then
            pickGem:onMove()

            local temptable = {}
            for k,v in pairs(swapTables) do
                table.insert(temptable, v)
            end

            funcPuzLast(temptable)
            swapTables = {}
        end
        pickGem = nil

        args.FuncEndPickGem()
    end

    local function onTouch(x, y, eventType)
        if eventType == CCTOUCHBEGAN then
            return touchBegin(x, y, eventType)
        elseif eventType == CCTOUCHMOVED then
            return touchMoved(x, y, eventType)
        elseif eventType == CCTOUCHENDED then
            return touchEnded(x, y, eventType)
        end
    end

    args["FuncPuzPutDown"] = function()
        onTouch(lastPickPos.x, lastPickPos.y, CCTOUCHENDED)
    end

    local _layertest = GFunc_CreateLayerEnterOrExit({touchBegin=touchBegin, touchMoved=touchMoved, touchEnded=touchEnded})
    layer:addChild(_layertest)
    
    GFuncTutorialPuzGameLayer = {onTouch = onTouch, touchBegin=touchBegin, touchMoved=touchMoved, touchEnded=touchEnded}
    
    return layer
end







