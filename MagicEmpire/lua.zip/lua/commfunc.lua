CCTOUCHBEGAN = "began"
CCTOUCHMOVED = "moved"
CCTOUCHENDED = "ended"
CCTOUCHCANCELLED = "cancelled"
CCTOUCHKEYBACK = "backClicked"
CCTOUCHKEYMENU = "menuClicked"

------------创建动画,(图片,起始帧,结束帧,循环次数(默认无限),切换速度(0.1), 动画完成的回调函数)
GFunc_CreateAnimation = function(fturext, bframe, iframe, loop, fps, func, suffix)
    local animation = CCAnimation:create()
    local anim = nil
    local name = nil
    local spname = nil
    for i = bframe, iframe do
        number = i
        
        --自动添加0,,fturext.."_00000"..number
        local fileturext = fturext
        if suffix then
            local zeroSum = suffix - string.len(string.format("%d",number))
            for j=1, zeroSum do
                fileturext = string.format("%s0",fileturext)
            end
        else
            local zeroSum = 5 - string.len(string.format("%d",number))
            fileturext = string.format("%s_",fturext)
            for j=1, zeroSum do
                fileturext = string.format("%s0",fileturext)
            end
        end
        
        
        name = fileturext..number..".png"
        local pFrame = CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName(name);
        if pFrame then
            if not spname then
                spname = name
            end
            animation:addSpriteFrame(pFrame);
        end
    end
    --频率
    if fps == nil then
        fps = 0.1
    end
    if loop == nil then
        loop = 10000
    end
    animation:setDelayPerUnit(fps)
    animation:setRestoreOriginalFrame(true)
    animation:setLoops(loop)--循环次数
    local array = CCArray:create()
    array:addObject(CCAnimate:create(animation))
    local seq = CCSequence:create(array)
    
    local funcAnim = function()
        anim:getParent():removeChild(anim, true)
        if func then
            func()
        end
    end
    
    seq = CCSequence:createWithTwoActions(seq, CCCallFuncN:create(funcAnim))
    
    anim = CCSprite:createWithSpriteFrameName(spname)
    anim:runAction(seq)
    
    return anim
end

-----创建一个按钮(子图,点击缩放1.2
GFunc_CreateButton = function(sfile, _width, _height, index, func)
    local btnSpriteN = CCSprite:create(sfile, CCRectMake(_width*index, 0, _width, _height))
    local btnSpriteS = CCSprite:create(sfile, CCRectMake(_width*index, 0, _width, _height))
    btnSpriteS:setScale(1.2)
    btnSpriteS:setContentSize(CCSizeMake(_width*1.2, _height*1.2))
    local btnItem = CCByzMenuItemSprite:create(btnSpriteN, btnSpriteS)
    if func ~= nil then
        btnItem:registerScriptTapHandler(func)
    end
    
    return btnItem
end

-----创建一个按钮-plist图片
GFUnc_CreateBtnSprite = function(sfile, func, scale, scaleT)
    local btnSpriteN = CCSprite:createWithSpriteFrameName(sfile)
    local btnSpriteS = CCSprite:createWithSpriteFrameName(sfile)
    
    if scale == nil then
        scale = 1.1
    end
    
    btnSpriteS:setScale(scale)
    btnSpriteS:setContentSize(CCSizeMake(btnSpriteN:getContentSize().width * scale, btnSpriteN:getContentSize().height * scale))

    return btnSpriteN, btnSpriteS
end

GFunc_ChangeBtnSprite = function( ... )
    local btnItem, sfile, func, scale, scaleT = ...
    btnSpriteN, btnSpriteS = GFUnc_CreateBtnSprite(sfile, func, scale, scaleT)
    btnItem:setNormalImage(btnSpriteN)
    btnItem:setSelectedImage(btnSpriteS)
end


GFunc_CreateButtonP = function(sfile, func, scale, scaleT)
    local btnSpriteN = CCSprite:createWithSpriteFrameName(sfile)
    local btnSpriteS = CCSprite:createWithSpriteFrameName(sfile)
    
    if scale == nil then
        scale = 1.1
    end
    
    btnSpriteS:setScale(scale)
    btnSpriteS:setContentSize(CCSizeMake(btnSpriteN:getContentSize().width * scale, btnSpriteN:getContentSize().height * scale))
    local btnItem = CCByzMenuItemSprite:create(btnSpriteN, btnSpriteS)
    if func ~= nil then
        btnItem:registerScriptTapHandler(func)
    end
    
    --可触摸区域大小
    if scaleT then
        btnItem:setContentSize(CCSizeMake(btnSpriteN:getContentSize().width * scaleT, btnSpriteN:getContentSize().height * scaleT))
    end
    
    return btnItem
end

GFunc_CreateButtonDP = function(sfile, func, scale, scaleT)
    local btnItem = GFunc_CreateButtonP(sfile, func, scale, scaleT)
    local btnSpriteD = CCSprite:createWithSpriteFrameName(sfile)
    btnSpriteD:setColor(ccc3(170, 96, 59))
    btnItem:setDisabledImage(btnSpriteD)
    btnItem:setContentSize(btnItem:getContentSize())
    
    return btnItem
end

GFunc_CreateButtonDPOther = function(sfile, dfile, func, scale, scaleT)
    local btnItem = GFunc_CreateButtonP(sfile, func, scale, scaleT)
    local btnSpriteD = CCSprite:createWithSpriteFrameName(dfile)
    btnItem:setDisabledImage(btnSpriteD)
    btnItem:setContentSize(btnItem:getContentSize())
    return btnItem
end


---创建一个按钮-文字
GFunc_CreateButtonLabelMenu = function(text, func, fsize, tag, tuSize)
    if fsize == nil then
        fsize = FontSize
    end
    local menu = CCMenu:create()
    local btnItem = CCMenuItemLabel:create(CCLabelTTF:create(text, "Arial", fsize))
    if func ~= nil then
        btnItem:registerScriptTapHandler(func)
    end
    if tag == nil then
        tag = -1
    end
    
    if tuSize ~= nil then
        btnItem:setAnchorPoint(ccp(0.5, 0.5))
        btnItem:setContentSize(tuSize)
    end
    
    menu:addChild(btnItem,0,tag)
    menu:setPosition(ccp(0,0))
    return menu
end

GFunc_CreateButtonLabel = function(text, func, fsize, toSize)
    if fsize == nil then
        fsize = FontSize
    end
    local btnItem = CCMenuItemLabel:create(CCLabelTTF:create(text, "Arial", fsize))
    if func ~= nil then
        btnItem:registerScriptTapHandler(func)
    end
    if tag == nil then
        tag = -1
    end
    
    if toSize ~= nil then
        btnItem:setAnchorPoint(ccp(0.5, 0.5))
        btnItem:setContentSize(toSize)
    end
    
    return btnItem
end



-----移动型虚线
GameDashedDynamic = {}
--这句是重定义元表的索引，必须要有，
GameDashedDynamic.__index = GameDashedDynamic
--文件,间隔,起始点,结束点
function GameDashedDynamic:new(sfile, inv, pfrom, pto)
    local self = {}
    setmetatable(self, GameDashedDynamic)

    self.inv = inv
    self.sfile = sfile
    self.progress = 0

    self._parent = GFunc_CreateLayerEnterOrExit({update=function(dt) self:update(dt) end})
    self._parent:setPosition(pfrom)
    --获得长度
    local vpos = ccp(pfrom.x - pto.x, pfrom.y-pto.y)
    self.lenght = ccpLength(vpos)

    self.bgsp = CCSprite:create(sfile, CCRect(0,0,7,self.lenght))
    self.bgsp:setPosition(ccp(0, 0))
    self.bgsp:setAnchorPoint(ccp(0.5,0))

    local angle2 = GFunc_Angle360(pfrom, ccp(pfrom.x, pfrom.y + 100), pto)/(math.pi/180)
    self.bgsp:setRotation(angle2)

    self._parent:addChild(self.bgsp)

    self.maxlenght = 635

    return self
end
function GameDashedDynamic:setPosition(pos)
    -- body
    self._parnet:setPosition(pos)
end
function GameDashedDynamic:update(dt)
    self.progress = self.progress + dt * 50
    if self.progress + self.lenght >= self.maxlenght then
        self.progress = 0
    end
    -- body
    self.bgsp:setTextureRect(CCRect(0,self.progress,7,self.lenght))
end




----------自定义容器类,平均排列所有子集
GameContainer = {}
--这句是重定义元表的索引，必须要有，
GameContainer.__index = GameContainer
--模拟构造体，一般名称为new()大小,
function GameContainer:new(w, h)
    local self = {}   
    setmetatable(self, GameContainer)
    
    self._width = w
    self._height = h
    self._parnet = CCNode:create()
    --self._parnet:setAnchorPoint(ccp(0.0, 0.5))
    --self._parnet:setContentSize(CCSizeMake(w,h))
    self._childs = {}
    
    return self
end

function GameContainer:addToLayer(layer, rlevel)
    layer:addChild(self._parnet)
end

function GameContainer:addChild(child)
    table.insert(self._childs, child)
    self._parnet:addChild(child)
    
    self:Refresh()
end

function GameContainer:Refresh()
    local x,y = self._parnet:getPosition()
    --根据容器大小,平均分布子元素
    local interval = self._width / #self._childs
    
    table.foreach(self._childs, function(k,v)
        v:setPosition(ccp(x + (k-1) * interval + interval/2, y))
    end)
end

function GameContainer:setPosition(pos)
    self._parnet:setPosition(pos)
end



----------自定义容器类,平均排列所有子集,可滑动
SildeContainer_LeftRight    = 0x01  --左右
SildeContainer_UpDown   = 0x02  --上下
SildeContainer_All  = 0x03 --全范围

GameSildeContainer = {}
--这句是重定义元表的索引，必须要有，
GameSildeContainer.__index = GameSildeContainer
--模拟构造体，一般名称为new()大小,
function GameSildeContainer:new(w,h,type)
    local self = {}
    setmetatable(self, GameSildeContainer)
    
    self._width = w and w or 0
    self._height = h and h or 0
    self._parent = CCLayer:create()
    self._childs = {}
    
    self._nodeParent = CCNode:create()
    self._parent:addChild(self._nodeParent)
    
    self._type = type
    if self._type == nil then
        self._type = SildeContainer_LeftRight
    end
    
    
    self.lastx, self.lasty = 0,0
    self.pickx, self.picky = 0,0
    
    return self
end

function GameSildeContainer:setSize(w,h)
    self._width = math.max(w and w or self._width,0)
    self._height = math.max(h and h or self._height,0)
end

function GameSildeContainer:setType(_v)
    self._type = _v
    
    self:Refresh()
end

function GameSildeContainer:onTouch(x,y,type)
    if type == CCTOUCHBEGAN then
        return self:onTouchBegin(x, y, type)
    elseif type == CCTOUCHMOVED then
        return self:onTouchMoved(x, y, type)
    elseif type == CCTOUCHENDED then
        return self:onTouchEnded(x, y, type)
    end
end

function GameSildeContainer:onTouchBegin(x, y)
    self.lastx, self.lasty = x,y
    self.pickx, self.picky = x,y
    return 1
end
    
function GameSildeContainer:onTouchMoved(x, y)
    local mx,my = self._nodeParent:getPosition()
    if self._type == SildeContainer_LeftRight then
        mx = mx + (x - self.lastx)
        if mx < -self._width then
            mx = -self._width
        elseif mx > 0 then
            mx = 0
        end
    elseif self._type == SildeContainer_UpDown then
        my = my + (y - self.lasty)
        if my < 0 then
            my = 0
        elseif my > self._height then
            my = self._height
        end
    elseif self._type == SildeContainer_All then
        mx = mx + (x - self.lastx)
        if mx < -self._width then
            mx = -self._width
        elseif mx > 0 then
            mx = 0
        end
        my = my + (y - self.lasty)
        if my < 0 then
            my = 0
        elseif my > self._height then
            my = self._height
        end
    end
    self._nodeParent:setPosition(ccp(mx, my))
    self.lastx, self.lasty = x,y
end

function GameSildeContainer:setViewPosition(pos)
    self._nodeParent:setPosition(pos)
end

function GameSildeContainer:getViewPostion()
    local x,y = self._nodeParent:getPosition()
    return x,y
end
    
function GameSildeContainer:onTouchEnded(x, y)
    
end

function GameSildeContainer:addToLayer(layer, rlevel)
    layer:addChild(self._parent)
end

function GameSildeContainer:addElementChild(child)
    table.insert(self._childs, child)
    self._nodeParent:addChild(child)
    
    --self:Refresh()
end
function GameSildeContainer:addChild(child)
    self:addElementChild(child)
end
function GameSildeContainer:removeChild(child)
    self._nodeParent:removeChild(child, true)
end

function GameSildeContainer:Refresh()
    local x,y = self._nodeParent:getPosition()
    
    if self._type == SildeContainer_LeftRight then
        --根据容器大小,平均分布子元素
        local interval = self._width / #self._childs
        
        table.foreach(self._childs, function(k,v)
            v:setPosition(ccp(x + (k-1) * interval + interval/2, y))
        end)
    elseif self._type == SildeContainer_UpDown then
        --根据容器大小,平均分布子元素
        local interval = self._height / #self._childs
        
        table.foreach(self._childs, function(k,v)
            v:setPosition(ccp(x, y - (k-1) * interval + interval/2))
        end)
    end
end

function GameSildeContainer:getPosition()
    local lx, ly = self._parent:getPosition()
    local mx, my = self._nodeParent:getPosition()
    return lx+mx, ly+my
end





---------------可前后翻页的layer窗口
GameContainerPage = {}
--这句是重定义元表的索引，必须要有，
GameContainerPage.__index = GameContainerPage
--模拟构造体，一般名称为new()大小,
function GameContainerPage:new(w, h)
    local self = {}   
    setmetatable(self, GameContainerPage)
    
    self._width = w
    self._height = h
    
    self._childs = {}
    -----
    
    self._parnet = CCLayer:create()
    
    self._showIndex = 0
    
    --上次操作时间(操作间隔
    local _lastTimes = os.clock()
    local _mousex, _mousey = 0 ,0
    local _beginpx = 0
    local function onTouchBegin(x, y)
        _mousex, _mousey = x, y
        _beginpx = x
        
        return 1
    end
    
    local function onTouchMoved(x, y)
    end
    
    local function onTouchEnded(x, y)
        if _lastTimes + 0.31 > os.clock() then
            return
        end
        _lastTimes = os.clock()
        
        -- 切换显示的列表
        local badd = nil
        if x > _beginpx + 20 then
            badd = false
        elseif x < _beginpx - 20 then
            badd = true
        end
        if badd ~= nil then
            self:Show_Layer(badd)
        end
    end
    
    -- 触摸操作
    local function onTouch(eventType, x, y)
        if eventType == CCTOUCHBEGAN then
            return onTouchBegin(x, y)
        elseif eventType == CCTOUCHMOVED then
            return onTouchMoved(x, y)
        elseif eventType == CCTOUCHENDED then
            return onTouchEnded(x, y)
        end
    end
    
    self._parnet:setTouchEnabled(true)
    self._parnet:registerScriptTouchHandler(onTouch)
    
    return self
end

function GameContainerPage:addToLayer(layer, rlevel)
    layer:addChild(self._parnet)
end

function GameContainerPage:addChild(child)
    table.insert(self._childs, child)
    self._parnet:addChild(child)
    
    ---初始化位置
    self:Show_Layer(nil, true)
end

function GameContainerPage:setPosition(pos)
    self._parnet:setPosition(pos)
end

function GameContainerPage:getPageSum()
    return #self._childs
end

function GameContainerPage:getPage()
    return self._showIndex
end

function GameContainerPage:setNextPageFunc(_func)
    self["_func_page"] = _func
end

function GameContainerPage:showPage(page)
    -- body
    if page > self._showIndex then
        self._showIndex = page-1
        self:Show_Layer(true)
    else
        self._showIndex = page+1
        self:Show_Layer(false)
    end
end

function GameContainerPage:Show_Layer(badd, binit)
    if badd == true then
        self._showIndex = self._showIndex + 1
    elseif badd == false then
        self._showIndex = self._showIndex - 1
    end
    
    if self._showIndex >= #self._childs then
        self._showIndex = #self._childs - self._showIndex
    elseif self._showIndex < 0 then
        self._showIndex = #self._childs + self._showIndex
    end

    --翻页结束
    local lastcallback = false
    local function funcpageend()
        if not lastcallback and self._func_page then
            self._func_page(self._showIndex)
            lastcallback = true
        end
    end
    
    table.foreach(self._childs, function(k,ly)
        local midx = k - 1 - self._showIndex
        
        local imd = math.floor(#self._childs / 2)
        if midx < -imd then
            midx = #self._childs + midx
        elseif midx > imd then
            midx = -(#self._childs - midx)
        end
        
        if not binit and ((badd and (midx == -1 or midx == 0)) or (not badd and (midx == 0 or midx == 1))) then
            --ly:runAction(CCMoveTo:create(0.3, ccp(midx * self._width, 0)))
            ly:runAction(CCSequence:createWithTwoActions(CCMoveTo:create(0.3, ccp(midx * self._width, 0)), CCCallFunc:create(funcpageend)))
            ly:setVisible(true)
        else
            ly:setPosition(ccp(midx * self._width, 0))
            ly:setVisible(false)
            
            if binit and midx == 0 then
                ly:setVisible(true)
            end
        end
    end)
end


-------------进度条控件
EProgressType_LeftRight = 0x01
EProgressType_RightLeft = 0x02

GameProgressCrols = {}
--这句是重定义元表的索引，必须要有，
GameProgressCrols.__index = GameProgressCrols
--模拟构造体，一般名称为new()大小,
function GameProgressCrols:new(sbg, sicon, type)
    local self = {}   
    setmetatable(self, GameProgressCrols)

    self._allprogress = 0
    self._progress = 0

    self.type = nil

    self._parent = CCNode:create()

    self._bgsp = nil
    if sbg then
        self._bgsp = CCSprite:createWithSpriteFrameName(sbg)
        self._parent:addChild(self._bgsp)
    end
    
    self._progress_sp = CCSprite:createWithSpriteFrameName(sicon)
    self._prosp = CCProgressTimer:create(self._progress_sp)
    self._parent:addChild(self._prosp)
    self._prosp:setPercentage(50)

    self:setType(type)

    return self
end

function GameProgressCrols:setScale(value)
    -- body
    self._parent:setScale(value)
end

function GameProgressCrols:setVisible(value)
    -- body
    self._parent:setVisible(value)
end

function GameProgressCrols:getContentSize()
    -- body
    local width = self._parent:getScale() * self._bgsp:getContentSize().width
    local height = self._parent:getScale() * self._bgsp:getContentSize().height
    return {width=width, height=height}
end

function GameProgressCrols:setAnchorPoint(pos)
    self._bgsp:setPosition(ccp(-self._bgsp:getContentSize().width*pos.x, self._bgsp:getContentSize().height*pos.y))
    self._prosp:setPosition(ccp(-self._prosp:getContentSize().width*pos.x, self._prosp:getContentSize().height*pos.y))
end

function GameProgressCrols:runAction(action)
    --self._bgsp:runAction(action:copy())
    --self._prosp:runAction(action())
end

function GameProgressCrols:setAllProgress(value)
    self._allprogress = value * 1.0
    self:update(0)
end

function GameProgressCrols:addToParent(parent, idx)
    if idx == nil then
        idx = 0
    end
    parent:addChild(self._parent, idx)
end

function GameProgressCrols:setPosition(pos)
    self._parent:setPosition(pos)
end
function GameProgressCrols:getPosition()
    return self._parent:getPosition()
end

function GameProgressCrols:setType(type)
    self.type = type
    if self.type == nil then
        self.type = EProgressType_LeftRight
    end

    if self.type == EProgressType_LeftRight then
        if self._bgsp then
            self._bgsp:setAnchorPoint(ccp(0, 0.5))
        end

        self._prosp:setType(kCCProgressTimerTypeBar)
        self._prosp:setAnchorPoint(ccp(0, 0.5))
        self._prosp:setMidpoint(CCPointMake(0, 0))
        self._prosp:setBarChangeRate(CCPointMake(1, 0))
    end
end

function GameProgressCrols:update(iprogress, anim)
    self._progress = (iprogress/self._allprogress) * 100

    if self._prosp:getPercentage() == 100 then
        self._prosp:setPercentage(99.9)
    end

    ---动画效果,anim = true
    local animtt = 0
    if anim then
        animtt = 0.2
    end
    local action = CCProgressTo:create(animtt, self._progress)
    self._prosp:runAction(CCSequence:createWithTwoActions(action,CCCallFunc:create(function() 
        self._prosp:setPercentage(self._progress) 
    end)))
end

-----------遮罩层
function GFunc_CreateLayerVisit(layer, showW, showH, x, y)
    local layerVisit = CCLayerVisit:create()
    layerVisit:setContentSize(CCSizeMake(showW,  showH))
    layerVisit:setPosition(ccp(x, y))
    layerVisit:setAnchorPoint(ccp(0, 0))
    layer:addChild(layerVisit)
    local _nodeParentLayerVisit = CCNode:create()
    _nodeParentLayerVisit:setPosition(x,-y)
    layerVisit:addChild(_nodeParentLayerVisit)

    return _nodeParentLayerVisit
end

--------- Layer创建 创建一个layer,响应刷新/进入/离开/触摸/触摸移动/触摸离开/事件
--local func_updateLayer = function(dt) end
--local func_enterLayer = function() end
--local func_exitLayer = function() end
--local func_touchBegin = function(x,y) end
--local func_touchMoved = function(x,y) end
--local func_touchEnded = function(x,y) end
--fps=1.0/60.0
--fmbg = false
--color=nil
--layer = GFunc_CreateLayerEnterOrExit(color,
--    func_updateLayer,func_enterLayer,func_exitLayer,func_touchBegin,func_touchMoved,func_touchEnded,
--    fps,fmbg)
GFunc_CreateLayerEnterOrExit = function(args)
    if args == nil then
        args = {}
    end
    local color, upfunc, enfunc, exfunc, tbfunc, tmfunc, tefunc, fps, fmbg, lindex = args.color, args.update, 
    args.enfunc, args.exfunc, args.touchBegin, args.touchMoved, args.touchEnded, args.fps, args.fmbg, args.lindex
    
    if color == nil then
        color = ccc4(0,0,0,0)
    end
    
    local layer = CCLayerColor:create(color)
    
    if fps == nil then
        fps = 1.0/60.0
    end
    
    if fmbg ~= nil and fmbg == true then
        -- 背景//遮挡按钮用
        local _Menubg = CCMenu:create()
        -- 主菜单大小
        _Menubg:setContentSize(CCSizeMake(DWinSize.width,  DWinSize.height))
        -- 设置坐标
        _Menubg:setPosition(0, 0)
        layer:addChild(_Menubg)
        
        local function menucallback()
            if tbfunc ~= nil then
                tbfunc()
            end
        end

        local btnItem = nil
        btnItem = CCMenuItemLabel:create(CCLabelTTF:create("", "Arial", GFGetFont(FontSize)))
        btnItem:setPosition(ccp(DWinSize.width/2, DWinSize.height/2))
        btnItem:setContentSize(CCSizeMake(DWinSize.width,  DWinSize.height))
        btnItem:registerScriptTapHandler(menucallback)
        _Menubg:addChild(btnItem)
        layer["menu"] = _Menubg
    end
    
    --更新事件回调
    local function update(dt)
        if upfunc ~= nil then
            upfunc(dt)
        end
    end
    
    ---进入退出界面
    local _baseLayer_entry = nil
    local function SpriteEase_onEnterOrExit(tag)
        if tag == "enter" then
            if enfunc then
                enfunc()
            end
            if upfunc then
                _baseLayer_entry = CCDirector:sharedDirector():getScheduler():scheduleScriptFunc(update, fps,false)
            end
        elseif tag == "exit" then
            if _baseLayer_entry ~= nil then
                CCDirector:sharedDirector():getScheduler():unscheduleScriptEntry(_baseLayer_entry)
            end
            _baseLayer_entry = nil
            if exfunc then
                exfunc()
            end
        end
    end
    -- 注册进入/退出事件
    layer:registerScriptHandler(SpriteEase_onEnterOrExit)
    
    -------------触摸事件
    local function onTouchBegin(x, y)
        if tbfunc ~= nil then
            tbfunc(x,y,CCTOUCHBEGAN)
        end
        
        if tmfunc ~= nil then
            return 1
        else
            return 0
        end
    end
    
    local function onTouchMoved(x, y)
        if tmfunc ~= nil then
            tmfunc(x,y,CCTOUCHMOVED)
        end
    end
    
    local function onTouchEnded(x, y)
        if tefunc ~= nil then
            tefunc(x, y,CCTOUCHENDED)
        end
    end
    
    -- 触摸操作
    local function onTouch(eventType, x, y)
        if eventType == CCTOUCHBEGAN then
            return onTouchBegin(x, y)
        elseif eventType == CCTOUCHMOVED then
            return onTouchMoved(x, y)
        elseif eventType == CCTOUCHENDED then
            return onTouchEnded(x, y)
        end
    end
    
    if tmfunc ~= nil or tbfunc ~= nil or tefunc ~= nil then
        layer:setTouchEnabled(true)

        if lindex == nil then
            lindex = -129
        else
            lindex = -129-lindex
        end
        if fmbg and tmfunc and tbfunc then
            layer:registerScriptTouchHandler(onTouch, false, lindex, true)
        else
            layer:registerScriptTouchHandler(onTouch)
        end
    end
    
    return layer
end



------------ 像短信提示一样,显示一条信息,从上方进入屏幕,再离开屏幕
--信息列表
local SMessageTable = {}
local SMShow = false
local SMLayer = nil
local SMTxtMsg = nil
local SMReturn = false

GFunc_ClearSMessage = function()
    if SMLayer then
        GFunc_RemoveChild(SMLayer)
    end
    SMessageTable = {}
    SMShow = false
    SMReturn = false
end

GFunc_ShowSMessage = function(msg)
    if msg ~= nil then
        table.insert(SMessageTable, msg)
    end
    local msgSize = 30
    local showX = 0
    local showY = DWinSize.height
    local showToY = showY-(msgSize+10)

    local function exfunc()
        SMLayer = nil
    end
    --print("msg", msg)
    if SMLayer == nil then
        SMLayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,100), exfunc = exfunc})
        SMLayer:setPosition(ccp(showX, showY))
        
        SMTxtMsg = CCLabelTTF:create(SMessageTable[1], "Arial", msgSize)
        SMTxtMsg:setPosition(ccp(DWinSize.width/2, msgSize/2+5))
        SMLayer:addChild(SMTxtMsg)
        
        GameGetRunScene():addChild(SMLayer,15)
    end
    
    if SMReturn and SMessageTable[1] then
        SMTxtMsg:setString(SMessageTable[1])
    end
    
    local func_nextMsg = function()
        -- 如果还有下一条信息,则显示下一条信息
        table.remove(SMessageTable, 1)
        if #SMessageTable > 0 then
            --渐隐,切换文字,再显示
            SMTxtMsg:runAction(CCSequence:createWithTwoActions(CCFadeTo:create(0.5, 10), CCCallFunc:create(function()
                SMTxtMsg:setString(SMessageTable[1])
                SMTxtMsg:runAction(CCSequence:createWithTwoActions(CCFadeTo:create(0.5, 255), CCCallFunc:create(function()
                    GFunc_ShowSMessage()
                    SMReturn = false
                end)))
            end)))
            
        else
            local action = CCMoveTo:create(0.5, ccp(showX, showY))
            local sqe = CCSequence:createWithTwoActions(action, CCCallFunc:create(function()
                --GFunc_ClearSMessage()
            end))
            SMLayer:runAction(sqe)
        end
        SMReturn = true
    end
    if not SMShow or SMReturn then
        SMLayer:stopAllActions()
        
        local x, y = SMLayer:getPosition()
        
        local array = CCArray:create()
        array:addObject(CCMoveTo:create((y - showToY) * 0.0125, ccp(showX, showToY)))
        array:addObject(CCMoveTo:create(3, ccp(showX, showToY)))
        local sqe = CCSequence:create(array)
        SMLayer:runAction(CCSequence:createWithTwoActions(sqe, CCCallFunc:create(func_nextMsg)))
    end
    
    SMShow = true
end
