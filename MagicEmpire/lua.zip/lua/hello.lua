-- for CCLuaEngine traceback
function __G__TRACKBACK__(msg)
    print("----------------------------------------")
    print("LUA ERROR: " .. tostring(msg) .. "\n")
    print(debug.traceback())
    print("----------------------------------------")
end

dofile "lua/commfunc.lua"
dofile "lua/gamefunc.lua"
dofile "lua/gameSound.lua"
dofile "lua/gameNumber.lua"
dofile "lua/gameConfig.lua"
dofile "lua/gStory.lua"
dofile "lua/gEvent.lua"

dofile "lua/PuzClass.lua"
dofile "lua/AStarNavigation.lua"

dofile "lua/global.lua"
dofile "lua/gameres.lua"
dofile "lua/loadres.lua"
dofile "lua/helper.lua"

dofile "lua/d_area.lua"
dofile "lua/d_areainfo.lua"
dofile "lua/d_areamap.lua"
dofile "lua/d_build.lua"
dofile "lua/d_buildinfo.lua"
dofile "lua/d_item.lua"
dofile "lua/d_mapinfo.lua"
dofile "lua/d_monster.lua"
dofile "lua/d_place.lua"
dofile "lua/d_rolep.lua"
dofile "lua/d_fightlv.lua"
dofile "lua/d_rolegrop.lua"
dofile "lua/d_task.lua"
dofile "lua/d_player.lua"
dofile "lua/d_skill.lua"
dofile "lua/d_story.lua"
dofile "lua/d_storyfight.lua"
dofile "lua/d_storyopen.lua"

dofile "lua/zgamedatas.lua"
dofile "lua/zgametutorial.lua"

dofile "lua/uiFight.lua"
dofile "lua/uiFightResult.lua"
dofile "lua/uiMain.lua"
dofile "lua/ui_menu.lua"
dofile "lua/uiMenu.lua"
dofile "lua/uiYanjiu.lua"
dofile "lua/uiBuild.lua"
dofile "lua/uiCity.lua"
dofile "lua/uiFightReady.lua"
dofile "lua/uiPuzGame.lua"
dofile "lua/uisBuild.lua"
dofile "lua/uiMonster.lua"
dofile "lua/uiDialog.lua"
dofile "lua/uiPlayer.lua"
dofile "lua/uiSkill.lua"
dofile "lua/uiShop.lua"
dofile "lua/uiPasser.lua"

dofile "lua/gameUpdate.lua"

local function main()
    -- avoid memory leak
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)
    ---------------
    createLoading()
    
    --注册全局回调
    registerDidEnterBackGroundHandler(GameDidEnterBackGround)
    registerWillEnterBackGroundHandler(GameWillEnterBackGround)
    registerJavaHandler(GameJavaHandler)
end

xpcall(main, __G__TRACKBACK__)

