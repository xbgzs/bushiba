-- for CCLuaEngine traceback
function __G__TRACKBACK__(msg)
    print("----------------------------------------")
    print("LUA ERROR: " .. tostring(msg) .. "\n")
    print(debug.traceback())
    print("----------------------------------------")
end

local function dofilegame(file)
    local strPath = CCFileUtils:sharedFileUtils():fullPathForFilename(file)
    require(strPath)
end

dofilegame("lua/commfunc.lua")
dofilegame("lua/gamefunc.lua")
dofilegame("lua/gameSound.lua")
dofilegame("lua/gameNumber.lua")
dofilegame("lua/gameConfig.lua")
dofilegame("lua/gStory.lua")
dofilegame("lua/gEvent.lua")

dofilegame("lua/PuzClass.lua")
dofilegame("lua/AStarNavigation.lua")

dofilegame("lua/global.lua")
dofilegame("lua/gameres.lua")
dofilegame("lua/loadres.lua")
dofilegame("lua/helper.lua")

dofilegame("lua/d_area.lua")
dofilegame("lua/d_areainfo.lua")
dofilegame("lua/d_areamap.lua")
dofilegame("lua/d_build.lua")
dofilegame("lua/d_buildinfo.lua")
dofilegame("lua/d_item.lua")
dofilegame("lua/d_mapinfo.lua")
dofilegame("lua/d_monster.lua")
dofilegame("lua/d_place.lua")
dofilegame("lua/d_rolep.lua")
dofilegame("lua/d_fightlv.lua")
dofilegame("lua/d_rolegrop.lua")
dofilegame("lua/d_task.lua")
dofilegame("lua/d_player.lua")
dofilegame("lua/d_skill.lua")
dofilegame("lua/d_story.lua")
dofilegame("lua/d_storyfight.lua")
dofilegame("lua/d_storyopen.lua")

dofilegame("lua/zgamedatas.lua")
dofilegame("lua/zgametutorial.lua")

dofilegame("lua/uiFight.lua")
dofilegame("lua/uiFightResult.lua")
dofilegame("lua/uiMain.lua")
dofilegame("lua/ui_menu.lua")
dofilegame("lua/uiMenu.lua")
dofilegame("lua/uiYanjiu.lua")
dofilegame("lua/uiBuild.lua")
dofilegame("lua/uiCity.lua")
dofilegame("lua/uiFightReady.lua")
dofilegame("lua/uiPuzGame.lua")
dofilegame("lua/uisBuild.lua")
dofilegame("lua/uiMonster.lua")
dofilegame("lua/uiDialog.lua")
dofilegame("lua/uiPlayer.lua")
dofilegame("lua/uiSkill.lua")
dofilegame("lua/uiShop.lua")
dofilegame("lua/uiPasser.lua")

dofilegame("lua/gameUpdate.lua")

local function main()
    -- avoid memory leak
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)
    ---------------
    createLoading()
    
    --注册全局回调
    registerDidEnterBackGroundHandler(GameDidEnterBackGround)
    registerWillEnterBackGroundHandler(GameWillEnterBackGround)
    registerJavaHandler(GameJavaHandler)
end

xpcall(main, __G__TRACKBACK__)

