-- for CCLuaEngine traceback
function __G__TRACKBACK__(msg)
    print("----------------------------------------")
    print("LUA ERROR: " .. tostring(msg) .. "\n")
    print(debug.traceback())
    print("----------------------------------------")
end

local function main()
    -- avoid memory leak
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)
    ---------------
    require "lua/commfunc"
    require "lua/gamefunc"
    require "lua/gameSound"
    require "lua/gameNumber"
    require "lua/gameConfig"
    require "lua/gStory"
    require "lua/gEvent"

    require "lua/PuzClass"
    require "lua/AStarNavigation"

    require "lua/global"
    require "lua/gameres"
    require "lua/loadres"
    require "lua/helper"

    require "lua/d_area"
    require "lua/d_areainfo"
    require "lua/d_areamap"
    require "lua/d_build"
    require "lua/d_buildinfo"
    require "lua/d_item"
    require "lua/d_mapinfo"
    require "lua/d_monster"
    require "lua/d_place"
    require "lua/d_rolep"
    require "lua/d_fightlv"
    require "lua/d_rolegrop"
    require "lua/d_task"
    require "lua/d_player"
    require "lua/d_skill"
    require "lua/d_story"
    require "lua/d_storyfight"
    require "lua/d_storyopen"

    require "lua/zgamedatas"
    require "lua/zgametutorial"

    require "lua/uiFight"
    require "lua/uiFightResult"
    require "lua/uiMain"
    require "lua/ui_menu"
    require "lua/uiMenu"
    require "lua/uiYanjiu"
    require "lua/uiBuild"
    require "lua/uiCity"
    require "lua/uiFightReady"
    require "lua/uiPuzGame"
    require "lua/uisBuild"
    require "lua/uiMonster"
    require "lua/uiDialog"
    require "lua/uiPlayer"
    require "lua/uiSkill"
    require "lua/uiShop"
    require "lua/uiPasser"

    require "lua/gameUpdate"

    createLoading()
    
    --注册全局回调
    registerDidEnterBackGroundHandler(GameDidEnterBackGround)
    registerWillEnterBackGroundHandler(GameWillEnterBackGround)
    registerJavaHandler(GameJavaHandler)
end

xpcall(main, __G__TRACKBACK__)

