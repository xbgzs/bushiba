
-- create menu
local function initWithLayer()
    --------把数据表中的资源添加至
    --数字
    for k,info in pairs(NumberTables) do
        table.insert(ResourcesTalbes, {rtype=Res_Png, d1=GetNumberFile(k), d2=nil,})
    end
    
    
    
    -----加载LOGO
    --CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("res/load.plist", "res/load.pvr")
    --------背景
    local spbg = CCSprite:create("res/logo_bg.png")
    spbg:setAnchorPoint(ccp(0, 0))
    layer:addChild(spbg)
    --
    --local spbgC = CCSprite:createWithSpriteFrameName("uit_click2.png")
    --spbgC:setPosition(ccp(480, 100))
    --layer:addChild(spbgC)
    --local arr1 = CCArray:create()
    --arr1:addObject(CCFadeTo:create(1.0, 100))
    --arr1:addObject(CCFadeTo:create(1.0, 255))
    --local seq1 = CCSequence:create(arr1)
    --spbgC:runAction(CCRepeatForever:create(seq1))
    --spbgC:setVisible(false)
    
    -- 加载资源
    local _lb_loading = CCLabelTTF:create(table.concat({"游戏正在加载中……"}), "Arial", GFGetFont(FontSizeBig))
    _lb_loading:setPosition(ccp(DWinSize.width/2, 100))
    layer:addChild(_lb_loading)
    
    ---------------------------
    local _loadingEnd = false
    local _loadingSums = #ResourcesTalbes --加载总数
    local _loadingFine = 0 --完成数量
    local _onGameRun = nil
    local _joinGame = false
    local _baseLayer_entry = nil
    
    local function loading_next()
        if _loadingFine >= #ResourcesTalbes then
            ----------------加载完成
            _lb_loading:setString("加载完成!\n点击屏幕开始游戏...")
            --
            --local spbgC = CCSprite:createWithSpriteFrameName("uit_click2.png")
            --spbgC:setAnchorPoint(ccp(480, 100))
            --layer:addChild(spbgC)
            --
            local arr1 = CCArray:create()
            arr1:addObject(CCFadeTo:create(1.0, 0))
            arr1:addObject(CCFadeTo:create(1.0, 255))
            local seq1 = CCSequence:create(arr1)
            
            _lb_loading:runAction(CCRepeatForever:create(seq1))
            
            --_lb_loading:setString("")
            --spbgC:setVisible(true)
            --显示总使用内存
            print(CCTextureCache:sharedTextureCache():dumpCachedTextureInfo())
            
            _loadingEnd = true
            return
        end
        _loadingFine = _loadingFine + 1
        local _nowload = ResourcesTalbes[_loadingFine]
        if _nowload.rtype == Res_Plist then
            CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile(_nowload.d1, _nowload.d2)
        elseif _nowload.rtype == Res_Png then
            CCTextureCache:sharedTextureCache():addImage(_nowload.d1)
        elseif _nowload.rtype == Res_Bgm then
            --SimpleAudioEngine:sharedEngine():preloadBackgroundMusic(string.format("%s%s",sFilePath_Sound, _nowload.d1))
            SimpleAudioEngine:sharedEngine():preloadBackgroundMusic(GetFiles(_nowload.d1))
            --print(_nowload.d1)
        elseif _nowload.rtype == Res_Effs then
            --SimpleAudioEngine:sharedEngine():preloadEffect(string.format("%s%s",sFilePath_Sound, _nowload.d1))
            SimpleAudioEngine:sharedEngine():preloadEffect(GetFiles(_nowload.d1))
            --print(_nowload.d1)
        end
        
        _lb_loading:setString(table.concat({"游戏正在加载中…… ",string.format("%.0f", (_loadingFine/_loadingSums)*100),"%"}))
    end
    
    local _frame = 0
    local function update()
        --print(_frame)
        -- 每次加载一个资源
        if _loadingEnd then
            return
        end
        
        if _frame == 0 then
            -- 加载音效音乐
            Init_GameSound()
        end
        
        loading_next()
        _frame = _frame + 1
    end
    
    ---暂停游戏
    local function _onGameRun()
        if not _gameRun then
            _baseLayer_entry = CCDirector:sharedDirector():getScheduler():scheduleScriptFunc(update,1.0/60.0,false)
        else
            if _baseLayer_entry ~= nil then
                CCDirector:sharedDirector():getScheduler():unscheduleScriptEntry(_baseLayer_entry)
            end
            _baseLayer_entry = nil
        end
    end
    
    local function SpriteEase_onEnterOrExit(tag,tag2)
        if not _joinGame then
            _joinGame = true
            _onGameRun()
        else
            _joinGame = false
            _onGameRun()
        end
    end
    
    
    -- 触摸回调响应
    local isbeging = false
    local function onTouch(eventType, x, y)
        if _loadingEnd and not isbeging then
            isbeging = true
            --createLayerMainMenu()
            createSceneMain()
        end
    end
    
    -- 接受触摸
    layer:setTouchEnabled(true)
    -- 触摸回调
    layer:registerScriptTouchHandler(onTouch)
    layer:registerScriptHandler(SpriteEase_onEnterOrExit)
end

function createLoading()
    scene = CCScene:create()
    layer = CCLayer:create()

    initWithLayer()
    
    scene:addChild(layer)

    GameReplaceScne(scene, UI_Load)
end














