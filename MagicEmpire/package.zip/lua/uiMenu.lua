------
--主城菜单类
------

local GGameShowMenu = false

function createLayerCityMenu(endfunc)
    local layer = nil

    if GGameShowMenu then
        return
    end

    local function closefunc()
        CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
        if endfunc then
            endfunc()
        end
    end
    
    ------------
    local touchBegin = function(x,y)
    end
    local touchMoved = function(x,y)
    end
    local touchEnded = function(x,y)
    end

    local function exitlayer()
        GGameShowMenu = false
    end
    GGameShowMenu = true
    ----------
    layer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,100),exfunc=exitlayer,touchBegin=touchBegin, touchMoved=touchMoved, touchEnded=touchEnded})
    ------------
    CCDirector:sharedDirector():getRunningScene():addChild(layer)
    local _parent = CCNode:create()
    layer:addChild(_parent)
    
    --地图背景
    local spbg = CCScale9Sprite:createWithSpriteFrameName("jiemian_106.png", CCRectMake(397, 105, 0, 30))
    spbg:setContentSize(CCSizeMake(397, 468))
    local uiWidth,uiHeight = spbg:getContentSize().width, spbg:getContentSize().height
    spbg:setPosition(ccp(uiWidth/2, uiHeight/2))
    _parent:addChild(spbg)
    
    local menu = CCMenu:create()
    menu:setPosition(ccp(0,0))
    _parent:addChild(menu)
    
    local bx = uiWidth/2
    local by = uiHeight-125
    local inv = 80
    
    --jiemian_079
    local paiyix = 44
    --继续
    local btnItem = GFunc_CreateButtonP("jiemian_079.png", function()
        closefunc()
    end,1.05, 1.3)
    btnItem:setPosition(ccp(bx, by))
    menu:addChild(btnItem)
    local spbgp = CCSprite:createWithSpriteFrameName("jiemian_014.png")
    spbgp:setPosition(ccp(btnItem:getNormalImage():getContentSize().width/2 + paiyix, btnItem:getNormalImage():getContentSize().height))
    btnItem:addChild(spbgp)

    --保存
    local btnItem = GFunc_CreateButtonP("jiemian_079.png", function()
        PlayerInfos:saveGameData()
        createSceneMain()
    end,1.05, 1.3)
    btnItem:setPosition(ccp(bx, by-1*inv))
    menu:addChild(btnItem)
    local spbgp = CCSprite:createWithSpriteFrameName("jiemian_013.png")
    spbgp:setPosition(ccp(btnItem:getNormalImage():getContentSize().width/2 + paiyix, btnItem:getNormalImage():getContentSize().height))
    btnItem:addChild(spbgp)

    --设置
    local btnItem = GFunc_CreateButtonP("jiemian_079.png", function()
        layer:setTouchEnabled(false)
        createLayerSetingMenu(function()
            layer:setTouchEnabled(true)
        end)
    end,1.05, 1.3)
    btnItem:setPosition(ccp(bx, by-2*inv))
    menu:addChild(btnItem)
    local spbgp = CCSprite:createWithSpriteFrameName("jiemian_012.png")
    spbgp:setPosition(ccp(btnItem:getNormalImage():getContentSize().width/2 + paiyix, btnItem:getNormalImage():getContentSize().height))
    btnItem:addChild(spbgp)

    --返回
    local btnItem = GFunc_CreateButtonP("jiemian_079.png", function()
        createSceneMain()
    end,1.05, 1.3)
    btnItem:setPosition(ccp(bx, by-3*inv))
    menu:addChild(btnItem)
    local spbgp = CCSprite:createWithSpriteFrameName("jiemian_011.png")
    spbgp:setPosition(ccp(btnItem:getNormalImage():getContentSize().width/2 + paiyix, btnItem:getNormalImage():getContentSize().height))
    btnItem:addChild(spbgp)
    
    
    --界面显示位置
    _parent:setPosition(ccp(DWinSize.width/2 - uiWidth/2, DWinSize.height/2 - uiHeight/2))
end


---------设置菜单界面
function createLayerSetingMenu(endfunc)
    local layer = nil
    local parentX, parentY = 0,0
    
    local function closefunc()
        CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
        if endfunc then
            endfunc()
        end
    end

    local btnTables = {}
    
    ------------
    local touchBegin = function(x, y, eventType)
        GFunc_SelectBtnRun(btnTables, x - parentX, y - parentY, eventType)
    end
    local touchMoved = function(x, y, eventType)
        GFunc_SelectBtnRun(btnTables, x - parentX, y - parentY, eventType)
    end
    local touchEnded = function(x, y, eventType)
        GFunc_SelectBtnRun(btnTables, x - parentX, y - parentY, eventType)
    end
    
    ----------
    layer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,100),touchBegin=touchBegin, touchMoved=touchMoved, touchEnded=touchEnded,fmbg=true})
    ------------
    CCDirector:sharedDirector():getRunningScene():addChild(layer,5)
    local _parent = CCNode:create()
    layer:addChild(_parent)
    
    --地图背景
    local spbg = CCScale9Sprite:createWithSpriteFrameName("jiemian_106.png", CCRectMake(397, 105, 0, 30))
    spbg:setContentSize(CCSizeMake(397, 468))
    local uiWidth,uiHeight = spbg:getContentSize().width, spbg:getContentSize().height
    spbg:setPosition(ccp(uiWidth/2, uiHeight/2))
    _parent:addChild(spbg)
    
    local menu = CCMenu:create()
    menu:setPosition(ccp(0,0))
    _parent:addChild(menu,1)


    local bpx = uiWidth/2
    local bpy = 300

    local bgssp = CCSprite:createWithSpriteFrameName("jiemian_107.png")
    bgssp:setPosition(ccp(bpx,bpy))
    _parent:addChild(bgssp)
    --声音
    local txtsound = CCSprite:createWithSpriteFrameName("jiemian_097.png")
    txtsound:setPosition(ccp(bpx-65, bpy))
    _parent:addChild(txtsound)

    local btnSoundItem = nil
    ---根据当前的声音情况显示不同的声音按钮
    local function changeSound(init)
        if init ~= true then
            Change_BgmStatus()
        end
        local sbtn = "jiemian_087.png"
        if btnSoundItem then
            menu:removeChild(btnSoundItem, true)
        end
        if Get_MusicStatus() == false then
            sbtn = "jiemian_088.png"
        end
        btnSoundItem = GFunc_CreateButtonP(sbtn, changeSound)
        btnSoundItem:setPosition(ccp(bpx+65, bpy))
        btnTables[1]=btnSoundItem
        menu:addChild(btnSoundItem)
    end
    changeSound(true)


    --关闭
    local btnItem = GFunc_CreateButtonP("jiemian_105.png", function()
        closefunc()
    end, nil, 2)
    btnItem:setPosition(ccp(uiWidth-10, uiHeight-30))
    menu:addChild(btnItem)
    btnTables[2]=btnItem
    
    --界面显示位置
    parentX, parentY = DWinSize.width/2 - uiWidth/2, DWinSize.height/2 - uiHeight/2
    _parent:setPosition(ccp(parentX, parentY))
end




