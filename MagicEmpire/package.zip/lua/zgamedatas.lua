-----zgamedatas.lua
--防内存修改
memoryMoney = 123
memoryCrystal = 321
memoryMagic = 213
--初始
local InitGameMoney = 3000
local InitGameMagic = 100

--------------游戏存档,玩家列表
GamePlayers = {}
GamePlayers.__index = GamePlayers
---
function GamePlayers:new(rdataindex)
    local self = {}   
    setmetatable(self, GamePlayers)
    
    --新游戏标识
    self.onNewGame = false
    --存档位
    self.rdataindex = rdataindex

    --游戏数据
    self.gametime = 0 --游戏用时
    self.citytime = 0 --游戏虚拟时间
    self.citytimeformat = {0,0,0} --时间格式化(年,月,日)
    self:formatGameTime()

    self.mapID = 1 --所在地区=GMoveMapStatus 为移动中
    self.mapPos = {0,0} --所有坐标 
    self.mapGoto = 0 --移动中,前往的地图ID
    self.movespeed = 100 --移动速度
    --已经开启的地图列表
    self.areaOpenlist = {}
    self.areaOpenlist[1] = 1 --默认开启地区

    --所有地图数据初始化
    self.AreaInfos = {}
    for k, info in pairs(MapArea_Static) do
        local infos = {}
        for _k, _v in pairs(info) do
            infos[_k] = _v
        end
        infos["agree"] = 0 --文明点
        infos["lv"] = 1 --文明等级
        self.AreaInfos[k] = infos
    end

    --上次收获时间
    self.lastGainTime = 0

    ----角色相关
    self.money = -memoryMoney --金币
    self.magic = -memoryMagic --魔法点
    self.crystal = -memoryCrystal --水晶

    self:addMoney(InitGameMoney)
    self:addMagic(InitGameMagic)
    --当前等级
    self.lv = 1
    self.hp = 1000  --生命
    self.hpmax = self.hp
    self.exp = 0    --经验
    self.def = 0    --防御
    self.avoid = 0  --闪避
    self.expup = 0

    self.fightlost = 0 --战斗失败数统计

    --所有拥有的道具列表
    self.itemlists = {}
    --当前通过的所有平叛点
    self.finshPlaces = {}
    --当前完成任务列表
    self.finshTasks = {} --当前完成任务列表
    self.nofinshTasks = {}  --未完成任务列表
    self.acceptTasks = {}  --已接受任务列表
    self.finshTempTasks = {} --已完成任务的临时列表
    --已解锁建筑列表
    self.openbuilds = {}
    --默认解锁
    for k,info in pairs(BuildList_Static) do
        if info.open == nil then
            self.openbuilds[k] = 1
        else
            self.openbuilds[k] = 0
        end
    end

    --已完成研究
    self.finshyanjius = {}
    --当前辅助角色表
    self.AidRoles = {}
    self.useAidRole = {}


    --所有建筑信息列表
    self.myBuildInfos = {}
    --初始化信息中保留城堡,在位置1上
    for k ,info in pairs(MapInfos_Static) do
        if info.build then --初始建筑
            self.myBuildInfos[k] = info
        end
    end

    self:updatePorperty()

    --self:unlockAidPlayer(1,true)
    --self:unlockAidPlayer(4,true)
    --self:unlockAidPlayer(7,true)

    return self
end
function GamePlayers:addExps(value)
    if self.lv == GPlayerMaxLevel then
        return
    end
    self.exp = self.exp + value
    local isup = false
    --print(self.exp,self.expup,self.lv)
    if self.exp >= self.expup and self.lv < GPlayerMaxLevel then
        isup = true
        self.lv = self.lv + 1
        self:updatePorperty()
    end
    --返回是否升级
    return isup
end
function GamePlayers:updatePorperty()
    -- body
    if self.lv > GPlayerMaxLevel then
        self.lv = GPlayerMaxLevel
    end

    local proInfo = PlayerLvExps_Static[self.lv]
    self.expup = proInfo.exp or 0
    self.hp = proInfo.hp or 0
    self.hpmax = self.hp or 0
    self.def = proInfo.def or 0
    self.avoid = proInfo.avoid or 0

    ---附加数值
    --研究
    for iID,_vinfo in pairs(self.itemlists) do
        local info = ItemList_Static[iID]
        if info and info.type == ItemType_Property and _vinfo.sumyj > 0 then
            --print(info.item, _vinfo.sumyj, info.money)
            --用了多少次,就增加多少
            local value = (info.money or 0) * _vinfo.sumyj
            if info.item == PlayerProperty_Hp then
                PlayerInfos:addProHp(value)
            elseif info.item == PlayerProperty_Def then
                PlayerInfos:addProDef(value)
            elseif info. item == PlayerProperty_Avoid then
                PlayerInfos:addProAvoid(value)
            end
        end
    end

    --self.def = 5
    --self.avoid = 50
    --print("防御",self.hpmax,self.def,self.avoid)
end
function GamePlayers:addProHp(value)
    -- body
    self.hpmax = self.hpmax + value
end
function GamePlayers:addProDef(value)
    -- body
    self.def = self.def + value
end
function GamePlayers:addProAvoid(value)
    -- body
    self.avoid = self.avoid + value
end

--保存游戏存档
function GamePlayers:saveGameData()
    Config_SaveGameData()
    return sdata
end
function GamePlayers:getGameData()
    --建筑信息表
    local buildlist = self:getAllBuildInfos()
    local sbuildlist = {}
    for k,info in pairs(buildlist) do
        local _info = {
            bid=info.bid,
            mapid=info.mapid,
            lv=info.lv,
            buildtime=info._buildtime,
            buildalltime=info._buildalltime,
            status=info._status,
            fieldTables=info.fieldTables,
            onYanjiu = info.onYanjiu,
            Yanjiutime = info.Yanjiutime,
            YanjiuItemID = info.YanjiuItemID,
            tempagree = info.tempagree,
            tempmagic = info.tempmagic,
            tempmoney = info.tempmoney,
            tempgaintime = info.tempgaintime,
        }
        --print("建筑",_info.bid, _info.mapid)
        table.insert(sbuildlist,_info)
    end
    --辅助角色信息
    local sAidRoles={}
    for k,info in pairs(self.AidRoles) do
        local _info = {
            id=info.id,
            lv=info.lv,
            exp=info.expsum,
        }
        table.insert(sAidRoles,_info)
    end

    --任务相关信息/已开启-未解决任务需要额外保存信息
    local sTasklists = {}
    for k,info in pairs(GFuncGetTableTaskInfos()) do
        --if info.status ~= GTaskStatus_Close then
            local sopenlist = {}
            local _info = {}
            if info.status == GTaskStatus_Close then
                for _k,_f in pairs(info.openlist) do
                    sopenlist[_k] = _f.finsh
                end

                _info = {
                    id = info.id,
                    elaptime = info.elaptime,
                    status = info.status,
                    openfinshlist = sopenlist,
                }
            else
                _info = {
                    id = info.id,
                    elaptime = info.elaptime,
                    status = info.status,
                }
            end
            sTasklists[info.id] = _info
        --end
    end

    --保存平叛点战斗过的次数
    local splaceFight = {}
    for pid,pinfo in pairs(GFuncGetAllPlaces()) do
        --print("save", pinfo.fight_sum, pinfo.fight_flee)
        if pinfo.fight_sum ~= 0 or pinfo.fight_flee ~= 0 then
            local _infos = {}
            _infos["id"] = pid
            _infos["fight_sum"] = pinfo.fight_sum
            _infos["fight_flee"] = pinfo.fight_flee
            table.insert(splaceFight, _infos)
        end
    end

    local sdata = {
        lv=self.lv,
        hp=self.hp,
        hpmax=self.hpmax,
        exp=self.exp,
        crystal = self.crystal,
        money=self.money,
        magic=self.magic,
        gametime = self.gametime,
        citytime=self.citytime,
        mapID=self.mapID,
        lastGainTime=self.lastGainTime,
        fightlost = self.fightlost,

        openbuilds=self.openbuilds,
        finshyanjius=self.finshyanjius,
        tasklists=sTasklists,
        areaInfo=self.AreaInfos,
        placeStatus=self.finshPlaces,
        arealist=self.areaOpenlist,
        mapPos = self.mapPos,
        mapGoto = self.mapGoto,
        mapspeed = self.mapspeed,
        useAidRole=self.useAidRole,
        itemlists=self.itemlists,
        buildlist=sbuildlist,
        AidRoles=sAidRoles,
        placefight=splaceFight,

        newtaskcount= GGameFuncGetTaskCount(),--未查看任务数
    }
    return sdata
end

function GamePlayers:initGameData()
    ---游戏初始化数据
    --print("初始化游戏")
    --初始任务添加
    for k,info in pairs(Tasks_Static) do
        --开启条件
        if info.opentype == nil then
            GFuncAddNewTask(info.id)
        end
    end
end

--加载存档
function GamePlayers:loadGameData()
    local strdata = Config_LoadGameData(self.rdataindex)
    --print(strdata)
    if strdata == nil or strdata == "" then
        ---新游戏
        self.onNewGame = true
        self:updatePorperty()
        return
    end
    local sdata = unserialize(strdata)
    self.lv = sdata.lv or 1
    self.hp = sdata.hp or 1000
    self.exp = sdata.exp or 0
    self.hpmax = sdata.hpmax or 0
    self.money = sdata.money or 0
    self.crystal = sdata.crystal or 0
    self.magic = sdata.magic or 0
    self.gametime = sdata.gametime or 0
    self.citytime = sdata.citytime or 0
    self.mapID = sdata.mapID or 1
    self.lastGainTime= sdata.lastGainTime or 0
    self.fightlost = sdata.fightlost or 0

    self.AreaInfos = sdata.areaInfo or {}
    self.useAidRole = sdata.useAidRole or {}
    self.itemlists = sdata.itemlists or {}

    self.openbuilds = sdata.openbuilds or {}
    self.finshyanjius = sdata.finshyanjius or {}

    self.areaOpenlist = sdata.arealist
    self.mapPos = sdata.mapPos
    self.mapGoto = sdata.mapGoto
    self.mapspeed = sdata.mapspeed

    GGameFuncSetTaskCount(sdata.newtaskcount)

    ---已开启/完成的任务
    local tasklists = sdata.tasklists or {}
    for k, info in pairs(tasklists) do
        if info.status == GTaskStatus_Open then
            GFuncAddNewTask(info.id,true)
        elseif info.status == GTaskStatus_Accept then
            GFuncAcceptTask(info.id,true)
        elseif info.status == GTaskStatus_Finsh then
            GFuncSetTaskFinsh(info.id,true)
        elseif info.status == GTaskStatus_FinshTemp then
            GFuncSetTaskFinshTemp(info.id,true)
        elseif info.status == GTaskStatus_Close and info.openfinshlist then
            for _k,_f in pairs(info.openfinshlist) do
                if GFuncGetTaskForID(info.id).openlist[_k] then
                    GFuncGetTaskForID(info.id).openlist[_k].finsh = _f
                end
            end
        end

        GFuncGetTaskForID(info.id).elaptime = info.elaptime
    end

    local sfinshPlaces = sdata.placeStatus or {}
    for k,v in pairs(sfinshPlaces) do
        GFuncSetPlaceFinsh(k, true)
    end

    local sbuildlist = sdata.buildlist or {}
    local sAidRoles = sdata.AidRoles or {}

    --建筑信息
    --self.myBuildInfos = {}
    --初始化信息中保留城堡,在位置1上
    for k ,info in pairs(sbuildlist) do
        if info.bid then
        local _info = {
            build=info.bid,
            id=info.mapid,
            lv=info.lv,
            buildtime=info.buildtime,
            buildalltime=info.buildalltime,
            status=info.status,
            fieldTables=info.fieldTables,
            onYanjiu = info.onYanjiu,
            Yanjiutime = info.Yanjiutime,
            YanjiuItemID = info.YanjiuItemID,
            tempagree = info.tempagree,
            tempmagic = info.tempmagic,
            tempmoney = info.tempmoney,
            tempgaintime = info.tempgaintime,
        }
        self.myBuildInfos[_info.id] = _info
        --print(_info.id, _info.build)
        end
    end

    --辅助角色信息
    for _k, _info in pairs(sAidRoles) do
        local _rinfo = self:unlockAidPlayer(_info.id, true)
        --local _rinfo = GameAidPlayers:new(_info.id)
        --self.AidRoles[_info.id] = _rinfo
        _rinfo.expsum = _info.exp
        _rinfo.lv = _info.lv
        _rinfo:updatePorperty()
    end

    --平叛点相关信息实例
    local splaceFight = sdata.placefight or {}
    local placeInfos = GFuncGetAllPlaces()
    for _k, _info in pairs(splaceFight) do
        local _pinfo = placeInfos[_info.id]
        _pinfo.fight_sum = _info.fight_sum or 0
        _pinfo.fight_flee = _info.fight_flee or 0
        --print(_info.fight_sum, _info.fight_flee)
    end

    --游戏时间格式化
    self:formatGameTime(nil, true)
    self:updatePorperty()
end
---获取所有建筑列表信息
function GamePlayers:getAllBuildInfos()
    return self.myBuildInfos
end
--受伤
function GamePlayers:onHurt(hurt)
    ---(100-实际伤害的免伤值)/100*伤害
    hurt = ConsertInt((100 - self.def)/100.0 * hurt)
    self.hp = self.hp - hurt
    if self.hp < 0 then
        self.hp = 0
    end

    return hurt
end
---建筑是否已经解锁
function GamePlayers:hasUnlockBuild(bid)
    if self.openbuilds[bid] == nil then
        self.openbuilds[bid] = 0
    end

    if self.openbuilds[bid] == 1 then
        return true
    end
    return false
end
---解锁建筑
function GamePlayers:unlockBuild(bid)
    -- body
    if self.openbuilds[bid] == nil then
        self.openbuilds[bid] = 1
    end
    self.openbuilds[bid] = 1
end
--研究中
function GamePlayers:Yanjiuing(yid)
    -- body
    self.finshyanjius[yid] = 2
end
--研究完成
function GamePlayers:finshYanjiu(yid)
    -- body
    self.finshyanjius[yid] = 3
end
--解锁研究
function GamePlayers:unlockYanjiu(yid)
    -- body
    self.finshyanjius[yid] = 1
    self:addItems(yid)
end
--所有可研究道具
function GamePlayers:getYanJius()
    --物品中类型为 ItemType_Shop 的道具
    local ilist = {}
    for k,v in pairs(self.itemlists) do
        local info = ItemList_Static[k]
        if info and v.sum > 0 and info.type == ItemType_Yanjiu then
            table.insert(ilist, {info=info,sum=v.sum, state=v.state})
        end
    end
    return ilist
end
--所有商品
function GamePlayers:getShops()
    --物品中类型为 ItemType_Shop 的道具
    local ilist = {}
    for k,v in pairs(self.itemlists) do
        local info = ItemList_Static[k]
        if info and v.sum > 0 and info.type == ItemType_Shop then
            table.insert(ilist, {info=info,sum=v.sum, state=v.state})
        end
    end
    return ilist
end
--设置商品的使用状态
function GamePlayers:onSetItemBuyState(iID, value)
    --
    local istate = 0
    if value == true then
        istate = 1
    end
    if self.itemlists[iID] then
        self.itemlists[iID].state = istate
    end
    --print("设置使用状态", iID, istate)
end
--所有农场作物
function GamePlayers:getFarms()
    --物品中类型为 ItemType_Farm 的道具
    local ilist = {}
    for k,v in pairs(self.itemlists) do
        local info = ItemList_Static[k]
        if info and v.sum > 0 and info.type == ItemType_Farm then
            table.insert(ilist, {info=info,sum=v.sum, state=v.state})
        end
    end
    return ilist
end
--所有牧场动物
function GamePlayers:getRanchs()
    --物品中类型为 ItemType_Animal 的道具
    local ilist = {}
    for k,v in pairs(self.itemlists) do
        local info = ItemList_Static[k]
        if info and v.sum > 0 and info.type == ItemType_Animal then
            table.insert(ilist, {info=info,sum=v.sum, state=v.state})
        end
    end
    return ilist
end
--解锁辅助角色
function GamePlayers:unlockAidPlayer(aid, init)
    --已经解锁
    local crole = GameAidPlayers:new(aid)
    crole._news = true
    ---初始化辅助角色
    self.AidRoles[aid] = crole
    --当前使用的角色
    if not init then
        --如果有角色位没有添加角色,则设置默认
        for k=1, GMaxRoleCount do
            if self.useAidRole[k] == nil then
                self.useAidRole[k] = aid
                break
            end
        end
        ---游戏事件:角色解锁
        GameEvent_AddGameEvent(crole.event, GGameEvent_UnlockRole, aid)
    end

    return crole
end
--获取使用辅助角色
function GamePlayers:getMyUseAidPlayer()
    local rinfo = {}
    for k=1,GMaxRoleCount do
        local _id = self.useAidRole[k]
        if self.AidRoles[_id] then
            table.insert(rinfo,self.AidRoles[_id])
        end
    end
    return rinfo
end
--获取所有辅助角色
function GamePlayers:getAidPlayers()
    return self.AidRoles
end
--更新使用角色
function GamePlayers:setUseAidPlayer(idx, rid)
    -- body
    --如果已经有此成员,则取消
    for k,aid in pairs(self.useAidRole) do
        if aid == rid then
            return
        end
    end
    self.useAidRole[idx] = rid
end
--添加水晶
function GamePlayers:addCrystal(value)
    -- body
    if value == nil then
        value = 0
    end
    self.crystal = self.crystal + value
end
--获得水晶
function GamePlayers:getCrystal()
    return self.crystal + memoryCrystal
end
--添加金币
function GamePlayers:addMoney(v)
    if v == nil then
        v = 0
    end
	self.money = self.money + v
end
--获得金币
function GamePlayers:getMoney()
    return self.money + memoryMoney
end
--添加魔法
function GamePlayers:addMagic(v)
    if v == nil then
        v = 0
    end
    self.magic = self.magic + v
end
---失败次数增加
function GamePlayers:addFightlost(v)
    if v == nil then
        v = 1
    end
    self.fightlost = self.fightlost + v
end
--获得金币
function GamePlayers:getMagic()
    return self.magic + memoryMagic
end
--添加道具
function GamePlayers:addItems(iID, num)
    if self.itemlists[iID] == nil then
        --sumyj=研究次数
        self.itemlists[iID] = {state=0,sum=0,sumyj=0}
    end
    if num == nil then
        num = 1
    end
    --print("获得道具", iID, num)

    self.itemlists[iID].sum = self.itemlists[iID].sum + num

    if self.itemlists[iID].sum < 0 then
        self.itemlists[iID].sum = 0
    end
end
--获取所有拥有的道具
function GamePlayers:getItems()
    return self.itemlists
end
--获取指定道具数量
function GamePlayers:getItem(iID)
    local iinfo = self.itemlists[iID]
    local isum = 0
    if iinfo then
        isum = self.itemlists[iID].sum or 0
    end
    return isum
end
--增加地区认同度
function GamePlayers:addAgree(mid, v)
    if mid == GMoveMapStatus then
        return
    end
    if v == nil then
        v = 0
    end
    --增加区域的认同值
    self.AreaInfos[mid].agree = self.AreaInfos[mid].agree + v
    --大于当前认同度等级则升级
    if self.AreaInfos[mid].lv < GAreaArgeeMaxLv and self.AreaInfos[mid].agree >= GFuncGetAreaArgeeLvInfos(mid, self.AreaInfos[mid].lv).agree  then
        self.AreaInfos[mid].lv = self.AreaInfos[mid].lv + 1

        --//----事件
        GameEvent_AgreeLevelUp(mid, self.AreaInfos[mid].lv)
    end
end
--获得地区认同度
function GamePlayers:getAgree(mid)
    return self.AreaInfos[mid].agree
end
--下个等级的认同度
function GamePlayers:getNextAgree(mid)
    local info = GFuncGetAreaArgeeLvInfos(mid, self.AreaInfos[mid].lv)
    return info.agree
end
--游戏时间增长
function GamePlayers:addGameTime(dt)
	self.gametime = self.gametime + dt
end
GGameTutorialStep8 = false
function GamePlayers:formatGameTime(value, init)
    local cctime = value
    if cctime == nil then
        cctime = self.citytime
    end

    --游戏时间
    local _strtime = ConsertInt(cctime)
    --总周
    local iallweek = math.floor(_strtime/GameWeekTimes)
    --总月
    local iallmonth = math.floor(iallweek/4)
    --年
    local iyear = math.floor(iallmonth/12)
    --月
    local imonth = iallmonth%12
    --周
    local iweek = iallweek%4
    if self.citytimeformat[1] ~= iyear then
        --新的一年
        self.citytimeformat[1] = iyear
        GameEvent_NewYear(iyear,init)
    end
    if self.citytimeformat[2] ~= imonth then
        GameEvent_NewMonth(imonth,init)
        
        if not init then
            ---每3个月赠送一次宝石,10个
            if iallmonth % 3 == 0 then
                self:addCrystal(GGameTimeCrystal)
            end
            ---游戏中第三个月开启刮刮卡教程
            if iallmonth == 3 then
                --关闭所有窗口
                GGameTutorialStep8 = true
            end
        end

        --新的一月
        self.citytimeformat[2] = imonth
    end
    if self.citytimeformat[3] ~= iweek then
        --新的一周
        self.citytimeformat[3] = iweek
        GameEvent_NewWeek(iweek,init)
    end


    if GGameTutorialStep8 and GGameShowInterface == GGameInterface_City then
        GGameTutorialStep8 = false
        GGameFuncCloseAllInterface()
        TutorialTaskRun(TStep8)
    end
end
--城市运转时间增长
function GamePlayers:addCityTime(dt)
    if GGameShowInterface ~= GGameInterface_Fight and not GGamePause then
        self:formatGameTime(self.citytime + dt)
        self.citytime = self.citytime + dt

        self:updateMoved(dt)
        self:updateTask(dt)

        ----非暂停,在城市界面中,没有打开的对话框,判定事件
        if GGameDialogIsShow == false then
            --print("事件--")
            GameEvent_RunGameEvent()
        end
    end

    ----------建造在所有时间都会进行
    if not GGamePause then
        ---建筑更新执行
        for k, cbuild in pairs(self:getAllBuildInfos()) do
            cbuild:update(dt)
        end
    end

    ---新游戏，初始化
    if self.onNewGame then
        self.onNewGame = false
        self:initGameData()
    end
end
--获取城市时间
function GamePlayers:getCityTime()
    return self.citytime
end
---判定事件/任务完成相关
function GamePlayers:updateTask(dt)
    if self["_task_juge_frame"] == nil then
        self["_task_juge_frame"] = 0
    end
    self._task_juge_frame = self._task_juge_frame + 1
    if self._task_juge_frame % 60 == 0 then
        ---判定运送任务
        if #self.acceptTasks > 0 then
            ------
            for tid,v in pairs(self.acceptTasks) do
                local info = GFuncGetTaskForID(tid)
                --送货任务需要判定拥有足够的物品
                if self.mapID == info.mid and info.type == GTaskType_Express then
                    GameEvent_JugeTaskFinshEnd(GTaskType_Express, tid)
                end
            end
        end
        ----手动完成任务
        self:showGameTaskFinsh()
    end
end
function GamePlayers:onFinshTask(tid, func)
    local info = GFuncGetTaskForID(tid)
    --print("完成任务确认",tid)
    ---完成任务
    GFuncSetTaskFinsh(tid)
     --获得奖励
    local _ritemID = 0
    local _ritemSum = 0
    if info.ritem then
        local rparaminfos = lua_string_split(info.ritem or "", "+")
        _ritemID = rparaminfos[1]+0
        _ritemSum = rparaminfos[2]+0

        --获得道具
        if _ritemID and _ritemSum > 0 then
            self:addItems(_ritemID, _ritemSum)
        end
    end
    ----获得报酬界面
    GameFuncClockCity()
    GFunc_GameDialogReward({money = info.rmoney or 0, itemid=_ritemID, itemsum=_ritemSum, func=function()
        GameFuncUnclockCity()

        if func then
            func()
        end
    end})
end

--显示任务完成相关
function GamePlayers:showGameTaskFinsh()
    if GGameShowInterface ~= GGameInterface_City then
        return
    end

    if self["_task_message_show"] == nil then
        self["_task_message_show"] = false
    end
    --print("判断任务完成___:", #self.finshTempTasks, self._task_message_show)
    if not GGameFuncHasInterfaceShow() and self._task_message_show == false then
        for _tid,v in pairs(self.finshTempTasks) do
            ---如果没有奖励则直接完成
            local tinfo = GFuncGetTaskForID(_tid)
            if tinfo.rmoney == nil and tinfo.ritem == nil then
                PlayerInfos:onFinshTask(_tid, function() end)
            else
                --弹出任务提示
                self._task_message_show = true
                GameFuncClockCity()

                GShowDialogTaskMessage({tid=_tid, close=true, func=function(_args)
                    if _args.finsh then
                        PlayerInfos:onFinshTask(_tid, function()
                            self._task_message_show = false
                            GameFuncUnclockCity()
                        end)
                    else
                        self._task_message_show = false
                        GameFuncUnclockCity()
                    end
                end})
            end
        end
    end
end
--移动到其它地区
function GamePlayers:updateMoved(dt)
    --移动中
    if self.mapID == GMoveMapStatus then
        --移动速度
        local movelenght = self.movespeed * dt / 1  --每秒移动/x
        --前往位置
        local toPos = {0,0}
        local pos = lua_string_split(MapArea_Static[self.mapGoto].posmap, ",")
        toPos[1] = pos[1]+0
        toPos[2] = pos[2]+0

        --计算新位置
        local mpx = toPos[1] - self.mapPos[1]
        local mpy = toPos[2] - self.mapPos[2]
        local normalize = ccpNormalize(ccp(mpx, mpy))
        
        self.mapPos[1] = self.mapPos[1] + normalize.x * movelenght
        self.mapPos[2] = self.mapPos[2] + normalize.y * movelenght
        local normalizeto = ccpNormalize(ccp(toPos[1] - self.mapPos[1], toPos[2] - self.mapPos[2]))
        --print(normalize.x, normalize.y, normalizeto.x, normalizeto.y)
        if (normalize.x > 0 and normalizeto.x < 0) or (normalize.y > 0 and normalizeto.y < 0) or
            (normalizeto.x > 0 and normalize.x < 0) or (normalizeto.y > 0 and normalize.y < 0) then
            --到达位置
            self:GotoAreaEnd(self.mapGoto)
        end
    end
end
--移动到指定地区
function GamePlayers:moveToArea(mid)
    --获得当前所有地区的坐标点
    if self.mapID ~= GMoveMapStatus then
        local pos = lua_string_split(MapArea_Static[self.mapID].posmap, ",")
        self.mapPos[1] = pos[1]+0
        self.mapPos[2] = pos[2]+0
        --print("移动", mid, self.mapID, self.mapPos[1], self.mapPos[2], pos[1], pos[2])
    end
    self.mapID = GMoveMapStatus
    self.mapGoto = mid
end
--获得当前玩家所有位置
function GamePlayers:getInMapPos()
    --移动中直接获得移动位置
    local _pos = {0,0}
    if self.mapID == GMoveMapStatus then
        _pos = {self.mapPos[1], self.mapPos[2]}
    else
        --否则获得当前地区的位置
        local pos = lua_string_split(MapArea_Static[self.mapID].posmap, ",")
        _pos[1] = pos[1]+0
        _pos[2] = pos[2]+0
    end
    return _pos
end
--到达了一个地区
function GamePlayers:GotoAreaEnd(mid)
    --print("到达地区")
    self.mapID = mid
    ---
    GameEvent_GotoArea(mid)
end
--开启动一个新的地区
function GamePlayers:OpenNewArea(mid)
    self.areaOpenlist[mid] = 1
    --print("开放新的区域", mid)

    GameEvent_OpenArea(mid)
end
--获取所有已经开始的地区
function GamePlayers:getOpenAreas()
    return self.areaOpenlist
end









-----------------------------/////////////
-----------辅助角色信息类
GameAidPlayers = {}
GameAidPlayers.__index = GameAidPlayers
---
function GameAidPlayers:new(id)
    local self = {}   
    setmetatable(self, GameAidPlayers)

    ----信息
    local prinfo = RoleInfos_Static[id]
    for k, v in pairs(prinfo) do
        self[k] = v
    end
    --
    self.id = id

    --ctype 成长类型
    --type 类型
    --rating 评级
    --name 名字
    --namesp 名字图片
    --art 形象图片
    --des 描述
    --skill 技能ID
    --atk
    --atkgrop
    --exp
    --expgrop
    --等级
    self.lv = 1 --等级
    --self.exp = 0 --当前经验
    --self.atk = 0 --攻击力
    --self.expup = 0 --等级经验

    self.expsum = 0

    ---新获得角色标识
    self._news = false

    self:updatePorperty()

    return self
end
--根据等级更新其属性
function GameAidPlayers:updatePorperty()
    if self.lv > GRoleMaxLevel then
        self.lv = GRoleMaxLevel
    end
    local proInfo = GFuncGetRoleInfoGrop(self.id, self.lv)
    self.expup = proInfo.exp or 0
    self.atk = proInfo.atk
    self.crit = proInfo.crit
end
--增加经验
function GameAidPlayers:addExps(exp)
    if self.lv == GRoleMaxLevel then
        return
    end

    self.expsum = self.expsum + exp
    local isup = false

    if self.expsum >= self.expup and self.lv < GRoleMaxLevel then
        isup = true
        self.lv = self.lv + 1
        self:updatePorperty()
    end
    --返回是否升级
    return isup
end
function GFuncGetRoleInfoGrop(rid, _lv)
    local rinfo = RoleInfos_Static[rid]
    local baseatk = rinfo.atk
    local baseexp = rinfo.exp
    local atksum = baseatk
    local expsum = 0
    for lv=1, _lv do
        atksum = rinfo.atk + (atksum-baseatk) + rinfo.atkgrop * (lv-1)

        expsum = expsum + baseexp + rinfo.expgrop * math.pow(lv-1,2)
        --print("lv:"..lv.." atk:"..atksum.." exp:"..expsum)
    end
    --print("属性___:攻击:"..atksum.." 升级经验:"..expsum)

    return {atk=atksum, exp=expsum, crit=0}
end
--local testi = GameAidPlayers:new(3)
--testi.lv = 20
--GFuncGetRoleInfoGrop(testi)



----------------------------加载游戏存档
PlayerInfos = nil
function LoadingGameDatas(index)
    InitGameAllDatas()

	PlayerInfos = GamePlayers:new(index)
    PlayerInfos:loadGameData()

    --教程信息
    loadTutorialInfo()
end
---保存存档



--//////////////////初始化所有地区认同等级相关信息
local TableAreaArgee = {}
local function InitAreaArgee()
    TableAreaArgee = {}
    for k,info in pairs(MapAreaInfo_Static) do
        if TableAreaArgee[info.mid] == nil then
            TableAreaArgee[info.mid] = {}
        end
        TableAreaArgee[info.mid][info.lv] = info
    end
end
function GFuncGetAreaArgeeLvInfos(mid, lv)
    if lv > GAreaArgeeMaxLv then
        lv = GAreaArgeeMaxLv
    end
    return TableAreaArgee[mid][lv]
end

---//////////////初始化所有平叛点信息
local TableAreaPlaceInfos = {}
local TableAreaPlaceInfosForID = {}
--已通过平叛点
local function InitAreaPlaceInfos()
    TableAreaPlaceInfos = {}
    local areaid = 1
    local placeid = 1
    --最大区域10个
    for k=1,10 do
        TableAreaPlaceInfos[k] = {}
        local areaplaceinfos = {}
        local index = 1
        --获取
        for _k, _info in pairs(MapPlace_Static) do

            --保存数据,通过次数
            _info["fight_sum"] = 0
            --脱离战斗时记录层数
            _info["fight_flee"] = 0


            if k == _info.mid and _info.ragree then
                table.insert(areaplaceinfos, _info)
            end

            TableAreaPlaceInfosForID[_info.id] = _info
        end
        --排序
        table.sort(areaplaceinfos, function(a,b) return a.index < b.index end)
        TableAreaPlaceInfos[k] = areaplaceinfos
    end
end
function GFuncGetAllPlaces()
    return TableAreaPlaceInfosForID
end
function GFuncGetAllAreaPlaceStatus()
    return PlayerInfos.finshPlaces
end
--获取地区所有平叛点
function GFuncGetAllPlace(mid)
    return TableAreaPlaceInfos[mid] or {}
end
--获取平叛点通过信息
function GFuncGetPlaceFinsh(pid)
    if PlayerInfos.finshPlaces[pid] then
        return true
    end
    return false
end
function GFuncGetPlaceInfos(pid)
    -- body
    return TableAreaPlaceInfosForID[pid]
end
--通过平叛点
function GFuncSetPlaceFinsh(pid, init)
    PlayerInfos.finshPlaces[pid] = true

    --更新平叛点的战斗次数
    TableAreaPlaceInfosForID[pid].fight_sum = TableAreaPlaceInfosForID[pid].fight_sum + 1

    --print("通过:", pid, init)
    --//----事件
    GameEvent_PlaceFinsh(pid, init)
end


---获得道具当前的价格
function GGameGetItemMoney(id)
    local info = ItemList_Static[id]
    --根据研究的次数,获得的收益会提高
    local myiteminfo = PlayerInfos:getItems()[id]
    local sumyj = 1
    if myiteminfo then
        sumyj = myiteminfo.sumyj or 1
    end

    --基础增长值
    local baseup = 10
    local money = info.money
    if money / 10 > 10 then
        baseup = math.ceil(money / 10.0)
    end
    ----根据研究次数获得累积值
    for k=1,(sumyj-1) do
        money = money + baseup
        baseup = baseup * 0.8
    end

    return math.floor(money)
end


------////////初始化建筑解锁条件
local TableBuildOpens = {}
function GFuncGetTableBuilds()
    return TableBuildOpens
end
local function InitTableBuildOpenType()
    TableBuildOpens = {}
    --初始化所有任务,拆分细化其开启条件
    for k,info in pairs(BuildList_Static) do
        local _info = deepcopy(info)
        --开启条件列表
        _info["openlist"] = {}

        --开启条件
        local stropentype = info.open
        local olist = lua_string_split(stropentype or "", "|")
        for _k,_str in pairs(olist) do
            --详细条件
            local rinfos = lua_string_split(_str or "", ":")
            --类型
            if #rinfos > 1 then
                local _type = rinfos[1] + 0
                local param1 = rinfos[2]
                local param2 = 0
                --认同度到达需要有两个参数
                if _type == GTaskOpenType_Argee then
                    local rparaminfos = lua_string_split(param1 or "", "+")
                    param1 = rparaminfos[1]
                    param2 = rparaminfos[2]
                end
                --print(_type,GTaskOpenType_Argee,param1, param2)
                local openinfo = {
                    type=_type+0,--类型
                    param1=param1+0,--参数1
                    param2=param2+0,--参数2
                    finsh=false,--是否已经达成
                }
                table.insert(_info.openlist, openinfo)
            end
        end

        TableBuildOpens[_info.id] = _info
    end
end

----//////////////初始化角色解锁
local TableRoleOpens = {}
function GFuncGetTableRoles()
    return TableRoleOpens
end
local function InitTableRoleOpenType()
    TableRoleOpens = {}
    --初始化所有任务,拆分细化其开启条件
    for k,info in pairs(RoleInfos_Static) do
        local _info = deepcopy(info)
        --开启条件列表
        _info["openlist"] = {}
        --是否已经解锁
        _info["openstats"] = false

        --开启条件
        local stropentype = info.open
        local olist = lua_string_split(stropentype or "", "|")
        for _k,_str in pairs(olist) do
            --详细条件
            local rinfos = lua_string_split(_str or "", ":")
            --类型
            if #rinfos > 1 then
                local _type = rinfos[1] + 0
                local param1 = rinfos[2]
                local param2 = 0
                --认同度到达需要有两个参数
                if _type == GTaskOpenType_Argee then
                    local rparaminfos = lua_string_split(param1 or "", "+")
                    param1 = rparaminfos[1]
                    param2 = rparaminfos[2]
                end
                --print(_type,GTaskOpenType_Argee,param1, param2)
                local openinfo = {
                    type=_type+0,--类型
                    param1=param1+0,--参数1
                    param2=param2+0,--参数2
                    finsh=false,--是否已经达成
                }
                table.insert(_info.openlist, openinfo)
            end
        end

        TableRoleOpens[_info.id] = _info
    end
end


-----////////////////研究解锁
local TableYanjiuOpens = {}
function GFuncGetTableYanJius()
    return TableYanjiuOpens
end
local function InitTableYanJiuOpenType()
    TableYanjiuOpens = {}
    --初始化所有任务,拆分细化其开启条件
    for k,info in pairs(ItemList_Static) do
        local _info = deepcopy(info)
        --开启条件列表
        _info["openlist"] = {}

        --开启条件
        if info.open then
        local stropentype = info.open
        local olist = lua_string_split(stropentype or "", "|")
        for _k,_str in pairs(olist) do
            --详细条件
            local rinfos = lua_string_split(_str or "", ":")
            --类型
            if #rinfos > 1 then
                local _type = rinfos[1] + 0
                local param1 = rinfos[2]
                local param2 = 0
                --认同度到达需要有两个参数
                if _type == GTaskOpenType_Argee then
                    local rparaminfos = lua_string_split(param1 or "", "+")
                    param1 = rparaminfos[1]
                    param2 = rparaminfos[2]
                end
                --print(_type,GTaskOpenType_Argee,param1, param2)
                local openinfo = {
                    type=_type+0,--类型
                    param1=param1+0,--参数1
                    param2=param2+0,--参数2
                    finsh=false,--是否已经达成
                }
                table.insert(_info.openlist, openinfo)
            end
        end

        TableYanjiuOpens[_info.id] = _info
        end
    end
end



------///////////////初始化任务相关信息
local TableTaskInfos = {}
--所有任务
function GFuncGetTableTaskInfos()
    return TableTaskInfos
end
--获得指定任务信息
function GFuncGetTaskForID(tid)
    return TableTaskInfos[tid]
end
local function InitTableTaskInfos()
    TableTaskInfos = {}
    --初始化所有任务,拆分细化其开启条件
    for k,info in pairs(Tasks_Static) do
        local _info = deepcopy(info)

        --开启条件列表
        _info["openlist"] = {}
        --时长_info.time
        --已经经过的时长
        _info.elaptime = 0
        --任务状态
        _info.status = GTaskStatus_Close

        --开启条件
        local stropentype = info.opentype
        local olist = lua_string_split(stropentype or "", "|")

        ----地点不在都城的还需要添加地区开启限制
        if _info.mid and _info.mid ~= 1 then
            table.insert(olist, string.format("%d:%d",GTaskOpenType_AreaOpen,_info.mid))
        end
        ---护送任务需要添加地区开启限制
        if _info.type == GTaskType_Moved and _info.param then
            table.insert(olist, string.format("%d:%d",GTaskOpenType_AreaOpen,_info.param))
        end

        for _k,_str in pairs(olist) do
            --详细条件
            local rinfos = lua_string_split(_str or "", ":")
            --类型
            if #rinfos > 1 then
                local _type = rinfos[1] + 0
                local param1 = rinfos[2]
                local param2 = 0
                --认同度到达需要有两个参数
                if _type == GTaskOpenType_Argee then
                    local rparaminfos = lua_string_split(param1 or "", "+")
                    param1 = rparaminfos[1]
                    param2 = rparaminfos[2]
                end
                --print(_type,GTaskOpenType_Argee,param1, param2)
                local openinfo = {
                    type=_type+0,--类型
                    param1=param1+0,--参数1
                    param2=param2+0,--参数2
                    finsh=false,--是否已经达成
                }
                table.insert(_info.openlist, openinfo)
            end
        end

        TableTaskInfos[_info.id] = _info
    end
end 
--通过任务未提交任务
function GFuncSetTaskFinshTemp(tid, init)
    PlayerInfos.finshTempTasks[tid] = true


    ---从已接受任务列表中移除
    if PlayerInfos.acceptTasks[tid] then
        PlayerInfos.acceptTasks[tid] = nil
    end

    --//----事件
    GameEvent_TaskTempFinsh(tid, init)
end
--通过任务
function GFuncSetTaskFinsh(tid, init)
    PlayerInfos.finshTasks[tid] = true

    ---从已完成任务临时列表中移除
    if PlayerInfos.finshTempTasks[tid] then
        PlayerInfos.finshTempTasks[tid] = nil
    end

    --//----事件
    GameEvent_TaskFinsh(tid, init)
end
--添加一个新的任务(添加到未接受任务列表中)
function GFuncAddNewTask(tid, init)
    --print("新任务",tid,init)
    PlayerInfos.nofinshTasks[tid] = true

    GameEvent_OpenTask(tid,init)
end
--接受一个任务
function GFuncAcceptTask(tid, init)
    PlayerInfos.acceptTasks[tid] = true

    ---从未接受任务列表中移除
    if PlayerInfos.nofinshTasks[tid] then
        PlayerInfos.nofinshTasks[tid] = nil
    end

    GameEvent_AcceptTask(tid,init)
end



---///////////////////初始化所有平叛/任务点的战斗场景信息
local TablePlaceTaskFightInfos = {}
local function InitPlaceTaskFightInfo()
    TablePlaceTaskFightInfos = {}

    --for k, info in pairs(FightLevel_Static) do
    for k=1, table.maxn(FightLevel_Static) do
        local info = FightLevel_Static[k]
        if info then
            if TablePlaceTaskFightInfos[info.pid] == nil then
                TablePlaceTaskFightInfos[info.pid] = {}
            end
            --TablePlaceTaskFightInfos[info.pid][info.lv] = info
            table.insert(TablePlaceTaskFightInfos[info.pid], info)
        end
    end
end
function GFuncGetPTaskFightInfo(pid, lv)
    if TablePlaceTaskFightInfos[pid][lv] then
        return TablePlaceTaskFightInfos[pid][lv]
    end
    return nil
end
--获取战斗的最大长度
function GFuncGetTPaskFightLevel(pid)
    -- body
    return table.getn(TablePlaceTaskFightInfos[pid] or {})
end


-------------/////////////初始化辅助角色信息

--------------------
function InitGameAllDatas()
    GGamePause = false
    GGameFuncCloseAllInterface()
    GGameFuncInitTaskCount()

    InitPlaceTaskFightInfo()
    InitAreaArgee()
    InitTableTaskInfos()
    InitAreaPlaceInfos()
    InitTableBuildOpenType()
    InitTableYanJiuOpenType()
    InitTableRoleOpenType()
end
















