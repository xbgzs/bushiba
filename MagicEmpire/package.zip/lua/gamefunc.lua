-- 返回时间格式(xx:xx:xx),传入时间(秒)
function GFunc_ChangeToTimeFormat(ftime)
    local tsc = ftime%60
    local tmi = (ftime-tsc)/60
    
    local rstr = string.format("%d",tmi)
    if string.len(string.format("%d",tmi)) == 1 then
        rstr = string.format("0%d",tmi)
    end
    if string.len(string.format("%d",tsc)) == 1 then
        rstr = table.concat({rstr,string.format(":0%d",tsc)})
    else
        rstr = table.concat({rstr,string.format(":%d",tsc)})
    end
    
    return rstr
end

-----------自定按钮触摸
function GFunc_SelectBtnRun(btnTables, x, y, eventType, isclick)
    if x ==nil or y == nil then
        return
    end
    local selbtn = nil
    for k,btn in pairs(btnTables) do
        if btn and btn:isEnabled() and btn:isVisible() then
        if not selbtn and btn:rect():containsPoint(ccp(x,y)) then
            if eventType ~= CCTOUCHENDED then
                if not btn:isSelected() then
                    btn:selected()
                end
            else
                if btn:isSelected() then
                    btn:unselected()
                end
                if isclick == nil or isclick == true then
                    --执行
                    btn:activate()
                    break
                end
            end
            selbtn = btn
        else
            btn:unselected()
        end
        end
    end
    return selbtn
end

function GFunc_RemoveChild(obj)
    if obj and obj.getParent and obj:getParent() then
        obj:getParent():removeChild(obj, true)
    end
end

function GFuc_GetUserDefault(key)
    return CCUserDefault:sharedUserDefault():getIntegerForKey(key)
end
function GFuc_SetUserDefault(key, value)
    CCUserDefault:sharedUserDefault():setIntegerForKey(key, value)
    CCUserDefault:sharedUserDefault():flush()
end
function GFuc_GetUserStrDefault(key)
    return CCUserDefault:sharedUserDefault():getStringForKey(key)
end
function GFuc_SetUserStDerfault(key, value)
    CCUserDefault:sharedUserDefault():setStringForKey(key, value)
    CCUserDefault:sharedUserDefault():flush()
end



function json(json)
    local rt={}
    local j=string.gsub(json,'\"([^\"]-)\":','%1=')
    local j=string.gsub(j,'%[','{')
    local j=string.gsub(j,'%]','}')
    local j='t='..j
    if j then
        loadstring(j)()
        rt = t
    end
    return rt
end

-----把table转换成json格式
function table2json(t)  
    local function serialize(tbl)  
        local tmp = {}  
        for k, v in pairs(tbl) do  
            local k_type = type(k)  
            local v_type = type(v)  
            local key = (k_type == "string" and "\"" .. k .. "\":")  
                or (k_type == "number" and "")  
            local value = (v_type == "table" and serialize(v))  
                or (v_type == "boolean" and tostring(v))  
                or (v_type == "string" and "\"" .. v .. "\"")  
                or (v_type == "number" and v)  
            tmp[#tmp + 1] = key and value and tostring(key) .. tostring(value) or nil  
        end  
        if table.maxn(tbl) == 0 then  
                return "{" .. table.concat(tmp, ",") .. "}"  
        else  
                return "[" .. table.concat(tmp, ",") .. "]"  
        end  
    end  
    assert(type(t) == "table")  
    return serialize(t)  
end  


--[[
 Lua有提供一些现成的函数可用来做序列化和反序列化操作。。。  
 其中loadstring可以执行字符串。  
 通过  
 lua = "return " .. lua  
 local func = loadstring(lua)  
 即实现了反序列化。。。
--]]
function serialize(obj)  
    local lua = ""  
    local t = type(obj)  
    if t == "number" then  
        lua = lua .. obj  
    elseif t == "boolean" then  
        lua = lua .. tostring(obj)  
    elseif t == "string" then  
        lua = lua .. string.format("%q", obj)  
    elseif t == "table" then  
        lua = lua .. "{\n"  
    for k, v in pairs(obj) do  
        lua = lua .. "[" .. serialize(k) .. "]=" .. serialize(v) .. ",\n"  
    end  
    local metatable = getmetatable(obj)  
        if metatable ~= nil and type(metatable.__index) == "table" then  
        for k, v in pairs(metatable.__index) do  
            lua = lua .. "[" .. serialize(k) .. "]=" .. serialize(v) .. ",\n"  
        end  
    end  
        lua = lua .. "}"  
    elseif t == "nil" then  
        return nil  
    else  
        error("can not serialize a " .. t .. " type.")  
    end  
    return lua  
end  
---反序列化
function unserialize(lua)  
    local t = type(lua)  
    if t == "nil" or lua == "" then  
        return nil  
    elseif t == "number" or t == "string" or t == "boolean" then  
        lua = tostring(lua)  
    else  
        error("can not unserialize a " .. t .. " type.")  
    end  
    lua = "return " .. lua  
    local func = loadstring(lua)  
    if func == nil then  
        return nil  
    end  
    return func()  
end  

--table拷贝1
function th_table_dup(ori_tab)
    if (type(ori_tab) ~= "table") then
        return nil;
    end
    local new_tab = {};
    for i,v in pairs(ori_tab) do
        local vtyp = type(v);
        if (vtyp == "table") then
            new_tab[i] = th_table_dup(v);
        elseif (vtyp == "thread") then
            -- TODO: dup or just point to?
            new_tab[i] = v;
        elseif (vtyp == "userdata") then
            -- TODO: dup or just point to?
            new_tab[i] = v;
        else
            new_tab[i] = v;
        end
    end
    return new_tab;
end
--table拷贝
function deepcopy(object)
    local lookup_table = {}
    local function _copy(object)
        if type(object) ~= "table" then
            return object
        elseif lookup_table[object] then
            return lookup_table[object]
        end  -- if
        local new_table = {}
        lookup_table[object] = new_table
        for index, value in pairs(object) do
            new_table[_copy(index)] = _copy(value)
        end  -- for
        return setmetatable(new_table, getmetatable(object))
    end  -- function _copy
    return _copy(object)
end  -- function deepcopy


function rand(inta,intb)                ------随机数方法
    return math.random(inta,intb)
end

----转换成整数
function ConsertInt(rvalue)
    rvalue = string.format("%.0f", rvalue)
    rvalue = rvalue + 0
    return rvalue
end

-------------------------------------------------------
-- 参数:待分割的字符串,分割字符
-- 返回:子串表.(含有空串)
function lua_string_split(str, split_char)
    local sub_str_tab = {};
    while (true) do
        local pos = string.find(str, split_char);
        if (not pos) then
            sub_str_tab[#sub_str_tab + 1] = str;
            break;
        end
        local sub_str = string.sub(str, 1, pos - 1);
        sub_str_tab[#sub_str_tab + 1] = sub_str;
        str = string.sub(str, pos + 1, #str);
    end

    return sub_str_tab;
end

function ConsertResultValue(values)
    if not values or #values < 2 then
        return 0
    end
    local rvalue = values[1] * rand(10000-values[2], 10000+values[2]) / 10000
    return ConsertInt(rvalue)
end

function ConsertResultValueForSplit(str)
    local values = lua_string_split(str, "|")
    local rvalue = ConsertResultValue(values)
    return rvalue
end


-----把传入的字符串解析返回table
function ConvertStrForTables(str)
    local lastchar = ""
    local schar = ""
    local data = {}
    
    ---如果最后一个字符不是",",最添加一个
    local slenght = string.len(str)
    if string.sub(str,slenght,slenght) ~= "," then
        str = string.format("%s,",str)
    end
    local slenght = string.len(str)
    
    for k=1, slenght do
        local s = string.sub(str,k,k)
        if s == ":" then
            lastchar = schar
            schar = ""
        elseif s == "," then
            data[lastchar] = schar
            
            schar = ""
            lastchar = ""
        else
            schar = string.format("%s%s",schar,s)
        end
    end
    
    return data
end

------把输入的字符串解析返回数组table数据
function ConvertStrForTableLists(str, spltestr)
    if spltestr == nil then
        spltestr = "*"
    end
    
    ---如果最后一个字符不是 spltestr,最添加一个
    local slenght = string.len(str)
    if string.sub(str,slenght,slenght) ~= spltestr then
        str = string.format("%s%s",str,spltestr)
    end
    local slenght = string.len(str)
    
    local tables = {}
    local slenght = string.len(str)
    local lastchar = ""
    local schar = ""
    local data = {}
    for k=1, slenght do
        local s = string.sub(str,k,k)
        if s == ":" then
            lastchar = schar
            schar = ""
        elseif s == "," then
            data[lastchar] = schar
            
            schar = ""
            lastchar = ""
        elseif s == spltestr then --新的一条数据
            table.insert(tables, data)
            data = {}
        else
            schar = string.format("%s%s",schar,s)
        end
    end
    
    return tables
end

--计算线段o-s,与 o-e之间的角度
function GFunc_Angle(o, s, e)
    local cosfi = 0
    local fi = 0
    local norm = 0
    local dsx = s.x - o.x
    local dsy = s.y - o.y
    local dex = e.x - o.x
    local dey = e.y - o.y

    local cosfi = dsx * dex + dsy * dey
    local norm = (dsx * dsx + dsy * dsy) * (dex * dex + dey * dey)
    local cosfi = cosfi / math.sqrt(norm)

    local fi = math.acos(cosfi)
    if 180 * fi / math.pi < 180 then
        return 180 * fi / math.pi
    else
        return 360 - 180 * fi / math.pi
    end
end
--获得360度的角度
function GFunc_Angle360(o, s, e)
    if GFunc_PostionSame(o, s) or GFunc_PostionSame(o, e) or GFunc_PostionSame(s, e) then
        return 0
    end

    local rotate = GFunc_Angle(o, s, e)
    local dir = ccpNormalize(ccp(e.x-s.x, e.y-s.y))  --math3d.vector2(e[0], e[1]) - math3d.vector2(s[0], s[1])
    if dir.x < 0 then
        rotate = 360 - rotate
    end
    return rotate * math.pi/180
end
--两点相等
function GFunc_PostionSame(p0,p1)
    if p0.x == p1.x and p0.y == p1.y then
        return true
    end
    return false
end
