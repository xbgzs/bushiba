
------------------------
--音乐音效开关
function Config_SoundOff(v)
    if v then
        CCUserDefault:sharedUserDefault():setIntegerForKey("sound", v)
        CCUserDefault:sharedUserDefault():flush()
    else
        return CCUserDefault:sharedUserDefault():getIntegerForKey("sound")
    end
end

--自动存档
function Config_AutoSaveGameData()
    if not GGamePause then
        Config_SaveGameData()
    end
end

function Config_SaveGameData(index, v)
    if index == nil then
        index = PlayerInfos.rdataindex
    end
    if v == nil then
        v = serialize(PlayerInfos:getGameData())
    end
    CCUserDefault:sharedUserDefault():setStringForKey(string.format("save%d", index), v)
    --存档相关的日期,时间，描述

    CCUserDefault:sharedUserDefault():flush()
end

function Config_LoadGameData(index)
    return CCUserDefault:sharedUserDefault():getStringForKey(string.format("save%d",index))
end

function Config_GameTutorialData(v, index)
    if index == nil then
        index = PlayerInfos.rdataindex
    end

    if v == nil then
        return CCUserDefault:sharedUserDefault():getStringForKey(string.format("tutorial%d",index))
    else
        CCUserDefault:sharedUserDefault():setStringForKey(string.format("tutorial%d",index), serialize(v))
        --存档相关的日期,时间，描述
        CCUserDefault:sharedUserDefault():flush()
    end
end

---本地ID
function SetMyServerID(v)
    CCUserDefault:sharedUserDefault():setIntegerForKey("server_id", v)
    CCUserDefault:sharedUserDefault():flush()
end
function GetMyServerID()
    return CCUserDefault:sharedUserDefault():getIntegerForKey("server_id")
end
----------------存档
















