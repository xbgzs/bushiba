
--------
local _GFunc_Game_updateData = nil
function GFunc_Game_updateData()
    if _GFunc_Game_updateData then
        _GFunc_Game_updateData()
    end
end

GFInterface_TaskDetail  = nil --详细任务
GFInterface_Tasks       = nil --任务列表
GFInterface_BuildInfos  = nil --建筑
GFInterface_Shoping     = nil --商店
GFInterface_ShopingReward   = nil --抽奖
GFInterface_BuildDetail = nil --建筑信息
GFInterface_Yanjiu      = nil --研究详细界面
GFInterface_PlayerInfo  = nil --玩家信息
GFInterface_MessageDialog   = nil --提示框

function GGameFuncHasInterfaceShow()
    -- body
    --print(GFInterface_TaskDetail , GFInterface_Tasks , GFInterface_BuildInfos , GFInterface_Shoping , GFInterface_BuildDetail
    --    , GFInterface_Yanjiu,GFInterface_PlayerInfo)
    if GFInterface_TaskDetail or GFInterface_Tasks or GFInterface_BuildInfos or GFInterface_Shoping or GFInterface_BuildDetail
        or GFInterface_Yanjiu or GFInterface_PlayerInfo or GFInterface_ShopingReward or GFInterface_MessageDialog then
        return true
    end
    return false
end

---关闭所有打开的界面
function GGameFuncCloseAllInterface()
    GFunc_RemoveChild(GFInterface_TaskDetail)
    GFunc_RemoveChild(GFInterface_Tasks)
    GFunc_RemoveChild(GFInterface_BuildInfos)
    GFunc_RemoveChild(GFInterface_Shoping)
    GFunc_RemoveChild(GFInterface_BuildDetail)
    GFunc_RemoveChild(GFInterface_Yanjiu)
    GFunc_RemoveChild(GFInterface_PlayerInfo)
    GFunc_RemoveChild(GFInterface_ShopingReward)
    GFunc_RemoveChild(GFInterface_MessageDialog)

    GFInterface_ShopingReward = nil
    GFInterface_TaskDetail  = nil --详细任务
    GFInterface_Tasks       = nil --任务列表
    GFInterface_BuildInfos  = nil --建筑
    GFInterface_Shoping     = nil
    GFInterface_BuildDetail = nil
    GFInterface_Yanjiu = nil
    GFInterface_PlayerInfo = nil
    GFInterface_MessageDialog = nil
end


GameFuncClockCity = nil
GameFuncUnclockCity = nil
GameFuncHideCity = nil
GameFuncShowCity = nil

GameFuncLockMenu    = nil
GameFuncUnLockMenu  = nil

-- 菜单显示层
function createLayerMainMenu()
    local layer = nil
    local scene = nil
    local menu = nil

    local function update(dt)
        GFunc_Game_updateData()
    end
    
    scene = CCScene:create()
    layer = GFunc_CreateLayerEnterOrExit({update = update})
    scene:addChild(layer)
    scene:addChild(CreateBackMenuItem(),2)
    GameReplaceScne(scene, UI_Menu)

    -----------城市界面初始化
    local layerCity = createLayerCity()
    layer:addChild(layerCity.layer)

    GameFuncLockMenu = function()
        menu:setEnabled(false)
    end
    GameFuncUnLockMenu = function()
        menu:setEnabled(true)
    end
    --事件表
    GameFuncClockCity = function()
        GameFuncLockMenu()
        layerCity.layer:setTouchEnabled(false)
        layerCity.menu:setEnabled(false)
    end
    GameFuncUnclockCity = function()
        GameFuncUnLockMenu()
        layerCity.layer:setTouchEnabled(true)
        layerCity.menu:setEnabled(true)
    end
    GameFuncHideCity = function()
        layer:setVisible(false)
        GameFuncClockCity()

        GGameShowInterface = GGameInterface_Other
    end
    GameFuncShowCity = function()
        GGameShowInterface = GGameInterface_City
        layer:setVisible(true)
        GameFuncUnclockCity()
    end

    ------------
    menu = CCMenu:create()
    menu:setPosition(ccp(0,0))
    layer:addChild(menu)
    
    --菜单
    local btnItem = GFunc_CreateButtonP("GUI_Pause.png", function()
        --显示菜单
        GameFuncClockCity()
        GGamePause = true
        createLayerCityMenu(function()
            GameFuncUnclockCity()
            GGamePause = false
        end)
    end,nil,1.5)
    btnItem:setPosition(ccp(60, DWinSize.height - 100))
    menu:addChild(btnItem)
    
    --玩家信息
    local btnItem = GFunc_CreateButtonP("jiemian_015.png", function()
        GameFuncClockCity()
        GShowDialogPlayerInfos(function()
            GameFuncUnclockCity()
        end)
    end,nil,1.5)
    btnItem:setPosition(ccp(60, 60))
    menu:addChild(btnItem)
    --建造
    local btnItem = GFunc_CreateButtonP("jiemian_016.png", function()
        GameFuncClockCity()
        createLayerBuildMenu(function()
            GameFuncUnclockCity()
        end)
    end,nil,1.5)
    btnItem:setPosition(ccp(DWinSize.width - 60, 60))
    menu:addChild(btnItem)
    --攻击
    local btnItem = GFunc_CreateButtonP("jiemian_017.png", function()
        GameFuncHideCity()
        createLayerGoFight(function()
            GameFuncShowCity()
        end)
    end,nil,1.5)
    btnItem:setPosition(ccp(60, 150))
    menu:addChild(btnItem)
    --邮箱/任务
    local btnItemTask = GFunc_CreateButtonP("jiemian_018.png", function()
        GameFuncClockCity()
        createLayerTaskMenu(function()
            GameFuncUnclockCity()
        end)
    end,nil,1.5)
    btnItemTask:setPosition(ccp(150, 60))
    menu:addChild(btnItemTask)
    --商店/购买
    local btnItem = GFunc_CreateButtonP("jiemian_143.png", function()
        GameFuncClockCity()
        createLayerShop(function()
            GameFuncUnclockCity()
        end)
    end,nil,1.5)
    btnItem:setPosition(ccp(DWinSize.width - 160, 60))
    menu:addChild(btnItem)


    local spGold = CCSprite:createWithSpriteFrameName("jiemian_008.png")
    spGold:setAnchorPoint(ccp(1,1))
    spGold:setPosition(ccp(DWinSize.width, DWinSize.height-5))
    layer:addChild(spGold)

    ----金币
    local numberMoney = GameNumbers:new(vNumberWhite)
    numberMoney:addLayer(spGold)
    numberMoney:setPosition(ccp(140, 75))

    ----魔法点
    local numberMagic = GameNumbers:new(vNumberWhite)
    numberMagic:addLayer(spGold)
    numberMagic:setPosition(ccp(155, 25))

    --宝石sp
    local spCrystal = GFunc_CreateButtonP("jiemian_168.png", function()
        GameFuncClockCity()
        createLayerShop(function()
            GameFuncUnclockCity()
        end)
    end,1.1,1.2)
    menu:addChild(spCrystal)
    spCrystal:setPosition(ccp(550, DWinSize.height-140))

    local numberCrystal = GameNumbers:new(vNumberWhite)
    numberCrystal:addLayer(spCrystal)
    numberCrystal:setPosition(ccp(100, 25))

    ---游戏时间
    --显示在左上角,背景sp
    local spGameTime = CCSprite:createWithSpriteFrameName("jiemian_007.png")
    spGameTime:setAnchorPoint(ccp(0,0.5))
    spGameTime:setPosition(ccp(5, DWinSize.height-30))
    layer:addChild(spGameTime)
    --年
    local numTimeYear = GameNumbers:new(vNumberWhite, NumberAlginment_Right)
    numTimeYear:addLayer(spGameTime)
    numTimeYear:setScale(0.8)
    numTimeYear:setPosition(ccp(60, 23))
    --月
    local numTimeMonth = GameNumbers:new(vNumberWhite, NumberAlginment_Right)
    numTimeMonth:addLayer(spGameTime)
    numTimeMonth:setScale(0.8)
    numTimeMonth:setPosition(ccp(125, 23))
    --周
    local numTimeWeek = GameNumbers:new(vNumberWhite, NumberAlginment_Right)
    numTimeWeek:addLayer(spGameTime)
    numTimeWeek:setScale(0.8)
    numTimeWeek:setPosition(ccp(190, 23))

    ----任务数显示 GGameFuncGetTaskCount
    local spTaskSBG = CCSprite:createWithSpriteFrameName("jiemian_136.png")
    spTaskSBG:setPosition(ccp(85,85))
    btnItemTask:addChild(spTaskSBG)

    local txtTaskSum = CCLabelTTF:create("", "Arial", 28)
    txtTaskSum:setPosition(ccp(85,85))
    btnItemTask:addChild(txtTaskSum)

    _GFunc_Game_updateData = function()
        numberMoney:setString(PlayerInfos:getMoney())
        numberMagic:setString(PlayerInfos:getMagic())
        numberCrystal:setString(PlayerInfos:getCrystal())

        --年
        local iyear = PlayerInfos.citytimeformat[1] + 1
        --月
        local imonth = PlayerInfos.citytimeformat[2] + 1
        --周
        local iweek = PlayerInfos.citytimeformat[3] + 1

        numTimeYear:setString(iyear)
        numTimeMonth:setString(imonth)
        numTimeWeek:setString(iweek)

        if GGameFuncGetTaskCount() > 0 then
            spTaskSBG:setVisible(true)
            txtTaskSum:setVisible(true)
            txtTaskSum:setString(GGameFuncGetTaskCount())
        else
            spTaskSBG:setVisible(false)
            txtTaskSum:setVisible(false)
        end
    end





    ----新游戏
    local _strtime = ConsertInt(PlayerInfos.citytime)
    --总周
    local iallweek = math.floor(_strtime/GameWeekTimes)
    --总月
    local iallmonth = math.floor(iallweek/4)
    if GGameInitTutorialID ~= nil and TStep6 ~= GGameInitTutorialID and TStep7 ~= GGameInitTutorialID and TStep8 ~= GGameInitTutorialID then
        --print("初始化游戏")
        GameFuncUnclockCity()
        GGamePause = true
        local function runinitgame()
            TutorialTaskRun(GGameInitTutorialID)
        end
        ---场景渐渐显示
        local layer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,255), fmbg=true})
        layer:runAction(CCSequence:createWithTwoActions(CCFadeOut:create(2.0), CCCallFunc:create(function()
            scene:removeChild(layer, true)
            runinitgame()
        end)))
        scene:addChild(layer, 15)
    end
end




