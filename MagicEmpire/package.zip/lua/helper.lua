-- cclog
cclog = function(...)
    print(string.format(...))
end

-- 当前显示的界面
local ShowScene = nil
-- 上次显示界面
local ShowSceneLast = nil
-- 当前显示的界面的scene
ShowSceneLayer = nil

-- 菜单返回回调
function MainMenuCallback()
    if ShowScene == UI_Menu and GGameShowInterface == GGameInterface_City then
        GGameFuncCloseAllInterface()
        --显示菜单
        GameFuncClockCity()
        GGamePause = true
        createLayerCityMenu(function()
            GameFuncUnclockCity()
            GGamePause = false
        end)
    else
        CCDirector:sharedDirector():endToLua()
    end
end

-- 返回主要返回莱单界面
function CreateBackMenuItem()
    local layer = CCLayer:create()
    ---手机返回键操作
    local _showTime = os.clock()
    local function KeypadHandler(strEvent)
        if os.clock() - _showTime < 1.5 then
            return
        end
        --按返回键时显示暂停界面
        if strEvent == CCTOUCHKEYBACK then   --CCTOUCHKEYMENU
            MainMenuCallback()
        end
    end
    
    layer:setKeypadEnabled(true)
    layer:registerScriptKeypadHandler(KeypadHandler)
    
    return layer
end

---- 游戏中,暂停按钮
function CreateGameStopLayer(pos)
    local layer = CCLayer:create()
    return layer
end

--暂停游戏
function GamePasueHelper()
    CCDirector:sharedDirector():getScheduler():setTimeScale(0)
end
--启动游戏
function GameResumeHelper()
    CCDirector:sharedDirector():getScheduler():setTimeScale(1.0)
end

function GameGetRunScene()
    -- body
    return ShowSceneLayer
end

function GameResumeShowScene()
    ShowScene = 0x00
end

-- 切换场景界面
function GameReplaceScne(scenelayer, id)
    if ShowScene == id then
        return false
    end
    --GFunc_ClearSMessage()
    if CCDirector:sharedDirector():getRunningScene() == nil then
        CCDirector:sharedDirector():runWithScene(scenelayer)
    else
        CCDirector:sharedDirector():replaceScene(scenelayer)
    end
    ShowSceneLast = ShowScene
    ShowScene = id
    ShowSceneLayer = scenelayer
    
    GameResumeHelper(true)
    
    ----背景音乐
    
    --if id == UI_Login or id == UI_Register or id == UI_CreateRole then
    --    Play_BackgroundMusic("login.mp3")
    --end
    
    
    return true
end


---游戏中断
function GameDidEnterBackGround()
    --GamePasueHelper()
end

function GameWillEnterBackGround()
    --GameResumeHelper(true)
    ---
    --Play_Bgm(true)
end


----JAVA回调返回
local GTableJavaHandlerResultList = {}
local GTableJavaHandler = {}
function GFuncSetJavaHandler(handler, func)
    GTableJavaHandler[handler] = func
end

function GameJavaHandlerUpdate(dt)
    if #GTableJavaHandlerResultList > 0 then
        local info = GTableJavaHandlerResultList[1]
        table.remove(GTableJavaHandlerResultList, 1)

        if GTableJavaHandler[info.pid] then
            GTableJavaHandler[info.pid](info.param, info.value)
        end
    end
end

function GameJavaHandler(pid, param, value)
    table.insert(GTableJavaHandlerResultList, {pid=pid, param=param, value=value})
end


