------
--商店 uiShop
------
local TableShoping_Static = {
    [1] = {
        namesp = "shop_002",
        art = "shop_004",
        money = 5,
    },
    [2] = {
        namesp = "shop_003",
        art = "shop_004",
        money = 5,
    },
    [3] = {
        namesp = "shop_001",
        art = "shop_008",
        money = 30,
    },
}


function createLayerShop(endfunc)
    local layer = nil

    local function closefunc()
        CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
        if endfunc then
            endfunc()
        end
    end
    
    ------------
    local touchBegin = function(x,y)
    end
    local touchMoved = function(x,y)
    end
    local touchEnded = function(x,y)
    end
    local function exitlayer()
        GFInterface_Shoping = nil
    end
    ----------
    layer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,100), exfunc=exitlayer, touchBegin=touchBegin, touchMoved=touchMoved, touchEnded=touchEnded})

    GFInterface_Shoping = layer
    ------------
    CCDirector:sharedDirector():getRunningScene():addChild(layer)
    local _parent = CCNode:create()
    layer:addChild(_parent)
    
    --背景
    local uiWidth, uiHeight = 577, 693
    local spbg = gfuncCreateUIBG({height=uiHeight})
    spbg:setPosition(ccp(uiWidth/2, uiHeight/2))
    _parent:addChild(spbg)

    --标题选择sp 
    --local spbg = CCSprite:createWithSpriteFrameName("jiemian_003.png")
    --spbg:setPosition(ccp(uiWidth/2, uiHeight-53))
    --_parent:addChild(spbg)

    local menu = CCMenu:create()
    menu:setPosition(ccp(0,0))
    _parent:addChild(menu)
    
    --关闭
    local btnItem = GFunc_CreateButtonP("jiemian_105.png", function()
        closefunc()
    end, nil, 1.5)
    btnItem:setPosition(ccp(uiWidth-10, uiHeight-30))
    menu:addChild(btnItem)
    
    ------------------------
    local function buildcallback(tag)
        if tag == 3 then
        --layer:setTouchEnabled(false)
        createLayerShopReward({func=function()
            --layer:setTouchEnabled(true)
        end})
        end
    end

    
    --翻页界面
    local layerPage = GameContainerPage:new(DWinSize.width, DWinSize.height)
    local _parentNode = nil
    local _pageMenu = nil
    local _pageMenuInfo = nil
    
    local _visitNodeParent = GFunc_CreateLayerVisit(layer, 530, 600, 55, 160)
    _visitNodeParent:addChild(layerPage._parnet)

    layerPage:setPosition(ccp(-110,0))
    
    --建筑列表
    local pagesum = 4 --每页数量
    
    local bpx = 195
    local bpy = 575
    local inv = 270
    local invw = 250
    local isum = 0

    for k=1,#TableShoping_Static do
        local vbuild = true
        local info = TableShoping_Static[k]

        --是否开启
        if vbuild then
            if _parentNode == nil or isum % pagesum == 0 then
                _parentNode = CCNode:create()
                layerPage:addChild(_parentNode)
                
                _pageMenu = CCMenu:create()
                _pageMenu:setPosition(ccp(0,0))
                _parentNode:addChild(_pageMenu)

                _pageMenuInfo = CCMenu:create()
                _pageMenuInfo:setPosition(ccp(0,0))
                _parentNode:addChild(_pageMenuInfo)
            end
            local pageIndex = isum%4
            local _x = bpx + (pageIndex%2) * invw
            local _y = bpy - math.floor(pageIndex/2) * inv
            --背景
            local btnItem = GFunc_CreateButtonP("jiemian_004.png", buildcallback, 1.05)
            btnItem:setPosition(ccp(_x,_y))
            _pageMenu:addChild(btnItem,0,k)
            local _psize = btnItem:getNormalImage():getContentSize()

            ---显示详细信息按钮
            --local btnItemInfos = GFunc_CreateButtonP("jiemian_005.png", function(tag)
            --    showbuildinfos(tag)
            --end, nil, 3)
            --btnItemInfos:setPosition(ccp(_x+_psize.width/2-20,_y+_psize.height/2-20))
            --_pageMenuInfo:addChild(btnItemInfos, 0, k)

            --图片
            local spbg = nil
            if k == 1 then
                for _k=1,2 do
                    spbg = CCSprite:createWithSpriteFrameName(string.format("%s.png", info.art))
                    spbg:setPosition(ccp(_psize.width/2 - 30 + (_k-1)*60,_psize.height/2))
                    btnItem:addChild(spbg)
                end
            elseif k == 2 then
                for _k=1,4 do
                    spbg = CCSprite:createWithSpriteFrameName(string.format("%s.png", info.art))
                    local vx, vy = 0,0
                    if _k == 1 then
                        vx = -50
                    elseif _k == 2 then
                        vx = 50
                    elseif _k == 3 then
                        vy = 50
                    elseif _k == 4 then
                        vy = -50
                    end
                    spbg:setPosition(ccp(_psize.width/2 + vx,_psize.height/2 + vy))
                    btnItem:addChild(spbg)
                end
            else
                spbg = CCSprite:createWithSpriteFrameName(string.format("%s.png", info.art))
                spbg:setPosition(ccp(_psize.width/2,_psize.height/2))
                btnItem:addChild(spbg)
            end

            --建造费用
            local spmoney = GameNumbers:new(vNumberBFHui, NumberAlginment_Right)
            spmoney:setPosition(ccp(_psize.width-20,30))
            spmoney:addLayer(btnItem)
            spmoney:setString(info.money)

            --名称sp
            if info.namesp then
                --名称背景sp
                local spbg = CCSprite:createWithSpriteFrameName("jiemian_107.png")
                spbg:setPosition(ccp(_psize.width/2,_psize.height + 25))
                btnItem:addChild(spbg)

                local spbg = CCSprite:createWithSpriteFrameName(string.format("%s.png", info.namesp))
                spbg:setPosition(ccp(_psize.width/2,_psize.height + 25))
                btnItem:addChild(spbg)
            end
            
            isum = isum + 1
        end
    end

    ----根据显示页数与当前而显示相关换页按钮
    local pageItemlist = {}
    local function clickPageItem(tag, callback)
        for k, item in pairs(pageItemlist) do
            if k == tag then
                item:setEnabled(false)
            else
                item:setEnabled(true)
            end
        end
        --print(tag,callback)
        if callback == nil then
            layerPage:showPage(tag)
        end
    end

    --根据页数显示按钮数
    for k=1, layerPage:getPageSum() do
        local btnItem = GFunc_CreateButtonDPOther("jiemian_112.png", "jiemian_113.png", function(tag)clickPageItem(tag)end, nil, 2.0)
        btnItem:setPosition(ccp(uiWidth-70 - ((k-1)*50), 40))
        local _pagekey = layerPage:getPageSum()-k
        pageItemlist[_pagekey] = btnItem
        menu:addChild(btnItem, 0, _pagekey)
    end

    ---前翻与后翻
    local btnNextPage = GFunc_CreateButtonP("jiemian_108.png", function()
        layerPage:Show_Layer(true)
    end, nil, 1.5)
    btnNextPage:setPosition(ccp(uiWidth-15, uiHeight/2-20))
    menu:addChild(btnNextPage)

    local function pageEndCallback(_showpage)
        --print("翻页完成",_showpage)
        clickPageItem(_showpage, true)
    end
    clickPageItem(0)

    layerPage:setNextPageFunc(pageEndCallback)
    
    ------------------------
    --界面显示位置
    _parent:setPosition(ccp(DWinSize.width/2 - uiWidth/2, DWinSize.height/2 - uiHeight/2))
end

------------奖励设置
local RewardType_Money  = 0x01
local RewardType_Crystal = 0x02
local RewardType_Magic  = 0x03
local RewardType_Role   = 0x04
local RewardType_Items  = 0x05
local RewardType_RItem  = 0x06
---lv:机率比 vlist:物品/数量表, sum:数量
local shopTableReward_Static = {
    [RewardType_Money]  = {lv=3, vlist={7500, 10000, 12500}},--游戏币
    [RewardType_Crystal] = {lv=1, vlist={25,30,35}},--水晶
    [RewardType_Magic]  = {lv=3, vlist={75,100,125}},--魔法点
    [RewardType_Role]   = {lv=1},--勇者
    [RewardType_Items]  = {lv=1, vlist={2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}},--研究道具
    [RewardType_RItem]  = {lv=2, vlist={25,26,27,28,29,30,31,32,33,34,35,36,37,38,39}},--角色道具
}
--获得道具3个
local GetRewardItemSum = 3
------------抽奖界面
function createLayerShopReward(args)
    if args == nil then
        args = {}
    end

    local layer = nil
    local endfunc = args.func
    --教程抽英雄
    local istutorial = args.tutorial

    local btnTables = {}
    local reloadReward = nil

    --抽奖励数
    local rewardMax = 6
    ----随机出来的奖励列表
    local rewardlist = {}
    --------获得奖励列表
    --是否有未获得的商店勇者
    local rolelist = {}
    for k,info in pairs(RoleInfos_Static) do
        if info.open == nil and PlayerInfos:getAidPlayers()[info.id] == nil then
            table.insert(rolelist, info.id)
        end
    end
    --生成概率表
    local _templist = {}
    for k,info in pairs(shopTableReward_Static) do
        --没有勇者则不需要添加
        if k ~= RewardType_Role or (#rolelist > 0 and k == RewardType_Role) then
            --类型表
            for c=1,info.lv do
                table.insert(_templist, k)
            end
        end
    end
    -------随机出奖励
    for k=1,rewardMax do
        --类型
        local _type = _templist[rand(1,#_templist)]
        ----奖励
        local rinfo = {type=_type, item=nil}
        -----奖励列表v
        local rvlist = {}
        if _type == RewardType_Role then
            rvlist = deepcopy(rolelist)
            --只出现一个角色
            rolelist = {}
            for _k,_t in pairs(_templist) do
                if _t == RewardType_Role then
                    table.remove(_templist,_k)
                    break
                end
            end
        else
            rvlist = shopTableReward_Static[_type].vlist
        end
        ----随机奖励
        rinfo.item = rvlist[rand(1,#rvlist)]

        rewardlist[k] = rinfo
    end


    local function closefunc()
        CCDirector:sharedDirector():getRunningScene():removeChild(layer, true)
        if endfunc then
            endfunc()
        end
    end
    
    ------------
    local touchBegin = function(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x,y,eventType)
    end
    local touchMoved = function(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x,y,eventType)
    end
    local touchEnded = function(x,y,eventType)
        GFunc_SelectBtnRun(btnTables,x,y,eventType)
    end
    local function exitlayer()
        GFInterface_ShopingReward = nil
    end
    ----------
    layer = GFunc_CreateLayerEnterOrExit({fmbg=true,color=ccc4(0,0,0,100), exfunc=exitlayer, touchBegin=touchBegin, touchMoved=touchMoved, touchEnded=touchEnded})

    GFInterface_ShopingReward = layer
    ------------
    CCDirector:sharedDirector():getRunningScene():addChild(layer)
    local _parent = CCNode:create()
    layer:addChild(_parent)

    local bgspNode = CCNode:create()
    layer:addChild(bgspNode)
    
    --背景
    local uiWidth, uiHeight = 577, 460
    local spbg = gfuncCreateUIBG({height=uiHeight})
    spbg:setPosition(ccp(uiWidth/2, uiHeight/2))
    _parent:addChild(spbg)

    --标题选择sp 
    --local spbg = CCSprite:createWithSpriteFrameName("jiemian_003.png")
    --spbg:setPosition(ccp(uiWidth/2, uiHeight-53))
    --_parent:addChild(spbg)

    local menu = CCMenu:create()
    menu:setPosition(ccp(0,0))
    layer:addChild(menu,1)
    
    --关闭
    local btnItemClose = GFunc_CreateButtonP("jiemian_105.png", function()
        closefunc()
    end, nil, 1.5)
    --btnItem:setPosition(ccp(uiWidth-10, uiHeight-30))
    btnItemClose:setPosition(ccp((DWinSize.width-(DWinSize.width-uiWidth)/2-10), (DWinSize.height-(DWinSize.height-uiHeight)/2-30)))
    menu:addChild(btnItemClose)
    if istutorial then
        btnItemClose:setEnabled(false)
    end
    
    ------------------------
    local ritemlist = {}
    local function buildcallback(tag)
        btnItemClose:setEnabled(false)

        ---教程用奖品列表
        if istutorial then
            rewardlist = {}
            ---点击的位置是勇者13
            rewardlist[tag] = {type=RewardType_Role, item=13}
            --其它位置随机
            local trlist = {{type=RewardType_Money, item=10000},{type=RewardType_Crystal, item=30},{type=RewardType_Magic, item=100},
            {type=RewardType_Money, item=12500},{type=RewardType_RItem, item=30}}
            for k=1,rewardMax do
                if tag ~= k then
                    local _rindex = rand(1,#trlist)
                    rewardlist[k] = trlist[_rindex]
                    table.remove(trlist, _rindex)
                end
            end
            --重新加载
            reloadReward()
        end

        for k,item in pairs(ritemlist) do
            item.btn:setEnabled(false)
        end

        --获得道具
        local rinfo = rewardlist[tag]
        if rinfo.type == RewardType_Money then
            PlayerInfos:addMoney(rinfo.item)
        elseif rinfo.type == RewardType_Magic then
            PlayerInfos:addMagic(rinfo.item)
        elseif rinfo.type == RewardType_Role then
            PlayerInfos:unlockAidPlayer(rinfo.item, true)
        elseif rinfo.type == RewardType_Crystal then
            PlayerInfos:addCrystal(rinfo.item)
        else
            PlayerInfos:addItems(rinfo.item, GetRewardItemSum)
        end
        ---结束
        local function funcend()
            if rinfo.type == RewardType_Role then
                layer:setTouchEnabled(false)
                GameEvent_GameEventUnlockRole(rinfo.item, function()
                    layer:setTouchEnabled(true)
                    print("结束...",GFuncTutorialTemp)
                    GFuncTutorialTempFunc()
                end)
            end

            if istutorial then
                btnItemClose:setEnabled(false)
            else
                btnItemClose:setEnabled(true)
            end
        end
        --显示
        local rframe = 0
        local function slupdate()
            rframe = rframe + 1
            local px,py = ritemlist[tag].sp:getPosition()
            if rframe % 2 == 0 then
                local anim = GFunc_CreateAnimation("jingbi_xiaoguo".."_", 1, 10, rand(1,2), 0.1, nil, 3)
                anim:setPosition(ccp(rand(px-60, px+60), rand(py-60, py+60)))
                CCDirector:sharedDirector():getRunningScene():addChild(anim,16)
            end
        end
        local showLayer = GFunc_CreateLayerEnterOrExit({update=slupdate})
        layer:addChild(showLayer,5)
        --显示其它
        local function showRewardItem(itemBtn, first, onend)
            
            local tttime = 1.0
            if first == true then
                tttime = 2.0
            end
            itemBtn.btn:runAction(CCSequence:createWithTwoActions(CCFadeOut:create(tttime), CCCallFunc:create(function()
                --print(itemBtn, first, onend)
                if first == true then
                    --显示其它所有
                    local isend = true
                    for _k,_item in pairs(ritemlist) do
                        if _k ~= tag then
                            showRewardItem(_item,false,isend)
                            isend = false
                        end
                    end

                    GFunc_RemoveChild(showLayer)
                elseif onend then
                    funcend()
                end
            end)))
        end
        ritemlist[tag].sp:setColor(ccc3(216,250,180))
        ----显示获得的道具
        showRewardItem(ritemlist[tag], true)
    end

    --翻页界面
    local layerPage = GameContainerPage:new(DWinSize.width, DWinSize.height)
    local _parentNode = nil
    local _pageMenu = nil
    local _pageMenuInfo = nil
    
    local _visitNodeParent = GFunc_CreateLayerVisit(layer, 530, 600, 55, 160)
    _visitNodeParent:addChild(layerPage._parnet)

    layerPage:setPosition(ccp(-110,0))
    
    --建筑列表
    local pagesum = rewardMax --每页数量
    local bpx = 140
    local bpy = 530
    local inv = 150
    local invw = 170
    local isum = 0
    local rowsum = 3

    reloadReward = function()
        for k,info in pairs(ritemlist) do
            GFunc_RemoveChild(info.btn)
            GFunc_RemoveChild(info.sp)
        end
        ritemlist = {}
        print("清空...")
        btnTables = {}
        table.insert(btnTables, btnItemClose)

        for k=1,rewardMax do
            local info = rewardlist[k]
            local pageIndex = isum%pagesum
            local _x = bpx + (pageIndex%rowsum) * invw
            local _y = bpy - math.floor(pageIndex/rowsum) * inv
            --背景
            local sppbg = CCSprite:createWithSpriteFrameName("shop_009.png")
            sppbg:setPosition(ccp(_x+2,_y-2))
            bgspNode:addChild(sppbg)
            --layer:addChild(sppbg)

            local btnItem = GFunc_CreateButtonP("shop_010.png", buildcallback, 1.05)
            btnItem:setPosition(ccp(_x,_y))
            menu:addChild(btnItem,0,k)
            table.insert(btnTables, btnItem)
            ritemlist[k] = {btn=btnItem,sp=sppbg}
            local _psize = btnItem:getNormalImage():getContentSize()

            --SIconMagic = "GUI_Magic.png"
            --SIconMoney = "GUI_SJ.png"
            --图片
            if info.type == RewardType_Money then
                local spbg = CCSprite:createWithSpriteFrameName(SIconMoney)
                spbg:setPosition(ccp(_psize.width/2, _psize.height/2-20))
                sppbg:addChild(spbg)
                --报酬数值
                local numberLv = GameNumbers:new(vNumberWhite)
                numberLv:setColor(ccc3(139,99,39))
                numberLv:addLayer(sppbg)
                numberLv:setPosition(ccp(_psize.width/2, _psize.height/2+20))
                numberLv:setString(info.item)
            elseif info.type == RewardType_Magic then
                local spbg = CCSprite:createWithSpriteFrameName(SIconMagic)
                spbg:setPosition(ccp(_psize.width/2, _psize.height/2-20))
                sppbg:addChild(spbg)
                --报酬数值
                local numberLv = GameNumbers:new(vNumberWhite)
                numberLv:setColor(ccc3(139,99,39))
                numberLv:addLayer(sppbg)
                numberLv:setPosition(ccp(_psize.width/2, _psize.height/2+20))
                numberLv:setString(info.item)
            elseif info.type == RewardType_Crystal then
                local spbg = CCSprite:createWithSpriteFrameName(SIconCrystal)
                spbg:setPosition(ccp(_psize.width/2, _psize.height/2-20))
                spbg:setScale(0.6)
                sppbg:addChild(spbg)
                --报酬数值
                local numberLv = GameNumbers:new(vNumberWhite)
                numberLv:setColor(ccc3(139,99,39))
                numberLv:addLayer(sppbg)
                numberLv:setPosition(ccp(_psize.width/2, _psize.height/2+20))
                numberLv:setString(info.item)
            elseif info.type == RewardType_Role then
                local crole = createRoleIcon(RoleInfos_Static[info.item])
                crole.btn:setPosition(ccp(_psize.width/2, _psize.height/2 + 20))
                crole.btn:setScale(0.8)
                crole.tlv:setVisible(false)
                sppbg:addChild(crole.btn)
            else
                local txtsp = CCLabelTTF:create(ItemList_Static[info.item].name.."*"..GetRewardItemSum, "Arial", 28, CCSizeMake(_psize.width-20, _psize.height-20), kCCTextAlignmentCenter)
                --local txtsp = CCLabelTTF:create(ItemList_Static[info.item].name, "Arial", 28, CCSizeMake(_psize.width-20, _psize.height-20))
                txtsp:setColor(ccc3(139,99,39))
                txtsp:setPosition(ccp(_psize.width/2, _psize.height/2-10))
                txtsp:setAnchorPoint(ccp(0.5,0.5))
                sppbg:addChild(txtsp)
            end

            isum = isum + 1
        end
    end
    reloadReward()

    --界面显示位置
    _parent:setPosition(ccp(DWinSize.width/2 - uiWidth/2, DWinSize.height/2 - uiHeight/2))
end

