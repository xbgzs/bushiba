-----------------------
--怪物类
------------------------
GameMonsterClass = {}
GameMonsterClass.__index = GameMonsterClass
---
function GameMonsterClass:new(id, lv)
    local self = {}
    setmetatable(self, GameMonsterClass)

    local minfo = MonsterList_Static[id]
    self.info = minfo
    for k, v in pairs(minfo) do
        self[k] = v
    end
    --name --名字
    --art   --形象
    --atk   --基础攻击力
    --hp    --基础生命值
    --atkgrop --攻击力成长
    --hpgrop  --生命成长 
    --type  --类型
    --des   --描述
    --exp   --经验值,
    --expgrop 经验值成长
    --print(minfo.art, id,lv)
    self.id = id
    self.lv = lv
    self.hpmax = self.hp --最大生命值

    self.ondeath = false

    self._parent = CCNode:create()
    --怪物形象
    self.spicon = CCSprite:createWithSpriteFrameName(string.format("%s.png",self.art))
    self.spicon:setAnchorPoint(ccp(0.5,0))
    --阴影
    self.spiconYY = CCSprite:createWithSpriteFrameName("guaiwudizuo.png")

    local shpbarbg = "jiemian_100.png"
    local shpbar =""
    if self.type == GColorType_Red then
        shpbar = "jiemian_101.png"
    elseif self.type == GColorType_Buld then
        shpbar = "jiemian_102.png"
    else
        shpbar = "jiemian_103.png"
    end
    --血条
    self.progress = GameProgressCrols:new(shpbarbg, shpbar)
    self.progress:setAnchorPoint(ccp(0.5,0))
    --self.progress:setPosition(ccp(-self.spicon:getContentSize().width/2,0))

    self._parent:addChild(self.spiconYY)
    self._parent:addChild(self.spicon)
    self._parent:addChild(self.progress._parent)

    -----buff列表
    self.bufflist = {}

    self:updateProperty()

    --self.atk=1

    return self
end
--受到攻击
function GameMonsterClass:onHurt(value, func, combo)
    --数值浮动
    --value = GFuncGameValueFloat(value,0.05)

    self.hp = self.hp - value
    if self.hp < 0 then
        self.hp = 0
    end
    self.progress:update(self.hp, true)

    local mx,my = self._parent:getPosition()
    -- 出血效果
    local fontsize = 48+(combo-1)*14
    --print("size:",fontsize, combo, mx,my)
    local txt = CCLabelTTF:create(string.format("-%d",value), "Arial", GFGetFont(fontsize))
    txt:setColor(ccc3(255,0,0))
    txt:setPosition(ccp(mx,my + self.spicon:getContentSize().width * 0.3))--self.spicon:getContentSize().width*0.4
    txt:runAction(CCSequence:createWithTwoActions(CCFadeTo:create(1.5, 200), CCCallFunc:create(function() 
        GFunc_RemoveChild(txt)
        if func then
            func()
        end
        end)))

    txt:runAction(CCMoveBy:create(1.0, ccp(rand(-20, 20), rand(100,130))))

    CCDirector:sharedDirector():getRunningScene():addChild(txt)

    if self.hp <= 0 then
        self.ondeath = true
    end
end
--是否死亡
function GameMonsterClass:isDeath()
    return self.ondeath
end
------死亡,执行动画效果
function GameMonsterClass:FuncGoDeath(func)
    --渐渐隐藏
    local alls = {self.spiconYY, self.progress._bgsp, self.progress._prosp}

    local function endfunc()
        if func then
            func()
        end
    end

    for k, info in pairs(alls) do
        local action = CCFadeOut:create(0.5)
        info:runAction(action)
    end
    local action = CCSequence:createWithTwoActions(CCFadeOut:create(0.5), CCCallFunc:create(endfunc))
    self.spicon:runAction(action)
end

--根据等级更新其属性
function GameMonsterClass:updateProperty()
    self.atkgrop = self.atkgrop or 0
    self.hpgrop = self.hpgrop or 0
    self.expgrop = self.expgrop or 0
    

    self.atk = (self.info.atk or 0) + ((self.lv or 1)-1) * self.atkgrop
    self.hp = (self.info.hp or 0) + ((self.lv or 1)-1) * self.hpgrop
    self.exp = (self.info.exp or 0) + ((self.lv or 1)-1) * self.expgrop

    --print("生命:"..self.hp.." 攻击:"..self.atk.." 经验"..self.exp.." 等级"..self.lv)
    
    self.hpmax = self.hp
    ---更新生命数值
    self.progress:setAllProgress(self.hpmax)
    self.progress:update(self.hp, true)

    ---隐藏血条
    if self.hpmax == 0 then
        self.progress:setVisible(false)
    end
end
--添加显示
function GameMonsterClass:addParent(parent, index)
    if index == nil then
        index = 0
    end
    parent:addChild(self._parent, index)
end
--设置坐标
function GameMonsterClass:setPosition(pos)
    self._pos = pos
    self._parent:setPosition(pos)
end
function GameMonsterClass:getPosition()
    -- body
    return self._pos
end
--怪物动画效果动画
function GameMonsterClass:onPlayed(func)
    --渐渐显示
    local alls = {self.spiconYY, self.progress._bgsp, self.progress._prosp}

    local function endfunc()
        if func then
            func()
        end
    end

    for k, info in pairs(alls) do
        local action = CCFadeIn:create(1.0)
        info:runAction(action)
    end
    local action = CCSequence:createWithTwoActions(CCFadeIn:create(1.0), CCCallFunc:create(endfunc))
    self.spicon:runAction(action)
end
--攻击/向前移动
function GameMonsterClass:onFight(func)
    if self._moveAct then
        self._parent:stopAction(self._moveAct)
        self._moveAct = nil
    end
    local array = CCArray:create()
    array:addObject(CCMoveBy:create(0.2,ccp(0,-10)))
    array:addObject(CCMoveTo:create(0.2,self._pos))
    self._moveAct = CCSequence:createWithTwoActions(CCSequence:create(array), CCCallFunc:create(function()
        self._moveAct = nil
        --print("移动结束")
        if func then
            func()
        end
    end))
    self._parent:runAction(self._moveAct)
end

function GameMonsterClass:newRound( ... )
    -- body
    self:updatebuff()
end

---执行buff
function GameMonsterClass:runbuff(func)
    local index = 0
    local blist = {}
    for k,buff in pairs(self.bufflist) do
        table.insert(blist, buff)
    end

    local function endbuffrun()
        if func then
            func()
        end
    end

    local function nextBuff()
        index = index + 1
        if index <= #blist then
            local buff = blist[index]
            GFuncFightSkillEff({skinfo=buff.info, taglist={self}, func=nextBuff})
        else
            endbuffrun()
        end
    end
    nextBuff()
end
function GameMonsterClass:updatebuff( ... )
    -- body
    for k,buff in pairs(self.bufflist) do
        buff.round = buff.round - 1
        if buff.round <= 0 then
            self:delbuff(buff)
        end
    end
end
function GameMonsterClass:updatebuffui( ... )
    -- body
    local index = 0
    for k, buff in pairs(self.bufflist) do
        buff.icon:setPosition(ccp(self.spicon:getContentSize().width*0.35,self.spicon:getContentSize().height*0.8 - index * 28))
        index = index + 1
    end
end
--移除buff
function GameMonsterClass:delbuff(buff)
    -- body
    if buff.icon then
        self._parent:removeChild(buff.icon, true)
    end
    self.bufflist[buff.info.eff] = nil

    self:updatebuffui()
end
----中buff
function GameMonsterClass:addbuff(skinfo)
    -- body
    local spicon = nil
    if self.bufflist[skinfo.eff] == nil then
        --生成图标
        spicon = CCSprite:createWithSpriteFrameName(GTableBuffIcon[skinfo.eff])
        self._parent:addChild(spicon)
    else
        spicon = self.bufflist[skinfo.eff].icon
    end
    local _info = {icon=spicon, info=skinfo, round=skinfo.round}
    self.bufflist[skinfo.eff] = _info
    --中了之后执行一次
    --self:runbuff()
    self:updatebuffui()
end
--是否可攻击
function GameMonsterClass:hasFight( ... )
    -- body
    for eff, einfo in pairs(self.bufflist) do
        if eff == SkillType_Sleep then
            return false
        end
    end
    return true
end





-----------------------
--角色类
------------------------
GamePlayerClass = {}
GamePlayerClass.__index = GamePlayerClass
---
function GamePlayerClass:new(rpinfo)
    local self = {}
    setmetatable(self, GamePlayerClass)

    self.info = rpinfo
    self.id = rpinfo.id
    self.type = rpinfo.type
    self.atk = rpinfo.atk
    self.baseatk = rpinfo.atk
    self.hp = rpinfo.hp
    self.lv = rpinfo.lv
    self.skill = rpinfo.skill
    ----------
    self.fcombo = 0 --连击计点
    self.fpuzsum = 0 --消除计点
    self.fskill = 0 --技能槽累积点

    --buff列表
    self.bufflist = {}

    --攻击目标
    self._fightTag = nil

    ----------------
    self._parent = CCNode:create()

    self.icon = createRoleIcon(rpinfo, GGameFightUseSkillFunc)
    local menu = CCMenu:create()
    menu:setPosition(ccp(0,0))
    menu:addChild(self.icon.btn,0 , self.id)
    self.icon.btn:setEnabled(false)
    self._parent:addChild(menu)

    self.icon.spname:setVisible(false)
    self.icon.tname:setVisible(false)

    --等级
    self.txtlv = self.icon.tlv

    --连击/消除点数
    self.uiCombo = CCLabelTTF:create(0, "Arial", 32)
    self.uiCombo:setPosition(ccp(50,15))
    self.uiPuzSum = CCLabelTTF:create(0, "Arial", 32)
    self.uiPuzSum:setPosition(ccp(50,-15))

    --是否有技能
    if self.skill then
        ----技能进度条
        self.skillprogress = GameProgressCrols:new(nil, string.format("%s.png",GTableRoleTypeBackBg[self.type]))
        self.skillprogress:setAllProgress(GFightSkillSoltValue)
        self.skillprogress:addToParent(self.icon.btn:getNormalImage())
        self.skillprogress:setPosition(ccp(0,self.icon.btn:getNormalImage():getContentSize().height/2))--ccp(-self.icon.btn:getNormalImage():getContentSize().width/2,0))
    end

    self._parent:addChild(self.uiCombo)
    self._parent:addChild(self.uiPuzSum)

    ---使用技能特效
    self.effskill = CCNode:create()
    self._parent:addChild(self.effskill)
    --上效果
    local sp = CCSprite:createWithSpriteFrameName("jiemian_164.png")
    sp:setPosition(ccp(0,30))
    self.effskill:addChild(sp)
    local arr1 = CCArray:create()
    arr1:addObject(CCMoveTo:create(0.2, ccp(0,35)))
    arr1:addObject(CCMoveTo:create(0.2, ccp(0,30)))
    local seq1 = CCSequence:create(arr1)
    sp:runAction(CCRepeatForever:create(seq1))
    --下效果
    local sp = CCSprite:createWithSpriteFrameName("jiemian_164.png")
    sp:setPosition(ccp(0,-30))
    sp:setFlipY(true)
    self.effskill:addChild(sp)
    local arr1 = CCArray:create()
    arr1:addObject(CCMoveTo:create(0.2, ccp(0,-35)))
    arr1:addObject(CCMoveTo:create(0.2, ccp(0,-30)))
    local seq1 = CCSequence:create(arr1)
    sp:runAction(CCRepeatForever:create(seq1))
    self.effskill:setVisible(false)

    self:hasUseSkill()

    --self.atk=1

    return self
end

function GamePlayerClass:addParent(parent, index)
    if index == nil then
        index = 0
    end
    parent:addChild(self._parent, index)
end

function GamePlayerClass:setPosition(pos)
    self._pos = pos
    self._parent:setPosition(pos)
end
function GamePlayerClass:hasFight( ... )
    if self.fcombo > 0 or self.fpuzsum > 0 then
        return true
    end
    return false
end
function GamePlayerClass:hasUseSkill(value)
    if value == nil then
        value = true
    end


    if self.skill then
        -- body
        if self.fskill >= GFightSkillSoltValue and value then
            self.icon.btn:setEnabled(true)
            self.icon.btn:setColor(ccc3(255,255,255))
            --self.icon.btn:getNormalImage():setColor(ccc3(255,255,255))
            self.effskill:setVisible(true)
        else
            self.icon.btn:setColor(ccc3(100,100,100))
            self.icon.btn:setEnabled(false)
            --self.icon.btn:getNormalImage():setColor(ccc3(100,100,100))
            self.effskill:setVisible(false)
        end
    end
end
--使用技能
function GamePlayerClass:useSkill()
    --print("技能使用", self.info.skill, self.fskill)
    -- body
    if self.fskill >= GFightSkillSoltValue then
        --使用技能
        self.icon.btn:setEnabled(false)
        --清0
        self:addSkill(-self.fskill)

        self:hasUseSkill()
    end
end
--每回合累积技能槽
function GamePlayerClass:addSkill(value)
    if value == nil then
        value = 1
    end

    -- body
    self.fskill = self.fskill + value
    --print("技能槽增加", value, self.fskill)
    if self.fskill >= GFightSkillSoltValue then
        self.fskill = GFightSkillSoltValue
    end

    self:UpdateUi()
end
--砖块消除,战斗计点累加
function GamePlayerClass:addCombo(fpuzsum)
    self.fcombo = self.fcombo + 1
    self.fpuzsum = self.fpuzsum + fpuzsum

    --技能槽连击累加
    self:addSkill()
end
--清除上次战斗的计点
function GamePlayerClass:newRound()
    self.fcombo = 0
    self.fpuzsum = 0
    self:UpdateUi()
    self:updatebuff()
end

---执行buff
function GamePlayerClass:runbuff(func)
    local index = 0
    local blist = {}
    for k,buff in pairs(self.bufflist) do
        table.insert(blist, buff)
    end

    local function endbuffrun()
        if func then
            func()
        end
    end

    local function nextBuff()
        index = index + 1
        if index <= #blist then
            local buff = blist[index]
            GFuncFightSkillEff({skinfo=buff.info, taglist={self}, func=nextBuff})
        else
            endbuffrun()
        end
    end
    nextBuff()
end
function GamePlayerClass:updatebuff( ... )
    -- body
    for k,buff in pairs(self.bufflist) do
        buff.round = buff.round - 1
        if buff.round <= 0 then
            self:delbuff(buff)
        end
    end
end
function GamePlayerClass:updatebuffui( ... )
    --更新buff数值
    self.atk = self.baseatk

    -- body
    local index = 0
    for k, buff in pairs(self.bufflist) do
        buff.icon:setPosition(ccp(-40 + index * 25, 45))
        index = index + 1

        if buff.info.eff == SkillType_AddUp then
            self.atk = self.atk + self.atk * (buff.info.value/100.0)
        end
    end
end
--移除buff
function GamePlayerClass:delbuff(buff)
    -- body
    if buff.icon then
        self._parent:removeChild(buff.icon, true)
    end
    self.bufflist[buff.info.eff] = nil

    self:updatebuffui()
end
----中buff
function GamePlayerClass:addbuff(skinfo)
    -- body
    local spicon = nil
    if self.bufflist[skinfo.eff] == nil then
        --生成图标
        spicon = CCSprite:createWithSpriteFrameName(GTableBuffIcon[skinfo.eff])
        self._parent:addChild(spicon)
    else
        spicon = self.bufflist[skinfo.eff].icon
    end
    --print("添加buff", self.bufflist[skinfo.eff], GTableBuffIcon[skinfo.eff])
    local _info = {icon=spicon, info=skinfo, round=skinfo.round}
    self.bufflist[skinfo.eff] = _info
    --中了之后执行一次
    --self:runbuff()
    self:updatebuffui()
end
--更新UI
function GamePlayerClass:UpdateUi()
    self.uiCombo:setString(self.fcombo)
    self.uiPuzSum:setString(self.fpuzsum)

    if self.skillprogress then
        self.skillprogress:update(self.fskill, true)
    end
end
--获取攻击目标
function GamePlayerClass:getFightTag()
    return self._fightTag
end
--设置攻击目标
function GamePlayerClass:setFightTag(_tag)
    -- body
    self._fightTag = _tag
end
--攻击/向前移动
function GamePlayerClass:onFight(func)
    if self._moveAct then
        self._parent:stopAction(self._moveAct)
        self._moveAct = nil
    end
    local array = CCArray:create()
    array:addObject(CCMoveBy:create(0.2,ccp(0,10)))
    array:addObject(CCMoveTo:create(0.2,self._pos))
    self._moveAct = CCSequence:createWithTwoActions(CCSequence:create(array), CCCallFunc:create(function()
        self._moveAct = nil
        --print("移动结束")
        if func then
            func()
        end
    end))
    self._parent:runAction(self._moveAct)
end
--获得经验效果
function GamePlayerClass:addExps(exp, func)

    local lvup = self.info:addExps(exp)
    local mx,my = self._parent:getPosition()
    --经验值数字
    self.txtexp = CCLabelTTF:create("+0", "Arial", 20)
    self.txtexp:setAnchorPoint(ccp(0,0))
    self.txtexp:setPosition(ccp(0,20))
    self._parent:addChild(self.txtexp,5)

    local function endfunc()
        --GFunc_RemoveChild(self.txtexp)
        --print("移除经验",self.id)
        if func then
            func()
        end
    end
    --print("添加经验",self.id)
    ----经验提升完成之后还要看是否提升等级
    local function endExpsadds()
        if lvup then
            local anim = nil
            local lvupsp = nil
            local function animEnd()
                endfunc()
                GFunc_RemoveChild(anim)
                GFunc_RemoveChild(lvupsp)
            end
            --等级提升动画    shengji_001
            anim = GFunc_CreateAnimation("shengji_", 2, 4, 5, nil, animEnd, 3)
            self._parent:addChild(anim)
            --向上浮动并渐渐消失的升级文字
            lvupsp = CCSprite:createWithSpriteFrameName("shengji_001.png")
            self._parent:addChild(lvupsp)

            lvupsp:runAction(CCMoveTo:create(1.5, ccp(0,30)))
            lvupsp:runAction(CCFadeOut:create(1.5))
            
            self.txtlv:setString(self.info.lv)
        else
            endfunc()
        end
    end

    --经验不断增加效果
    local lastexp = 1
    local alltime = 1.0
    local allsum = 10.0
    local mtime = alltime/allsum
    local function nextShow()
        local action = CCSequence:createWithTwoActions(CCDelayTime:create(0.1), CCCallFunc:create(function()
            local gexp = math.floor(lastexp/10.0 * exp)
            gexp = string.format("+%d exp", gexp)
            self.txtexp:setString(gexp)
            lastexp = lastexp + 1
            if lastexp > allsum then
                endExpsadds()
            else
                nextShow()
            end
        end))
        CCDirector:sharedDirector():getRunningScene():runAction(action)
    end
    nextShow()
end





function createRoleIcon(info, func)
    local sbtnfile = string.format("%s.png",GTableRoleTypeBackBg[info.type])
    local btnItem = GFunc_CreateButtonP(sbtnfile, func)
            
    local spfront = CCSprite:createWithSpriteFrameName(string.format("%s.png",GTableRoleTypeBg[info.type]))
    spfront:setPosition(ccp(0, 0))
    btnItem:getNormalImage():addChild(spfront,2)
    spfront:setPosition(ccp(btnItem:getNormalImage():getContentSize().width/2, btnItem:getNormalImage():getContentSize().height/2))
    local spfronts = CCSprite:createWithSpriteFrameName(string.format("%s.png",GTableRoleTypeBg[info.type]))
    spfronts:setPosition(ccp(0, 0))
    btnItem:getSelectedImage():addChild(spfronts,2)
    spfronts:setPosition(ccp(btnItem:getNormalImage():getContentSize().width/2, btnItem:getNormalImage():getContentSize().height/2))

    --头像
    local spicon = CCSprite:createWithSpriteFrameName(string.format("%s.png",info.art))
    spicon:setPosition(ccp(0, 0))
    btnItem:getNormalImage():addChild(spicon,1)
    spicon:setPosition(ccp(btnItem:getNormalImage():getContentSize().width/2, btnItem:getNormalImage():getContentSize().height/2))
    local spicons = CCSprite:createWithSpriteFrameName(string.format("%s.png",info.art))
    spicons:setPosition(ccp(0, 0))
    btnItem:getSelectedImage():addChild(spicons,1)
    spicons:setPosition(ccp(btnItem:getNormalImage():getContentSize().width/2, btnItem:getNormalImage():getContentSize().height/2))
    
    --名字sp
    local spname = CCSprite:createWithSpriteFrameName("jiemian_057.png")
    spname:setPosition(ccp(80, -20))
    
    --名字
    local txtname = CCLabelTTF:create(info.name, "Arial", 32)
    txtname:setPosition(ccp(80, -20))

    --等级
    local parent = CCNode:create()
    btnItem:addChild(parent)
    local txtlv = CCLabelTTF:create(string.format("%d", info.lv or 1), "Arial", 24)
    txtlv:setAnchorPoint(ccp(0.5,0))
    txtlv:setPosition(ccp(20,44))
    parent:addChild(txtlv)



    if spname then btnItem:addChild(spname) end
    if spname then btnItem:addChild(txtname) end

    return {btn=btnItem, tname=txtname, spname=spname, spicon=spicon, tlv=txtlv, spfront=spfront, spicons=spicons, spfronts=spfronts}
end









------------//////////////

-----------------------
--玩家类
------------------------
GamePlayerInfoClass = {}
GamePlayerInfoClass.__index = GamePlayerInfoClass
---
function GamePlayerInfoClass:new()
    local self = {}
    setmetatable(self, GamePlayerInfoClass)

    self.hp = PlayerInfos.hpmax
    self.hpmax = PlayerInfos.hpmax
    self.avoid = PlayerInfos.avoid
    self.baseavoid = PlayerInfos.avoid
    self.def = PlayerInfos.def
    self.lv = PlayerInfos.lv
    self.bufflist = {}


    self.fcombo = 0 --连击计点
    self.fpuzsum = 0 --消除计点
    ----------------
    self._parent = CCNode:create()

    --血条
    self.progressHp = GameProgressCrols:new(nil, "jiemian_096.png")
    self.progressHp:setAllProgress(self.hpmax)
    self.progressHp:addToParent(self._parent)
    self.progressHp:setPosition(ccp(9, 533.5))
    self.progressHp:update(self.hp,true)

    return self
end
function GamePlayerInfoClass:onHurt( value , func)
    -- body
    local function endfunc()
        if func then
            func()
        end
    end

    --数值浮动
    value = GFuncGameValueFloat(value)

        -----计算是否命中
        local hitlv = rand(1,100)
        --print(hitlv)
        local ishit = hitlv > self.avoid and true or false

        if ishit then
            ---(100-实际伤害的免伤值)/100*伤害
            local hurt = ConsertInt((100 - self.def)/100.0 * value)
            self.hp = self.hp - hurt
            if self.hp < 0 then
                self.hp = 0
            end
            --,目标受到伤害,获得伤害值
            self.progressHp:update(self.hp, true)
            --出血效果
            local txt = CCLabelTTF:create(string.format("-%d",hurt), "Arial", GFGetFont(80))
            txt:setColor(ccc3(255,0,0))
            txt:setPosition(ccp(DWinSize.width/2, 533))
            txt:runAction(CCSequence:createWithTwoActions(CCMoveBy:create(1.0, ccp(0, 50)), CCCallFunc:create(function() 
                GFunc_RemoveChild(txt)
                endfunc()
                end)))
            CCDirector:sharedDirector():getRunningScene():addChild(txt)
        else
            --MISS
            local txt = CCLabelTTF:create("MISS", "Arial", GFGetFont(80))
            txt:setPosition(ccp(DWinSize.width/2, 533))
            txt:runAction(CCSequence:createWithTwoActions(CCMoveBy:create(1.0, ccp(0, 50)), CCCallFunc:create(function() 
                GFunc_RemoveChild(txt)
                endfunc()
                end)))
            CCDirector:sharedDirector():getRunningScene():addChild(txt)
        end
end
function GamePlayerInfoClass:onTreat(value, func)
    -- body
    local function endfunc()
        if func then
            func()
        end
    end

    --数值浮动
    value = GFuncGameValueFloat(value)

    self.hp = self.hp + value
    if self.hp > self.hpmax then
        self.hp = self.hpmax
    end

    self.progressHp:update(self.hp, true)
    --恢复加血效果
    local txt = CCLabelTTF:create(string.format("+%d",value), "Arial", GFGetFont(80))
    txt:setColor(ccc3(0,255,0))
    txt:setPosition(ccp(DWinSize.width/2, 533))
    txt:runAction(CCSequence:createWithTwoActions(CCMoveBy:create(1.0, ccp(0, 50)), CCCallFunc:create(function() 
        GFunc_RemoveChild(txt)
        endfunc()
        end)))
    CCDirector:sharedDirector():getRunningScene():addChild(txt)

    ---治疗特效
    --条件闪现星星
    for k=1,40 do
        local anim = GFunc_CreateAnimation("jingbi_xiaoguo".."_", 1, 10, rand(1,3), rand(1,2)/10.0, nil, 3)
        anim:setPosition(ccp(rand(40,DWinSize.width-40), rand(515, 540)))
        CCDirector:sharedDirector():getRunningScene():addChild(anim)
    end
end
function GamePlayerInfoClass:addParent(parent)
    parent:addChild(self._parent)
end

function GamePlayerInfoClass:newRound( ... )
    self.fcombo = 0
    self.fpuzsum = 0
    -- body
    self:updatebuff()
end
---执行buff
function GamePlayerInfoClass:runbuff(func)
    local index = 0
    local blist = {}
    for k,buff in pairs(self.bufflist) do
        table.insert(blist, buff)
    end

    local function endbuffrun()
        if func then
            func()
        end
    end

    local function nextBuff()
        index = index + 1
        if index <= #blist then
            local buff = blist[index]
            GFuncFightSkillEff({skinfo=buff.info, taglist={self}, func=nextBuff})
        else
            endbuffrun()
        end
    end
    nextBuff()
end
function GamePlayerInfoClass:updatebuff( ... )
    -- body
    for k,buff in pairs(self.bufflist) do
        buff.round = buff.round - 1
        if buff.round <= 0 then
            self:delbuff(buff)
        end
    end
end
function GamePlayerInfoClass:updatebuffui( ... )
    --更新buff数值
    self.avoid = self.baseavoid

    -- body
    local index = 0
    for k, buff in pairs(self.bufflist) do
        buff.icon:setPosition(ccp(DWinSize.width- 50 - index * 25, 533))
        index = index + 1

        ---闪避增加
        if buff.info.eff == SkillType_Avoid then
            self.avoid = self.avoid + buff.info.value
        end
    end

end
--移除buff
function GamePlayerInfoClass:delbuff(buff)
    -- body
    if buff.icon then
        self._parent:removeChild(buff.icon, true)
    end
    self.bufflist[buff.info.eff] = nil

    self:updatebuffui()
end
----中buff
function GamePlayerInfoClass:addbuff(skinfo)
    -- body
    local spicon = nil
    if self.bufflist[skinfo.eff] == nil then
        --生成图标
        spicon = CCSprite:createWithSpriteFrameName(GTableBuffIcon[skinfo.eff])
        self._parent:addChild(spicon)
    else
        spicon = self.bufflist[skinfo.eff].icon
    end
    local _info = {icon=spicon, info=skinfo, round=skinfo.round}
    self.bufflist[skinfo.eff] = _info
    --中了之后执行一次
    --self:runbuff()
    self:updatebuffui()
end

---治疗砖块连击<<
function GamePlayerInfoClass:addTreatCombo(puzsum)
    self.fcombo = self.fcombo + 1
    self.fpuzsum = self.fpuzsum + puzsum
end

--治疗效果
function GamePlayerInfoClass:onTreatBrick(func)
    --治疗量=连消数*基础治疗量*(消除砖块数/3/连消数)+等级*10 浮动 10%
    local baseTreat = 100
    local lvValue = 10
    local value = 0
    if self.fcombo > 0 then
        value = self.fcombo * baseTreat * (self.fpuzsum/3/self.fcombo) + self.lv * lvValue
        value = rand(value*0.9, value*1.1)
    end
    -- body
    if value > 0 and self.hp < self.hpmax then
        self:onTreat(value, func)
    else
        if func then
            func()
        end
    end
end