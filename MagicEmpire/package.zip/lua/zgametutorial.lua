----zgametutorial --游戏教程
GTempTutorialPuzOpertion = 0x00
GTempTutorialTouch = nil
-----引导头像::::: yindaotouxiang.png

---教程临时函数
local _GFuncTutorialTempFunc = nil
function GFuncTutorialTempFunc()
	if _GFuncTutorialTempFunc then
		_GFuncTutorialTempFunc()
	end
end

local function GFuncCreateStoryLayer(eid, runEvent)
	---事件执行
	local _UIinfo = GGameRunEventStory({color=ccc4(0,0,0,0),func=function()
		if runEvent then
			runEvent()
		end
	end, eid = eid, width=460, height=200})
	if _UIinfo then
		_UIinfo.parent:setPosition(ccp(180,_UIinfo.parentY))

		---引导头像
		local iconPy = CCSprite:createWithSpriteFrameName("yindaotouxiang.png")
		iconPy:setAnchorPoint(ccp(0,0))
		iconPy:setPosition(ccp(-210,4))
		_UIinfo.parent:addChild(iconPy)
	end

	return _UIinfo
end

local function GFuncCreateTutorialLayer(args)
	local btnlist = {}
	local function touchbegin(x,y,eventType)
		local btnsel = GFunc_SelectBtnRun(btnlist,x,y,eventType)
		if GTempTutorialTouch then
			GTempTutorialTouch(x,y,eventType)
		end
	end

	if args == nil then
		args = {}
	end

	local function exitlayer()
		if args.efunc then
			args.efunc()
		end
	end

	---额外显示
	local otherlist = {}
	local parentlayer = GFunc_CreateLayerEnterOrExit({lindex=200,color=ccc4(0,0,0,150), exfunc=exitlayer,touchBegin=touchbegin,touchMoved=touchbegin,
		touchEnded=touchbegin, fmbg=true})
	CCDirector:sharedDirector():getRunningScene():addChild(parentlayer,14)
	parentlayer:setVisible(false)
	parentlayer:setTouchEnabled(false)
	local parent = CCNode:create()
	CCDirector:sharedDirector():getRunningScene():addChild(parent,16)
	local parentd = CCNode:create()
	CCDirector:sharedDirector():getRunningScene():addChild(parentd,14)
	--背景
	local bgp = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
	CCDirector:sharedDirector():getRunningScene():addChild(bgp,15)

	local menu = CCMenu:create()
	menu:setPosition(ccp(0,0))
	parent:addChild(menu)

	local function hidePLayer()
		parentlayer:setVisible(false)
		parentlayer:setTouchEnabled(false)
	end

	local function showPLayer()
		parentlayer:setVisible(true)
		parentlayer:setTouchEnabled(true)
	end

	local function closefunc(nosave)
		GFunc_RemoveChild(parentlayer)
		GFunc_RemoveChild(parent)
		GFunc_RemoveChild(bgp)

		if not nosave and args.efinsh then
			args.efinsh()
		end
	end

	--清除目前的显示
	local function clearother()
		for k,item in pairs(otherlist) do
			GFunc_RemoveChild(item)
			otherlist[k] = nil
		end
		for k,item in pairs(btnlist) do
			btnlist[k] = nil
		end
	end
	local args = {parentd=parentd,parent=parent,clearother=clearother,hidePLayer=hidePLayer, showPLayer=showPLayer, 
		parentlayer = parentlayer, closefunc=closefunc,otherlist=otherlist,btnlist=btnlist, touchbegin=touchbegin,bgp = bgp, menu=menu}
	return args
end

--游戏开始介绍说明
local function tutorialGameInit(args)
	local index = 1
	local evtlist = {1001, 1002, 1003, 1004, 1005, 1006, 1007}

	---
	local tutorialLayer = GFuncCreateTutorialLayer(args)

	local function runEvent()
		if index <= #evtlist then
			local eid = evtlist[index]
			---事件执行
			local _UIinfo = GFuncCreateStoryLayer(eid, runEvent)
			tutorialLayer.bgp:setVisible(true)

			if index == 1 then

			elseif index == 2 then
				_UIinfo.parent:setPositionY(_UIinfo.parentY+200)

				tutorialLayer.parentlayer:setVisible(true)
				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)
				--显示邮箱,并且显示相应的数字
				--邮箱/任务
			    local btnItem = GFunc_CreateButtonP("jiemian_018.png", function()
			        createLayerTaskMenu(function()
			        end)
			        GFuncClickEventStory()
			    end,nil,1.5)
			    btnItem:setPosition(ccp(150, 60))
			    menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist,btnItem)
			    ----任务数显示 GGameFuncGetTaskCount
			    local spTaskSBG = CCSprite:createWithSpriteFrameName("jiemian_136.png")
			    spTaskSBG:setPosition(ccp(85,85))
			    btnItem:addChild(spTaskSBG)

			    local txtTaskSum = CCLabelTTF:create("", "Arial", 28)
			    txtTaskSum:setPosition(ccp(85,85))
			    btnItem:addChild(txtTaskSum)

			    if GGameFuncGetTaskCount() > 0 then
		            spTaskSBG:setVisible(true)
		            txtTaskSum:setVisible(true)
		            txtTaskSum:setString(GGameFuncGetTaskCount())
		        else
		            spTaskSBG:setVisible(false)
		            txtTaskSum:setVisible(false)
		        end
		   	elseif index == 3 then
				_UIinfo.parent:setPositionY(_UIinfo.parentY+200)
		   		--开启操作,点击邮箱
				tutorialLayer.showPLayer()
			elseif index == 4 then
				tutorialLayer.clearother()
				--任务说明
				tutorialLayer.hidePLayer()
				tutorialLayer.bgp:setVisible(false)
			elseif index == 5 then
				--点击任务
				tutorialLayer.parentlayer:setTouchEnabled(true)--showPLayer()
				tutorialLayer.bgp:setVisible(false)

				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)

				local btnItem = GFunc_CreateButtonLabel("", function()
					GShowDialogTaskMessage({tid=1061})
					GFuncClickEventStory()
				end, nil, CCSizeMake(530, 70))
	            btnItem:setPosition(ccp(DWinSize.width/2, 680))
	            menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist, btnItem)
			elseif index == 6 then
				--显示任务
				tutorialLayer.clearother()
				--任务说明
				tutorialLayer.hidePLayer()
				_UIinfo.parent:setPositionY(_UIinfo.parentY)
				tutorialLayer.bgp:setVisible(false)
			elseif index == 7 then
				--接受任务
				_UIinfo.parent:setPositionY(_UIinfo.parentY)

				tutorialLayer.parentlayer:setTouchEnabled(true)

				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)
				--显示邮箱,并且显示相应的数字
				--邮箱/任务
		        local btnItem = GFunc_CreateButtonP("jiemian_099.png", function()
		        	GFuncClickEventStory(x,y,CCTOUCHENDED)
		        	--GFuncAcceptTask(1061)
		        	TutorialTaskRun(TStep2)
		        end,nil,1.5)
		        btnItem:setPosition(ccp(DWinSize.width/2, 242.5))
		        menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist,btnItem)
			end
			--print(index)
		else
			GFuncAcceptTask(1061)
			--关闭
			tutorialLayer.closefunc()
			--关闭所有窗口
			GGameFuncCloseAllInterface()
		end
		index = index + 1
	end
	runEvent()
end

--及建造魔法屋
local function buildMagicHouse(args)
	local index = 1
	local evtlist = {1008, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017}

	---
	local tutorialLayer = GFuncCreateTutorialLayer(args)

	local function runEvent()
		if index <= #evtlist then
			local eid = evtlist[index]
			---事件执行
			local _UIinfo = GFuncCreateStoryLayer(eid, runEvent)
			tutorialLayer.bgp:setVisible(true)

			if index == 1 then
			elseif index == 2 then
				_UIinfo.parent:setPositionY(_UIinfo.parentY+200)

				tutorialLayer.showPLayer()
				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)

			  	local btnItem = GFunc_CreateButtonP("jiemian_016.png", function()
			        createLayerBuildMenu(function()
			        end)

			        GFuncClickEventStory()
			    end,nil,1.5)
			    btnItem:setPosition(ccp(DWinSize.width - 60, 60))
			    menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist,btnItem)
			elseif index == 3 then
				tutorialLayer.hidePLayer()
				tutorialLayer.clearother()
				tutorialLayer.bgp:setVisible(false)

				_UIinfo.parent:setPositionY(_UIinfo.parentY)
			elseif index == 4 then
				--点击任务
				tutorialLayer.parentlayer:setTouchEnabled(true)--showPLayer()
				tutorialLayer.bgp:setVisible(false)

				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)

				local btnItem = GFunc_CreateButtonLabel("", function()
					GFunc_ShowBulidList(2)
					GGameFuncCloseAllInterface()
					GFuncClickEventStory()

					tutorialLayer.hidePLayer()
				end, nil, CCSizeMake(215, 215))
	            btnItem:setPosition(ccp(200, 575))
	            menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist, btnItem)

				---遮挡效果
				--上
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setPosition(ccp(0,685))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--左
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(85,220))
				templayer:setPosition(ccp(0,465))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--右
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(500,220))
				templayer:setPosition(ccp(310,465))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--下
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(640,465))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)

				_UIinfo.parent:setPositionY(_UIinfo.parentY)
			elseif index == 5 then
				tutorialLayer.clearother()
				tutorialLayer.bgp:setVisible(false)
				_UIinfo.parent:setPositionY(_UIinfo.parentY)
			elseif index == 6 then
				tutorialLayer.parentlayer:setTouchEnabled(true)
				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)

				local mapid = 2
				local build = 2
				local info = MapInfos_Static[mapid]
				local binfo = GFuncGetTableBuilds()[build]

				--设置地图显示在中间
				GameFuncGetCityViewPos(ccp(-150,0))

				--获得地图显示位置
				local vpx, vpy = GameFuncGetCityViewPos()
				---显示临时建筑
				local btnItem = GFunc_CreateButtonP(string.format("%s.png","map_003"), function(tag)
                    ---开始建造建筑
                    local cbuild = GGameCityNewBuild(build, mapid)

                    ----建造进度显示
                    cbuild:onBuild()

                    --教程时设置一个比较短的时间
                    cbuild._buildalltime = 4
                	cbuild.progress:setAllProgress(cbuild._buildalltime)

                    --扣除建造费用
                    PlayerInfos:addMoney(-binfo.money)

                    --取消所有临时显示建筑
                    GFunc_hideBuildList()

                    GFuncClickEventStory()

                    tutorialLayer.clearother()
                end)
                --btnItem:setOpacity(255)
                btnItem:setPosition(ccp(vpx + info.x + btnItem:getNormalImage():getContentSize().width/2, vpy + DWinSize.height - info.y + btnItem:getNormalImage():getContentSize().height/2))
             	menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
             	table.insert(tutorialLayer.btnlist, btnItem)
           	elseif index == 7 then
           		--等级建造完成
           		GGamePause = false

           		---临时函数,建造完成传递进来
           		_GFuncTutorialTempFunc = function()
           			GGamePause = true
           			--用完后要清空
           			_GFuncTutorialTempFunc = nil

           			--完成建造
           			GFuncClickEventStory()
           		end
           		---
           		--tutorialLayer.hidePLayer()
           		tutorialLayer.bgp:setVisible(false)
           	elseif index == 8 then
				_UIinfo.parent:setPositionY(_UIinfo.parentY+200)

           		tutorialLayer.parentlayer:setTouchEnabled(true)
           		----去领取任务报酬
				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)
				--显示邮箱,并且显示相应的数字
				--邮箱/任务
			    local btnItem = GFunc_CreateButtonP("jiemian_018.png", function()
			        createLayerTaskMenu(function()
			        end)
			        GFuncClickEventStory()
			    end,nil,1.5)
			    btnItem:setPosition(ccp(150, 60))
			    menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist,btnItem)
			elseif index == 9 then
				---
				tutorialLayer.clearother()
				--点击任务
				tutorialLayer.parentlayer:setTouchEnabled(true)--showPLayer()
				tutorialLayer.bgp:setVisible(false)

				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)

				local btnItem = GFunc_CreateButtonLabel("", function()
					GShowDialogTaskMessage({tid=1061})
					GFuncClickEventStory()
				end, nil, CCSizeMake(530, 70))
	            btnItem:setPosition(ccp(DWinSize.width/2, 680))
	            menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist, btnItem)
			elseif index == 10 then
				tutorialLayer.clearother()
				--领取奖励
				_UIinfo.parent:setPositionY(_UIinfo.parentY)
				tutorialLayer.parentlayer:setTouchEnabled(true)
				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)
				--显示邮箱,并且显示相应的数字
		        local btnItem = GFunc_CreateButtonP("ictgetr.png", function()
		        	PlayerInfos:onFinshTask(1061, function()
                            --print("----")
                            --开始下一段教程
                           	TutorialTaskRun(TStep3)
                        end)
		        	GFuncClickEventStory()
		        end,nil,1.5)
		        btnItem:setPosition(ccp(DWinSize.width/2, 242.5))
		        menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist,btnItem)
			end
		else
			--开始研究铁的任务
			--GFuncAcceptTask(1062)
			--关闭
			tutorialLayer.closefunc()
			--关闭所有窗口
			GGameFuncCloseAllInterface()
		end
		index = index + 1
	end
	runEvent()
end

--研究道具,快速完成功能
local function buildYanjiuFirstBtn(args)
	local index = 1
	local evtlist = {1018, 1019, 1020, 1021, 1022, 1023, 1024, 1025}

	---
	local tutorialLayer = GFuncCreateTutorialLayer(args)

	local function runEvent()
		if index <= #evtlist then
			local eid = evtlist[index]
			---事件执行
			local _UIinfo = GFuncCreateStoryLayer(eid, runEvent)
			tutorialLayer.bgp:setVisible(true)

			if index == 2 then--点击[魔法屋]
				tutorialLayer.parentlayer:setTouchEnabled(true)
				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)

				local mapid = 2
				local build = 2
				local info = MapInfos_Static[mapid]
				local binfo = GFuncGetTableBuilds()[build]

				--设置地图显示在中间
				GameFuncGetCityViewPos(ccp(-150,0))

				--error:::测试用,添加一个研究屋
				if PlayerInfos:getAllBuildInfos()[mapid] == nil then
					GGameCityNewBuild(build, mapid)
				end
				--测试用[铁]
				if PlayerInfos:getItem(2) == 0 then
					PlayerInfos:addItems(2)
				end
				--error::

				--获得地图显示位置
				local vpx, vpy = GameFuncGetCityViewPos()
				---显示临时建筑
				local btnItem = GFunc_CreateButtonP(string.format("%s.png","map_003"), function()
                	GShowBuildInfos({info=PlayerInfos:getAllBuildInfos()[mapid], endfunc=function()

                    end})
                    GFuncClickEventStory()
                end)
                btnItem:setPosition(ccp(vpx + info.x + btnItem:getNormalImage():getContentSize().width/2, vpy + DWinSize.height - info.y + btnItem:getNormalImage():getContentSize().height/2))
             	menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
             	table.insert(tutorialLayer.btnlist, btnItem)
            elseif index == 3 then --点击[研究
            	tutorialLayer.clearother()
				--领取奖励
				_UIinfo.parent:setPositionY(_UIinfo.parentY)
				tutorialLayer.parentlayer:setTouchEnabled(true)
				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)
				--显示邮箱,并且显示相应的数字
				local btnItem = GFunc_CreateButtonP("jiemian_036.png", function(tag)
			        createLayerYanJiuMenu(PlayerInfos:getAllBuildInfos()[mapid], function()
			        	
			        	--关闭界面,重新显示
			        	--GGameFuncCloseAllInterface()
			            --GShowBuildInfos({info=PlayerInfos:getAllBuildInfos()[mapid], endfunc=function()
                    	--end})
			        end)
			        tutorialLayer.clearother()
			      	GFuncClickEventStory()
				end,nil, 1.2)
				btnItem:setPosition(ccp(DWinSize.width/2, 332.5))
		        menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist,btnItem)
			elseif index == 4 then --研发界面描述
				_UIinfo.parent:setPositionY(_UIinfo.parentY)
				tutorialLayer.bgp:setVisible(false)
				tutorialLayer.hidePLayer()
			elseif index == 5 then --研究[铁]
				_UIinfo.parent:setPositionY(_UIinfo.parentY)
				--领取奖励
				tutorialLayer.bgp:setVisible(false)
				tutorialLayer.parentlayer:setTouchEnabled(true)
				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)
				--显示邮箱,并且显示相应的数字
				local btnItem = GFunc_CreateButtonLabel("", function()
	                _UIinfo.layer:setTouchEnabled(false)
	                local itemID = 2--铁
	             	local iteminfo = {info=ItemList_Static[itemID], sum=PlayerInfos:getItem(2)}
					local function enddialogclose(_args)
	                    _UIinfo.layer:setTouchEnabled(true)
	                    --
	                    local buildInfos = PlayerInfos:getAllBuildInfos()[2]
	                    if _args.enter then
	                        buildInfos:YanjiuBegin(itemID)
	                   		--扣除相应的魔法点数
	                    	PlayerInfos:addMagic(-(iteminfo.info.magic or 0))
	                    end

	                    ---
                    	GFuncClickEventStory()
			        	--关闭界面,重新显示
			        	GGameFuncCloseAllInterface()
			            GShowBuildInfos({info=buildInfos, endfunc=function()
                    	end})
	                end
	                --GFunc_ShowDialogEnterClance({msg=string.format("开始研究\n%s",iteminfo.info.name), func=enddialogclose})
	                enddialogclose({enter=true})
				end, nil, CCSizeMake(500, 80))
	            btnItem:setPosition(ccp(DWinSize.width/2, 685))
	            menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist,btnItem)
			elseif index == 6 then --介绍
				_UIinfo.parent:setPositionY(_UIinfo.parentY+600)
				GGamePause = false
	         	tutorialLayer.clearother()
	         	tutorialLayer.hidePLayer()
	         	tutorialLayer.bgp:setVisible(false)
			elseif index ==  7 then --立即完成
				_UIinfo.parent:setPositionY(_UIinfo.parentY+600)
				--tutorialLayer.bgp:setVisible(false)
				tutorialLayer.parentlayer:setTouchEnabled(true)
				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)
				--立即完成按钮
				local buildInfos = PlayerInfos:getAllBuildInfos()[2]
			    btnItem = GFunc_CreateButtonP("jiemian_070.png", function(tag)
			        buildInfos:YanjiuEnd(true)
			        GGamePause = true
			        GFuncClickEventStory()

			        --关闭奖励对话框
			        GFunc_RemoveChild(GFInterface_MessageDialog)
			        tutorialLayer.hidePLayer()
			        tutorialLayer.clearother()
			        end,nil, 1.2)
			    btnItem:setPosition(ccp(DWinSize.width/2, 214))
			    menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist,btnItem)
			end
		else
			--关闭
			tutorialLayer.closefunc()
			--关闭所有窗口
			GGameFuncCloseAllInterface()

			--获得研究物品
			GFunc_ShowGameDialogMessage({msg=string.format("[%s] 的研究完成啦\n 获得了 [%s]x1", "铁", "匕首"),
     	    	func = function()
     	    		if hasfinshTutorial(TStep3) and not hasfinshTutorial(TStep4) then
     	    			TutorialTaskRun(TStep4)
     	    		end
     	    	end})
		end
		index = index + 1
	end
	runEvent()
end

---建造商店,添加商品
local function buildGameShop(args)
	local index = 1
	local evtlist = {1026,1027,1028,1029,1030,1031,1032,1033,1034,1035}

	---
	local tutorialLayer = GFuncCreateTutorialLayer(args)

	local function runEvent()
		if index <= #evtlist then
			local eid = evtlist[index]
			---事件执行
			local _UIinfo = GFuncCreateStoryLayer(eid, runEvent)
			tutorialLayer.bgp:setVisible(true)

			
			if index == 2 then
				_UIinfo.parent:setPositionY(_UIinfo.parentY+200)
				tutorialLayer.showPLayer()
				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)

			  	local btnItem = GFunc_CreateButtonP("jiemian_016.png", function()
			        createLayerBuildMenu(function()
			        end)

			        GFuncClickEventStory()
			    end,nil,1.5)
			    btnItem:setPosition(ccp(DWinSize.width - 60, 60))
			    menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist,btnItem)
			elseif index == 3 then
				tutorialLayer.clearother()
				--点击任务
				tutorialLayer.parentlayer:setVisible(false)
				tutorialLayer.parentlayer:setTouchEnabled(true)--showPLayer()
				tutorialLayer.bgp:setVisible(false)

				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)

				local btnItem = GFunc_CreateButtonLabel("", function()
					GFunc_ShowBulidList(3)
					GGameFuncCloseAllInterface()
					tutorialLayer.hidePLayer()
					GFuncClickEventStory()
				end, nil, CCSizeMake(215, 215))
	            btnItem:setPosition(ccp(440, 575))
	            menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist, btnItem)

				---遮挡效果
				--上
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setPosition(ccp(0,685))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--右
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(85,220))
				templayer:setPosition(ccp(DWinSize.width-85,465))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--左
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(330,220))
				templayer:setPosition(ccp(0,465))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--下
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(640,465))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)

				_UIinfo.parent:setPositionY(_UIinfo.parentY)
			elseif index == 4 then
				tutorialLayer.clearother()
				_UIinfo.parent:setPositionY(_UIinfo.parentY)
				tutorialLayer.parentlayer:setTouchEnabled(true)

				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)

				local mapid = 3
				local build = 3
				local info = MapInfos_Static[mapid]
				local binfo = GFuncGetTableBuilds()[build]

				--设置地图显示在中间
				GameFuncGetCityViewPos(ccp(-150,0))

				--获得地图显示位置
				local vpx, vpy = GameFuncGetCityViewPos()
				---显示临时建筑
				local btnItem = GFunc_CreateButtonP(string.format("%s.png","map_005"), function(tag)
                    ---开始建造建筑
                    local cbuild = GGameCityNewBuild(build, mapid)

                    ----建造进度显示
                    cbuild:onBuild()

                    --教程时设置一个比较短的时间
                    cbuild._buildalltime = 4
                	cbuild.progress:setAllProgress(cbuild._buildalltime)

                    --扣除建造费用
                    PlayerInfos:addMoney(-binfo.money)

                    --取消所有临时显示建筑
                    GFunc_hideBuildList()

                    GFuncClickEventStory()
                end)
                btnItem:setPosition(ccp(vpx + info.x + btnItem:getNormalImage():getContentSize().width/2, vpy + DWinSize.height - info.y + btnItem:getNormalImage():getContentSize().height/2))
             	menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
             	table.insert(tutorialLayer.btnlist, btnItem)
            elseif index == 5 then
            	tutorialLayer.clearother()

              	_UIinfo.parent:setPositionY(_UIinfo.parentY)

           		--等级建造完成
           		GGamePause = false

           		---临时函数,建造完成传递进来
           		_GFuncTutorialTempFunc = function()
           			GGamePause = true
           			--用完后要清空
           			_GFuncTutorialTempFunc = nil
           			--完成建造
           			GFuncClickEventStory()
           		end
           		tutorialLayer.bgp:setVisible(false)
           	elseif index == 6 then--点击[商店]
				tutorialLayer.parentlayer:setTouchEnabled(true)
				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)

				local mapid = 3
				local build = 3
				local info = MapInfos_Static[mapid]
				local binfo = GFuncGetTableBuilds()[build]

				--设置地图显示在中间
				GameFuncGetCityViewPos(ccp(-150,0))

				--error:::测试用,
				if PlayerInfos:getAllBuildInfos()[mapid] == nil then
					GGameCityNewBuild(build, mapid)
				end
				--测试用[铁]
				if PlayerInfos:getItem(48) == 0 then
					PlayerInfos:addItems(48)
				end

				--获得地图显示位置
				local vpx, vpy = GameFuncGetCityViewPos()
				---显示临时建筑
				local btnItem = GFunc_CreateButtonP(string.format("%s.png","map_005"), function()
                	GShowBuildInfos({info=PlayerInfos:getAllBuildInfos()[mapid], endfunc=function()

                    end})
                    GFuncClickEventStory()
                end)
                btnItem:setPosition(ccp(vpx + info.x + btnItem:getNormalImage():getContentSize().width/2, vpy + DWinSize.height - info.y + btnItem:getNormalImage():getContentSize().height/2))
             	menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
             	table.insert(tutorialLayer.btnlist, btnItem)
            elseif index == 7 then --点击[添加商品
            	tutorialLayer.clearother()
				--领取奖励
				tutorialLayer.parentlayer:setVisible(false)
				tutorialLayer.parentlayer:setTouchEnabled(true)--showPLayer()
				tutorialLayer.bgp:setVisible(false)

				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)

				local btnItem = GFunc_CreateButtonLabel("", function()
					GTutorShopClickItem(1)
					GFuncClickEventStory()
				end, nil, CCSizeMake(600, 80))
	            btnItem:setPosition(ccp(320, 380))
	            menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist, btnItem)
			elseif index == 8 then --
				tutorialLayer.hidePLayer()
				tutorialLayer.bgp:setVisible(false)
			elseif index == 9 then
            	tutorialLayer.clearother()
				tutorialLayer.parentlayer:setVisible(false)
				tutorialLayer.parentlayer:setTouchEnabled(true)--showPLayer()
				tutorialLayer.bgp:setVisible(false)

				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)

				local btnItem = GFunc_CreateButtonLabel("", function()
					GFuncClickEventStory()
					GTutorShopSelectEnd()
				end, nil, CCSizeMake(600, 80))
	            btnItem:setPosition(ccp(320, 568))
	            menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist, btnItem)
			elseif index == 10 then
            	tutorialLayer.clearother()
            	tutorialLayer.hidePLayer()
            	tutorialLayer.bgp:setVisible(false)
				_UIinfo.parent:setPositionY(_UIinfo.parentY)
			end
		else
			--添加消除判断任务
			GFuncAddNewTask(1065)
			--
			TutorialTaskRun(TStep5)
			--关闭
			tutorialLayer.closefunc()
			--关闭所有窗口
			GGameFuncCloseAllInterface()
		end
		index = index + 1
	end
	runEvent()
end

--出征相关教程
local function tutorFightTask(args)
	local index = 1
	local evtlist = {}--{1036,1037,1038,1038}
	for k=1036,1049 do
		table.insert(evtlist, k)
		print(k)
	end
	print(#evtlist)
	---
	local tutorialLayer = GFuncCreateTutorialLayer(args)

	local function runEvent()
		if index <= #evtlist then
			local eid = evtlist[index]
			---事件执行
			local _UIinfo = GFuncCreateStoryLayer(eid, runEvent)
			tutorialLayer.bgp:setVisible(true)

			if index == 1 then
				_UIinfo.parent:setPositionY(_UIinfo.parentY+200)

				tutorialLayer.showPLayer()
				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)
				--显示邮箱,并且显示相应的数字
				--邮箱/任务
			    local btnItem = GFunc_CreateButtonP("jiemian_018.png", function()
			        GFuncClickEventStory()
			        createLayerTaskMenu()
			    end,nil,1.5)
			    btnItem:setPosition(ccp(150, 60))
			    menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist,btnItem)
			    ----任务数显示 GGameFuncGetTaskCount
			    local spTaskSBG = CCSprite:createWithSpriteFrameName("jiemian_136.png")
			    spTaskSBG:setPosition(ccp(85,85))
			    btnItem:addChild(spTaskSBG)

			    local txtTaskSum = CCLabelTTF:create("", "Arial", 28)
			    txtTaskSum:setPosition(ccp(85,85))
			    btnItem:addChild(txtTaskSum)

			    if GGameFuncGetTaskCount() > 0 then
		            spTaskSBG:setVisible(true)
		            txtTaskSum:setVisible(true)
		            txtTaskSum:setString(GGameFuncGetTaskCount())
		        else
		            spTaskSBG:setVisible(false)
		            txtTaskSum:setVisible(false)
		        end
		   	elseif index == 2 then
		   		tutorialLayer.clearother()
		   		tutorialLayer.parentlayer:setVisible(false)
				--点击任务
				tutorialLayer.parentlayer:setTouchEnabled(true)--showPLayer()
				tutorialLayer.bgp:setVisible(false)

				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)

				local btnItem = GFunc_CreateButtonLabel("", function()
					GFuncClickEventStory()
					GShowDialogTaskMessage({tid=1065})
				end, nil, CCSizeMake(530, 70))
	            btnItem:setPosition(ccp(DWinSize.width/2, 680))
	            menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist, btnItem)
			elseif index == 3 then
				--显示任务
				tutorialLayer.clearother()
				--任务说明
				tutorialLayer.hidePLayer()
				_UIinfo.parent:setPositionY(_UIinfo.parentY)
				tutorialLayer.bgp:setVisible(false)
			elseif index == 4 then
				--接受任务
				_UIinfo.parent:setPositionY(_UIinfo.parentY)

				tutorialLayer.parentlayer:setTouchEnabled(true)

				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)

		        local btnItem = GFunc_CreateButtonP("jiemian_099.png", function()
		        	GGamePause = false
		        	GFuncAcceptTask(1065)
		        	tutorialLayer.hidePLayer()
		        	GGameFuncCloseAllInterface()
		        	tutorialLayer.bgp:setVisible(false)
		        	tutorialLayer.clearother()
		        	_UIinfo.parent:setVisible(false)

		        	local layerTemp = GFunc_CreateLayerEnterOrExit({update=function()
		        		if not GEvtHasonRunGameEventStory() and #GEvtGTableEventTables() <= 0 then
		        			_UIinfo.clicklast()
		        		end
		        	end, fps=0.5})
		        	_UIinfo.parent:addChild(layerTemp)
		        end,nil,1.5)
		        btnItem:setPosition(ccp(DWinSize.width/2, 242.5))
		        menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist,btnItem)
			elseif index == 6 then
				_UIinfo.parent:setPositionY(_UIinfo.parentY+200)

				tutorialLayer.showPLayer()
				local menu = CCNode:create()
				tutorialLayer.parent:addChild(menu)
				--出征
				local btnItem = GFunc_CreateButtonP("jiemian_017.png", function()
			        GFuncClickEventStory()
			        GameFuncHideCity()
			        createLayerGoFight(function()
			            GameFuncShowCity()
			        end)

			        tutorialLayer.hidePLayer()
			        tutorialLayer.clearother()
			    end,nil,1.5)
   				btnItem:setPosition(ccp(60, 150))
			    menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist,btnItem)
			elseif index == 8 then
				---地图
				tutorialLayer.bgp:setVisible(false)
				--黑掉下面的部分
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(DWinSize.width, DWinSize.height - 315))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
			elseif index == 9 then
				--tutorialLayer.bgp:setVisible(false)
				tutorialLayer.clearother()

				local menu = CCNode:create()
				tutorialLayer.parent:addChild(menu)
				--移动
				local btnItem = GFunc_CreateButtonP("jiemian_111.png")
			    btnItem:setPosition(ccp(70, 670))
			    menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist,btnItem)
			elseif index == 10 then
				_UIinfo.parent:setPositionY(_UIinfo.parentY+700)
				----出征列表
				tutorialLayer.clearother()
				tutorialLayer.hidePLayer()
				tutorialLayer.bgp:setVisible(false)
				--黑掉上面的部分
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(DWinSize.width, 315))
				templayer:setPosition(ccp(0,DWinSize.height - 315))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
			elseif index == 11 then
				tutorialLayer.bgp:setVisible(false)
				tutorialLayer.parentlayer:setTouchEnabled(true)
				local menu = CCNode:create()
				tutorialLayer.parent:addChild(menu)

				local btnItem = GFunc_CreateButtonLabel("", function()
					GFuncClickEventStory()
					GFuncTutorialGoSelect(1)
				end, nil, CCSizeMake(530, 80))
	            btnItem:setPosition(ccp(DWinSize.width/2, 580))
	            menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist, btnItem)
			elseif index == 12 then
				tutorialLayer.hidePLayer()
				tutorialLayer.bgp:setVisible(false)
				tutorialLayer.clearother()
			elseif index == 13 then
				tutorialLayer.bgp:setVisible(false)
				_UIinfo.parent:setPositionY(_UIinfo.parentY+350)
			elseif index == 14 then
				tutorialLayer.showPLayer()
				local menu = CCNode:create()
				tutorialLayer.parent:addChild(menu)
				--出征
			    local btnItem = GFunc_CreateButtonP("jiemian_120.png", function()
			    	GFuncTutorialGoFight()
			    	---结束
			    	GFuncClickEventStory()
			    end)
			    btnItem:setPosition(ccp(DWinSize.width-170, 350))
			    menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist,btnItem)
			end
		else
			--关闭
			tutorialLayer.closefunc()
			--关闭所有窗口
			GGameFuncCloseAllInterface()
		end
		index = index + 1
	end
	runEvent()
end


--战斗教程
local function tutorFight(args)
	local index = 1
	local evtlist = {}--{1036,1037,1038,1038}
	for k=1050,1064 do
		table.insert(evtlist, k)
	end
	---
	local tutorialLayer = GFuncCreateTutorialLayer(args)

	local function runEvent()
		if index <= #evtlist then
			local eid = evtlist[index]
			---事件执行
			local _UIinfo = GFuncCreateStoryLayer(eid, runEvent)
			tutorialLayer.bgp:setVisible(true)
			if index == 1 then

			elseif index == 2 then
				tutorialLayer.bgp:setVisible(false)
				--黑掉下面的部分
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(DWinSize.width, DWinSize.height - 332))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
			elseif index == 2 then
				tutorialLayer.bgp:setVisible(false)
			elseif index == 3 then
				tutorialLayer.bgp:setVisible(false)
			elseif index == 4 then
				--550
				tutorialLayer.clearother()
				tutorialLayer.bgp:setVisible(false)
				--黑掉下面的部分
				--上
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setPosition(ccp(0,628))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--下
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(DWinSize.width, 550))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
			elseif index == 5 then
				tutorialLayer.clearother()
				--520
				tutorialLayer.bgp:setVisible(false)
				--上
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setPosition(ccp(0,550))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--下
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(DWinSize.width, 520))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
			elseif index == 6 then
				tutorialLayer.clearother()
				_UIinfo.parent:setPositionY(_UIinfo.parentY + 550)
				--520
				tutorialLayer.bgp:setVisible(false)
				--上
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setPosition(ccp(0,520))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
			elseif index == 7 then
				tutorialLayer.clearother()
				_UIinfo.parent:setPositionY(_UIinfo.parentY + 650)
				--520
				tutorialLayer.bgp:setVisible(false)
				--上
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setPosition(ccp(0,628))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
			elseif index == 8 then
				tutorialLayer.parentlayer:setTouchEnabled(true)
				_UIinfo.parent:setPositionY(_UIinfo.parentY + 650)
				--520
				tutorialLayer.bgp:setVisible(false)
				_UIinfo.layer:setTouchEnabled(false)

				GTempTutorialTouch = function(x,y,eventType)
					--print(x,y,eventType)
					GFuncTutorialPuzGameLayer.onTouch(x,y,eventType)
				end
				---显示一个手指移动的动画
				GTempTutorialPuzOpertion	= 0x01
				GTempTutorialFight1 = function( ... )
					GTempTutorialTouch = nil
					-- body
					tutorialLayer.clearother()
					tutorialLayer.hidePLayer()
					GTempTutorialFight1 = nil
					_UIinfo.layer:setVisible(false)
					GTempTutorialFight2 = function()
						GFuncClickEventStory()
						--新回合
						GTempTutorialFight2 = nil
					end
				end

				---指示线
				local tipDashed = GameDashedDynamic:new("res/dashed.png", 18, ccp(370,70), ccp(270-5,70))
            	tutorialLayer.parentd:addChild(tipDashed._parent)
			    table.insert(tutorialLayer.otherlist, tipDashed._parent)
				local tipDashed = GameDashedDynamic:new("res/dashed.png", 18, ccp(270,70), ccp(270,470))
            	tutorialLayer.parentd:addChild(tipDashed._parent)
			    table.insert(tutorialLayer.otherlist, tipDashed._parent)

			    local spj = CCSprite:createWithSpriteFrameName("jiaocheng_002.png")
			    spj:setPosition(ccp(370, 70))
            	tutorialLayer.parentd:addChild(spj)
			    table.insert(tutorialLayer.otherlist, spj)
			    local spj = CCSprite:createWithSpriteFrameName("jiaocheng_002.png")
			    spj:setPosition(ccp(270, 470))
            	tutorialLayer.parentd:addChild(spj)
			    table.insert(tutorialLayer.otherlist, spj)
				---------不需要操作的砖块变暗
				--左
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(220,520))
				templayer:setPosition(ccp(0,0))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--右
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(500,120))
				templayer:setPosition(ccp(420,0))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--右下
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setPosition(ccp(320,120))
				templayer:setContentSize(CCSizeMake(320,400))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--下
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setPosition(ccp(220,0))
				templayer:setContentSize(CCSizeMake(200,20))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
			elseif index == 9 then
				tutorialLayer.bgp:setVisible(false)
			elseif index == 10 then
				tutorialLayer.bgp:setVisible(false)
				_UIinfo.parent:setPositionY(_UIinfo.parentY + 650)
			elseif index == 11 then
				tutorialLayer.parentlayer:setTouchEnabled(true)
				_UIinfo.parent:setPositionY(_UIinfo.parentY + 650)
				--520
				tutorialLayer.bgp:setVisible(false)
				_UIinfo.layer:setTouchEnabled(false)

				GTempTutorialTouch = function(x,y,eventType)
					GFuncTutorialPuzGameLayer.onTouch(x,y,eventType)
				end
				---显示一个手指移动的动画
				GTempTutorialPuzOpertion	= 0x02
				GTempTutorialFight1 = function( ... )
					-- body
					tutorialLayer.clearother()
					tutorialLayer.hidePLayer()
					GTempTutorialFight1 = nil
					GTempTutorialTouch = nil
					_UIinfo.layer:setVisible(false)
					GTempTutorialFight2 = function()
						GFuncClickEventStory()
						--新回合
						GTempTutorialFight2 = nil
					end
				end

				---指示线
				local tipDashed = GameDashedDynamic:new("res/dashed.png", 18, ccp(470,370), ccp(470,270))
            	tutorialLayer.parentd:addChild(tipDashed._parent)
			    table.insert(tutorialLayer.otherlist, tipDashed._parent)
			    
			    local spj = CCSprite:createWithSpriteFrameName("jiaocheng_002.png")
			    spj:setPosition(ccp(470, 370))
            	tutorialLayer.parentd:addChild(spj)
			    table.insert(tutorialLayer.otherlist, spj)
			    local spj = CCSprite:createWithSpriteFrameName("jiaocheng_002.png")
			    spj:setPosition(ccp(470, 270))
            	tutorialLayer.parentd:addChild(spj)
			    table.insert(tutorialLayer.otherlist, spj)
				---------不需要操作的砖块变暗
				--左
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(420,520))
				templayer:setPosition(ccp(0,0))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--上
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(100,100))
				templayer:setPosition(ccp(420,420))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--右
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setPosition(ccp(520,0))
				templayer:setContentSize(CCSizeMake(320,520))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--下
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setPosition(ccp(420,0))
				templayer:setContentSize(CCSizeMake(100,220))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
			elseif index == 12 then
				--520
				tutorialLayer.bgp:setVisible(false)
			elseif index == 13 then
				tutorialLayer.hidePLayer()
				_UIinfo.layer:setVisible(false)

				if GTempTutorialFight3 then
					GTempTutorialFight4 = function()
						GTempTutorialFight4 = nil
						_UIinfo.layer:setVisible(true)
					end
					GTempTutorialFight3()
					GTempTutorialFight3 = nil
				end
				tutorialLayer.clearother()
				--520
				tutorialLayer.bgp:setVisible(false)
			elseif index == 14 then
				if GTempTutorialFight5 then
					GTempTutorialFight5()
				end
				tutorialLayer.clearother()
				tutorialLayer.bgp:setVisible(false)
			elseif index == 15 then
				tutorialLayer.hidePLayer()
				tutorialLayer.bgp:setVisible(false)
			end
		else
			if GTempTutorialFight7 then
				GTempTutorialFight7()
			end
			--关闭
			tutorialLayer.closefunc()
			--关闭所有窗口
			GGameFuncCloseAllInterface()
		end
		index = index + 1
	end
	runEvent()
end

--基础教程结束,界面指导教程
local function tutorInterface(args)
	local index = 1
	local evtlist = {}--{1036,1037,1038,1038}
	for k=1065,1068 do
		table.insert(evtlist, k)
	end
	---
	local tutorialLayer = GFuncCreateTutorialLayer(args)

	local function runEvent()
		if index <= #evtlist then
			local eid = evtlist[index]
			---事件执行
			local _UIinfo = GFuncCreateStoryLayer(eid, runEvent)
			tutorialLayer.bgp:setVisible(true)
			if index == 1 then

			elseif index == 2 then
				_UIinfo.parent:setPositionY(_UIinfo.parentY+200)
				---显示界面介绍

				--暂停、保存、设置、返回
				local txt = CCLabelTTF:create("暂停/保存\n设置/返回", "Arial", 28)
				txt:setAnchorPoint(ccp(0,0.5))
			    txt:setPosition(ccp(5, DWinSize.height - 100))
			    tutorialLayer.parent:addChild(txt)
			    table.insert(tutorialLayer.otherlist, txt)
				--时间
				local txt = CCLabelTTF:create("时间", "Arial", 28)
				txt:setAnchorPoint(ccp(0,0.5))
			    txt:setPosition(ccp(50, DWinSize.height-30))
			    tutorialLayer.parent:addChild(txt)
			    table.insert(tutorialLayer.otherlist, txt)
				--金币
				local txt = CCLabelTTF:create("金币", "Arial", 28)
			    txt:setPosition(ccp(DWinSize.width-200, DWinSize.height-30))
			    tutorialLayer.parent:addChild(txt)
			    table.insert(tutorialLayer.otherlist, txt)
				--魔法点
				local txt = CCLabelTTF:create("魔法点", "Arial", 28)
			    txt:setPosition(ccp(DWinSize.width-150, DWinSize.height-80))
			    tutorialLayer.parent:addChild(txt)
			    table.insert(tutorialLayer.otherlist, txt)
				--出征
				local txt = CCLabelTTF:create("出征", "Arial", 28)
			    txt:setPosition(ccp(60, 150))
			    tutorialLayer.parent:addChild(txt)
			    table.insert(tutorialLayer.otherlist, txt)
				--玩家信息
				local txt = CCLabelTTF:create("信息界面", "Arial", 28)
			    txt:setPosition(ccp(60, 60))
			    tutorialLayer.parent:addChild(txt)
			    table.insert(tutorialLayer.otherlist, txt)
				--任务
				local txt = CCLabelTTF:create("任务", "Arial", 28)
			    txt:setPosition(ccp(150, 60))
			    tutorialLayer.parent:addChild(txt)
			    table.insert(tutorialLayer.otherlist, txt)
				--商场/宝石购买
				local txt = CCLabelTTF:create("商场\n宝石购买", "Arial", 28)
			    txt:setPosition(ccp(DWinSize.width - 160, 60))
			    tutorialLayer.parent:addChild(txt)
			    table.insert(tutorialLayer.otherlist, txt)
				--建造
				local txt = CCLabelTTF:create("建造", "Arial", 28)
			    txt:setPosition(ccp(DWinSize.width - 60, 60))
			    tutorialLayer.parent:addChild(txt)
			    table.insert(tutorialLayer.otherlist, txt)
			elseif index == 3 then
				tutorialLayer.clearother()
				tutorialLayer.bgp:setVisible(false)
			elseif index == 4 then
				tutorialLayer.clearother()
				tutorialLayer.bgp:setVisible(false)
			end
		else
			--关闭
			tutorialLayer.closefunc()
			--关闭所有窗口
			GGameFuncCloseAllInterface()
		end
		index = index + 1
	end
	runEvent()
end


--刮刮卡教程
local function tutorGuaGuaka(args)
	local index = 1
	local evtlist = {}
	for k=1069,1077 do
		table.insert(evtlist, k)
	end
	---
	local tutorialLayer = GFuncCreateTutorialLayer(args)
	local function runEvent()
		if index <= #evtlist then
			local eid = evtlist[index]
			---事件执行
			local _UIinfo = GFuncCreateStoryLayer(eid, runEvent)
			tutorialLayer.bgp:setVisible(true)
			if index == 1 then
			elseif index == 2 then
				tutorialLayer.bgp:setVisible(false)
				--左
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(DWinSize.width-180,DWinSize.height))
				templayer:setPosition(ccp(0,0))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--上
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(180, 110))
				templayer:setPosition(ccp(DWinSize.width-180, DWinSize.height-110))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--下
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(180, DWinSize.height-168))
				templayer:setPosition(ccp(DWinSize.width-180, 0))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
			elseif index == 3 then
				_UIinfo.parent:setPositionY(_UIinfo.parentY+200)
				tutorialLayer.clearother()

			  	local btnItem = GFunc_CreateButtonP("jiemian_143.png", function()
			        createLayerBuildMenu(function()
			        end)
			        GFuncClickEventStory()
			    end,nil,1.5)
			    btnItem:setPosition(ccp(DWinSize.width - 160, 60))
			    tutorialLayer.parent:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, btnItem)
				table.insert(tutorialLayer.btnlist,btnItem)
			elseif index == 4 then
				_UIinfo.parent:setPositionY(_UIinfo.parentY+200)
				tutorialLayer.clearother()
				tutorialLayer.showPLayer()
			  	local btnItem = GFunc_CreateButtonP("jiemian_143.png", function()
			        createLayerShop(function()
			        end)
			        GFuncClickEventStory()
			    end,nil,1.5)
			    btnItem:setPosition(ccp(DWinSize.width - 160, 60))
			    tutorialLayer.parent:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, btnItem)
				table.insert(tutorialLayer.btnlist,btnItem)
			elseif index == 5 then
				_UIinfo.parent:setPositionY(_UIinfo.parentY+740)
				tutorialLayer.clearother()
				tutorialLayer.hidePLayer()
				tutorialLayer.bgp:setVisible(false)
			elseif index == 6 then
				_UIinfo.parent:setPositionY(_UIinfo.parentY+740)
				tutorialLayer.clearother()
				--点击任务
				tutorialLayer.parentlayer:setVisible(false)
				tutorialLayer.parentlayer:setTouchEnabled(true)--showPLayer()
				tutorialLayer.bgp:setVisible(false)

				local menu = CCMenu:create()
				menu:setPosition(ccp(0,0))
				tutorialLayer.parent:addChild(menu)

				local btnItem = GFunc_CreateButtonLabel("", function()
					createLayerShopReward({tutorial=true})
					tutorialLayer.hidePLayer()
					GFuncClickEventStory()
				end, nil, CCSizeMake(215, 215))
	            btnItem:setPosition(ccp(200, 310))
	            menu:addChild(btnItem)
			    table.insert(tutorialLayer.otherlist, menu)
				table.insert(tutorialLayer.btnlist, btnItem)

				---遮挡效果
				--上
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setPosition(ccp(0,460))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--左
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(85,270))
				templayer:setPosition(ccp(0,190))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--右
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(500,270))
				templayer:setPosition(ccp(310,190))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
				--下
				local templayer = GFunc_CreateLayerEnterOrExit({color=ccc4(0,0,0,150)})
				templayer:setContentSize(CCSizeMake(640,190))
				tutorialLayer.parentd:addChild(templayer)
			    table.insert(tutorialLayer.otherlist, templayer)
			elseif index == 7 then
				tutorialLayer.hidePLayer()
				tutorialLayer.clearother()
				tutorialLayer.bgp:setVisible(false)
				_UIinfo.parent:setPositionY(_UIinfo.parentY+50)
			elseif index == 8 then
				tutorialLayer.bgp:setVisible(false)
				_UIinfo.layer:setTouchEnabled(false)
				_UIinfo.parent:setPositionY(_UIinfo.parentY+50)

				_GFuncTutorialTempFunc = function()
					---
					GFunc_RemoveChild(_UIinfo.layer)
					_GFuncTutorialTempFunc = nil
					runEvent()
				end
			elseif index == 9 then
				tutorialLayer.bgp:setVisible(false)
				_UIinfo.parent:setPositionY(_UIinfo.parentY+50)
			end
		else
			--关闭
			tutorialLayer.closefunc(true)
			--关闭所有窗口
			GGameFuncCloseAllInterface()
		end
		index = index + 1
	end
	runEvent()
end


TStep1	= 0x01
TStep2	= 0x02
TStep3	= 0x03
TStep4	= 0x04
TStep5	= 0x05
TStep6	= 0x06
TStep7	= 0x07
TStep8 	= 0x08
local tutorialTables = {
	[TStep1] = tutorialGameInit,
	[TStep2] = buildMagicHouse,
	[TStep3] = buildYanjiuFirstBtn,--buildMagicHouse,
	[TStep4] = buildGameShop,--buildMagicHouse,
	[TStep5] = tutorFightTask,--buildMagicHouse,
	[TStep6] = tutorFight,--buildMagicHouse,
	[TStep7] = tutorInterface,--buildMagicHouse,
	[TStep8] = tutorGuaGuaka,
}

local tutorialStatus = {}
function hasfinshTutorial( tid )
	-- body
	--for k,v in pairs(tutorialStatus) do
	--	print(k,v)
	--end

	if tutorialStatus[tid] then
		return true
	end
	return false
end

---初始教程ID/执行到的教程
GGameInitTutorialID	= TStep1

function loadTutorialInfo()
	GGameInitTutorialID	= TStep1
	tutorialStatus = {}

	local strdata = Config_GameTutorialData()
    if strdata == nil or strdata == "" then
        return
    end
    local sdata = unserialize(strdata)
    tutorialStatus = sdata
    --加载教程信息
    for k,v in pairs(tutorialStatus) do
    	--print("tutor",k,v,GGameInitTutorialID)
    	if k > GGameInitTutorialID then
    		GGameInitTutorialID = k
    	end
    end

    local maxtutorialID = 0
    for k,v in pairs(tutorialTables) do
    	if v and k > maxtutorialID then
    		maxtutorialID = k
    	end
    end

    if GGameInitTutorialID == maxtutorialID then
    	GGameInitTutorialID = nil
    else
    	GGameInitTutorialID = GGameInitTutorialID + 1
    end
end

GGameRunTutorialStep = nil
---执行教程任务
function TutorialTaskRun(step, args)
	--被闭关
	local function efunc()
		GGamePause = false
	end
	--正常结束
	local function efinsh()
		tutorialStatus[step] = true
		--保存教程完成情况
		Config_GameTutorialData(tutorialStatus)
		--保存游戏
		--print("5__")
		Config_AutoSaveGameData()

		--print("完成保存,",step)
	end

	if args == nil then
		args = {}
	end
	args["efinsh"] = efinsh
	args["efunc"] = efunc
	--print(step.."____")
	if tutorialTables[step] then
		GGamePause = true
		tutorialTables[step](args)
	else
		efunc()
	end
end








--------------
GColorType_Red = 1
GColorType_Buld = 2
GColorType_Greed	= 3
GColorType_Yellow	= 4
GColorType_LGreed	= 5
GColorType_Purple	= 6
GColorType_Health	= 0x09 --治疗砖块 fangk_009
--教程用砖块表
local tutorialInitBrickTables = {
	{GColorType_Red, GColorType_Red, GColorType_Buld, GColorType_Buld, GColorType_Health, GColorType_Buld},
	{GColorType_Buld, GColorType_Buld, GColorType_Red, GColorType_Health, GColorType_Buld, GColorType_Health},
	{GColorType_Red, GColorType_Red, GColorType_Buld, GColorType_LGreed, GColorType_Health, GColorType_Health},
	{GColorType_Buld, GColorType_Buld, GColorType_Red, GColorType_Yellow, GColorType_Health, GColorType_Greed},
	{GColorType_Red, GColorType_Red, GColorType_Buld, GColorType_Red, GColorType_Buld, GColorType_Buld},
}

function GGameTutorialInitPuzBrick(puzclass)
    puzclass.bInit = true
    for r=1, puzclass._rows do
        for c=1,puzclass._cols do
        	local tr = (puzclass._rows-(r-1))
        	local tpe = tutorialInitBrickTables[tr][c]
        	--print(tpe,tr,r,c)
            puzclass:newGem(r, c, tpe)
        end
    end
    --print("教程杀...")

    ---开启不重复生成
    puzclass.bInit = true--false
    --不刷新蓝色砖块
    puzclass._types = {1,3,4,5,GColorType_Health}
end